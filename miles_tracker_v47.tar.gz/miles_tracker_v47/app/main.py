from fastapi import FastAPI, Form
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from bs4 import BeautifulSoup
from cryptography.fernet import Fernet, InvalidToken
from datetime import datetime, date, timedelta
from zoneinfo import ZoneInfo
from pathlib import Path
import sqlite3, re, imaplib, email, html, os, threading, time, hashlib, json
from email import policy
from email.parser import BytesParser
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

BASE = Path(__file__).resolve().parent
DB = BASE.parent / 'data' / 'miles.db'
KEYFILE = BASE.parent / 'data' / '.credential_key'
DB.parent.mkdir(exist_ok=True)
SG_TZ = ZoneInfo('Asia/Singapore')

def sg_now():
    return datetime.now(SG_TZ)

def sg_today():
    return sg_now().date()

app = FastAPI(title='Miles Tracker V47')
app.mount('/static', StaticFiles(directory=str(BASE/'static')), name='static')

CARDS = {'citi_rewards': {'name':'Citi Rewards Mastercard','type':'miles'}, 'maybank_fnf': {'name':'Maybank Family & Friends Mastercard','type':'cashback'}, 'maybank_xl_rewards': {'name':'Maybank XL Cashback','type':'cashback'}, 'trust_freedom': {'name':'Trust Freedom Card','type':'cashback'}}
MCC = {
    742:'Veterinary Services', 4111:'Local/Suburban Commuter Passenger Transportation', 4112:'Passenger Railways', 4121:'Taxicabs and Limousines', 4131:'Bus Lines', 4215:'Courier Services', 4411:'Cruise Lines', 4511:'Airlines', 4722:'Travel Agencies and Tour Operators', 4789:'Transportation Services', 4812:'Telecommunication Equipment', 4814:'Telecommunication Services', 4899:'Cable, Satellite and Other Pay Television/Radio Services', 4900:'Utilities', 5311:'Department Stores', 5331:'Variety Stores', 5399:'Miscellaneous General Merchandise', 5411:'Grocery Stores/Supermarkets', 5422:'Freezer and Locker Meat Provisioners', 5441:'Candy, Nut and Confectionery Stores', 5451:'Dairy Products Stores', 5462:'Bakeries', 5499:'Miscellaneous Food Stores', 5532:'Automotive Tire Stores', 5533:'Automotive Parts and Accessories Stores', 5541:'Service Stations (with or without Ancillary Services)', 5542:'Fuel Dispenser, Automated', 5611:"Men's and Boys' Clothing and Accessories Stores", 5621:"Women's Ready-to-Wear", 5631:"Women's Accessory/Specialty Stores", 5641:'Children/Infants Wear Stores', 5651:'Family Clothing Stores', 5655:'Sports and Riding Apparel Stores', 5661:'Shoe Stores', 5691:'Men’s and Women’s Clothing Stores', 5699:'Miscellaneous Apparel and Accessory Shops', 5732:'Electronics Stores', 5811:'Caterers', 5812:'Eating Places and Restaurants', 5813:'Bars, Cocktail Lounges, Discotheques, Nightclubs and Taverns', 5814:'Fast Food Restaurants', 5815:'Digital Goods: Media, Books, Movies, Music', 5816:'Digital Goods: Games', 5817:'Digital Goods: Applications', 5818:'Digital Goods: Large Digital Goods Merchants', 5940:'Bicycle Shops', 5941:'Sporting Goods Stores', 5942:'Book Stores', 5945:'Hobby, Toy and Game Shops', 5948:'Luggage and Leather Goods Stores', 5962:'Direct Marketing—Travel Related Arrangements Services', 5995:'Pet Shops, Pet Food and Supplies Stores', 6300:'Insurance Sales, Underwriting and Premiums', 7011:'Lodging—Hotels, Motels, Resorts', 7512:'Automobile Rental Agency', 7832:'Motion Picture Theaters', 7922:'Theatrical Producers and Ticket Agencies', 7993:'Video Amusement Game Supplies', 7994:'Video Game Arcades', 8211:'Elementary and Secondary Schools', 8220:'Colleges, Universities and Professional Schools', 8398:'Charitable and Social Service Organizations', 8999:'Professional Services (Not Elsewhere Classified)'}
CITI_SHOPPING_MCC = {5311,5611,5621,5631,5641,5651,5655,5661,5691,5699,5948}
CITI_TRAVEL_MCC = set(range(3000,4000)) | {4111,4112,4789,4411,4511,4722,4723,5962,7011,7012,7512}
# Maybank XL Cashback — official MCCs from XL Cashback Card T&Cs
XL_MCC = {
    'Dine': {5811, 5812, 5814, 5462},
    'Shop': {5262, 5310, 5311, 5331, 5399, 5621, 5631, 5651, 5655, 5661, 5691, 5699, 5941},
    'Travel': set(range(3000, 3300)) | set(range(3300, 3309)) | {4511, 4722, 7011},
    'Play': {4899, 5813, 5815, 7832, 7993, 7994},
}
XL_ALL_BONUS_MCC = set().union(*XL_MCC.values())
# XL Cashback Programme T&Cs, clause 5.6: excluded transaction MCCs.
XL_EXCLUDED_MCC = {4829, 4900, 5960, 6010, 6011, 6012, 6050, 6051, 6381, 6399, 6529, 6530, 6534, 6540, 7349, 7511}
XL_EXCLUDED_MERCHANT_PREFIXES = (
    'BAGUS', 'BANC DE BINARY', 'BANCDEBINARY.COM', 'CANTINE', 'EZ LINK',
    'EZ-LINK', 'EZLINK', 'EZLINKS.COM', 'FLASH PAY', 'FLASHPAY', 'INSTAREM',
    'MB * MONEYBOOKERS.COM', 'NETS VCASHCARD', 'OANDA ASIA PAC', 'RAZERPAY',
    'SEDAP', 'SGEBIZ', 'SIMPLYGO', 'SINGTEL DASH', 'SINGAPORE E-BUSINESS',
    'SKR*', 'SKYFX.COM', 'TRANSIT', 'TRANSITLINK', 'TRANSIT LINK',
    'WWW.IGMARKETS.COM.SG', 'WWW.PLUS500.CO.UK', 'WWW.MYEZLINK.COM.SG', 'YOUTRIP'
)

# Maybank Family & Friends — category MCCs (effective 1 Jan 2026 where known)
FNF_MCC = {
    'Automotive': {5541, 5542, 5532, 5533, 5599, 7531, 7535, 7538, 5552, 8699},
    'Beauty & Wellness': {7297, 7298, 7230},
    'Commute': {4111, 4112, 4121, 4131, 4789},
    'Dining & Food Delivery': {5812, 5814},
    'Entertainment': {5813, 7832, 7922, 7929},
    'Groceries': {5411},
    'Kids & Pets': {742, 5995},
    'Online Shopping': {5611, 5262, 5309, 5310, 5331, 5399, 5621, 5631, 5641, 5651, 5661, 5691, 5699, 5948},
    'Sports & Sports Apparels': {5655, 5940, 5941, 7032, 7941, 7992, 7997},
    'Telco & Streaming': {4812, 4814, 4899},
}
# Default preferred categories for new cardmembers from 1 Jan 2026
FNF_DEFAULT_PREFERRED = ['Automotive', 'Dining & Food Delivery', 'Kids & Pets', 'Online Shopping', 'Telco & Streaming']



def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row
    c.execute("""CREATE TABLE IF NOT EXISTS transactions(id INTEGER PRIMARY KEY,transaction_date TEXT,transaction_time TEXT,posted_date TEXT,merchant TEXT,amount REAL,currency TEXT,card_id TEXT,last4 TEXT,mcc INTEGER,mcc_source TEXT,mcc_confidence TEXT,mcc_note TEXT,transaction_channel TEXT DEFAULT 'unknown',miles REAL DEFAULT 0,cashback REAL DEFAULT 0,reward_status TEXT,raw_summary TEXT,created_at TEXT)""")
    c.execute("CREATE TABLE IF NOT EXISTS card_settings(card_id TEXT PRIMARY KEY,statement_day INTEGER DEFAULT 1)")
    c.execute("CREATE TABLE IF NOT EXISTS card_identifiers(identifier_type TEXT NOT NULL, identifier_value TEXT NOT NULL, card_id TEXT NOT NULL, updated_at TEXT NOT NULL, PRIMARY KEY(identifier_type, identifier_value))")
    # Maybank SMS last-4 mappings are configuration, not parser logic.
    c.execute("INSERT OR IGNORE INTO card_identifiers(identifier_type,identifier_value,card_id,updated_at) VALUES('last4','8003','maybank_fnf',?)", (sg_now().isoformat(),))
    c.execute("INSERT OR IGNORE INTO card_identifiers(identifier_type,identifier_value,card_id,updated_at) VALUES('last4','2007','maybank_xl_rewards',?)", (sg_now().isoformat(),))
    # Citi Rewards statement date: user has confirmed the statement closes on the 20th.
    # The setting is persisted so the statement-cycle logic does not depend on UI state.
    c.execute("INSERT OR IGNORE INTO card_settings(card_id,statement_day) VALUES('citi_rewards',20)")
    c.execute("""CREATE TABLE IF NOT EXISTS merchant_mcc_rules(merchant_name TEXT PRIMARY KEY COLLATE BINARY,mcc INTEGER NOT NULL,note TEXT,source TEXT NOT NULL DEFAULT 'user',updated_at TEXT NOT NULL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS app_settings(key TEXT PRIMARY KEY,value TEXT NOT NULL,updated_at TEXT NOT NULL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS processed_emails(uid TEXT PRIMARY KEY,message_id TEXT,received_at TEXT,subject TEXT,sender TEXT,parser_version TEXT,transaction_id INTEGER,processed_at TEXT NOT NULL)""")
    # Track supported-card emails that could not be parsed so the UI can show them.
    # Safe migration for databases created before V20.
    c.execute("""CREATE TABLE IF NOT EXISTS email_parse_issues(uid TEXT PRIMARY KEY,message_id TEXT,received_at TEXT,subject TEXT,sender TEXT,reason TEXT,first_seen TEXT NOT NULL,last_seen TEXT NOT NULL)""")
    try:
        c.execute('ALTER TABLE email_parse_issues ADD COLUMN email_content TEXT')
    except sqlite3.OperationalError as e:
        if 'duplicate column name' not in str(e).lower():
            raise
    cols={r['name'] for r in c.execute('PRAGMA table_info(transactions)').fetchall()}
    if 'spend_sgd' not in cols: c.execute("ALTER TABLE transactions ADD COLUMN spend_sgd REAL")
    if 'fx_rate' not in cols: c.execute("ALTER TABLE transactions ADD COLUMN fx_rate REAL")
    if 'fx_source' not in cols: c.execute("ALTER TABLE transactions ADD COLUMN fx_source TEXT")
    if 'fx_updated_at' not in cols: c.execute("ALTER TABLE transactions ADD COLUMN fx_updated_at TEXT")
    if 'posted_amount_sgd' not in cols: c.execute("ALTER TABLE transactions ADD COLUMN posted_amount_sgd REAL")
    cols={r['name'] for r in c.execute('PRAGMA table_info(transactions)').fetchall()}
    if 'transaction_time' not in cols: c.execute("ALTER TABLE transactions ADD COLUMN transaction_time TEXT")
    if 'transaction_channel' not in cols: c.execute("ALTER TABLE transactions ADD COLUMN transaction_channel TEXT DEFAULT 'unknown'")
    if 'email_cashback' not in cols: c.execute("ALTER TABLE transactions ADD COLUMN email_cashback REAL")
    # Backfill transaction times from stored email text for transactions imported before V7.
    for r in c.execute("SELECT id,raw_summary FROM transactions WHERE (transaction_time IS NULL OR transaction_time='') AND raw_summary IS NOT NULL AND raw_summary<>''").fetchall():
        raw=str(r['raw_summary'])
        tm=None
        m=re.search(r'Transaction\s+time\s*:\s*([0-9]{1,2}:[0-9]{2}(?::[0-9]{2})?)', raw, re.I)
        if m: tm=m.group(1)
        if not tm:
            m=re.search(r'\bon\s+\d{1,2}\s+[A-Za-z]{3,9}\s+\d{4}\s+(\d{1,2}:\d{2}(?::\d{2})?)\s*SGT', raw, re.I)
            if m: tm=m.group(1)
        if tm: c.execute("UPDATE transactions SET transaction_time=? WHERE id=?",(tm,r['id']))
    c.commit(); return c

def is_amaze_merchant(name):
    """AMAZE* transactions are routed through the online payment method."""
    return str(name or '').strip().upper().startswith('AMAZE*')

def enforced_transaction_channel(merchant, channel=None):
    if is_amaze_merchant(merchant):
        return 'online'
    return channel or 'unknown'

def suspicious_merchant(name):
    return bool(re.search(r'(?:mail-sor-|google\.com|googleusercontent\.com|amazonses\.com|Received:|Return-Path:)', str(name or ''), re.I))

def repair_malformed_merchants(c):
    """Repair transactions created by the old fallback parser from stored email text."""
    if get_setting(c, 'merchant_repair_v2', '') == '1':
        return 0
    repaired = 0
    rows = c.execute("SELECT * FROM transactions WHERE raw_summary IS NOT NULL AND raw_summary<>'' AND (merchant = 'Unknown merchant' OR merchant LIKE '%mail-sor-%' OR merchant LIKE '%google.com%' OR merchant LIKE '%googleusercontent.com%' OR merchant LIKE '%amazonses.com%')").fetchall()
    for r in rows:
        try:
            parsed = parse_email(str(r['raw_summary']), c)
        except Exception:
            parsed = None
        if not parsed or not parsed.get('merchant') or suspicious_merchant(parsed.get('merchant')):
            continue
        merchant = parsed['merchant']
        mcc, src, conf, note = effective_mcc(c, merchant, None)
        tx = dict(r)
        tx.update(parsed)
        tx['mcc'] = mcc
        tx['transaction_channel'] = parsed.get('transaction_channel') or r['transaction_channel'] or 'unknown'
        miles, cashback, status = calc_reward(tx, c, True)
        c.execute("UPDATE transactions SET transaction_date=?,transaction_time=?,posted_date=?,merchant=?,amount=?,currency=?,card_id=?,last4=?,mcc=?,mcc_source=?,mcc_confidence=?,mcc_note=?,transaction_channel=?,email_cashback=?,miles=?,cashback=?,reward_status=? WHERE id=?",
                  (parsed.get('transaction_date',r['transaction_date']), parsed.get('transaction_time',r['transaction_time'] or ''), parsed.get('posted_date',r['posted_date']), merchant, parsed.get('amount',r['amount']), parsed.get('currency',r['currency']), parsed.get('card_id',r['card_id']), parsed.get('last4',r['last4']), mcc, src, conf, note, tx['transaction_channel'], parsed.get('email_cashback',r['email_cashback']), miles, cashback, status, r['id']))
        repaired += 1
    set_setting(c, 'merchant_repair_v2', '1')
    c.commit()
    return repaired

def repair_maybank_transactions(c):
    """Reparse previously imported Maybank alerts after the dedicated parser was added."""
    if get_setting(c, 'maybank_parser_repair_v2', '') == '1':
        return 0
    repaired = 0
    rows = c.execute("SELECT * FROM transactions WHERE raw_summary IS NOT NULL AND raw_summary<>'' AND (card_id='' OR card_id IS NULL OR merchant='Unknown merchant' OR last4 IN (SELECT identifier_value FROM card_identifiers WHERE identifier_type='last4'))").fetchall()
    for r in rows:
        try: parsed = parse_maybank_email(str(r['raw_summary']), c)
        except Exception: parsed = None
        if not parsed or not parsed.get('merchant') or not parsed.get('last4'): continue
        if not parsed.get('card_id'): continue
        mcc, src, conf, note = effective_mcc(c, parsed['merchant'], None)
        tx = dict(r); tx.update(parsed); tx['mcc']=mcc; tx['transaction_channel']=parsed.get('transaction_channel') or 'unknown'
        miles, cash, status = calc_reward(tx, c, True)
        c.execute("UPDATE transactions SET transaction_date=?,transaction_time=?,posted_date=?,merchant=?,amount=?,currency=?,card_id=?,last4=?,mcc=?,mcc_source=?,mcc_confidence=?,mcc_note=?,transaction_channel=?,miles=?,cashback=?,reward_status=? WHERE id=?",
                  (parsed['transaction_date'],parsed.get('transaction_time',''),parsed['posted_date'],parsed['merchant'],parsed['amount'],parsed['currency'],parsed['card_id'],parsed['last4'],mcc,src,conf,note,tx['transaction_channel'],miles,cash,status,r['id']))
        repaired += 1
    set_setting(c, 'maybank_parser_repair_v2', '1'); c.commit(); return repaired

def get_setting(c,key,default=''):
    r=c.execute('SELECT value FROM app_settings WHERE key=?',(key,)).fetchone(); return r['value'] if r else default

def set_setting(c,key,value):
    c.execute('INSERT INTO app_settings(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at',(key,value,sg_now().isoformat()))

def crypto():
    if not KEYFILE.exists(): KEYFILE.write_bytes(Fernet.generate_key()); os.chmod(KEYFILE,0o600)
    return Fernet(KEYFILE.read_bytes().strip())

def save_secret(c,key,value): set_setting(c,'secret:'+key,crypto().encrypt(value.encode()).decode())
def read_secret(c,key):
    v=get_setting(c,'secret:'+key,'')
    if not v:return ''
    try:return crypto().decrypt(v.encode()).decode()
    except (InvalidToken,ValueError):return ''

def exact_mcc_rule(c,merchant): return c.execute('SELECT * FROM merchant_mcc_rules WHERE merchant_name = ? COLLATE BINARY',(merchant,)).fetchone()

def extract_message_body(body):
    """Extract the actual bank-email content from normal or forwarded MIME mail.

    Gmail forwarding can wrap the original bank message inside multipart or
    message/rfc822 parts. Prefer the deepest HTML/plain body and avoid parsing
    transport headers (Received/From/etc.) as transaction content.
    """
    def walk(msg, depth=0):
        if depth > 4:
            return ''
        # A forwarded message may be attached as message/rfc822.
        for part in msg.walk():
            if part.get_content_type() == 'message/rfc822':
                try:
                    nested = part.get_payload(0)
                    if nested is not None:
                        result = walk(nested, depth + 1)
                        if result:
                            return result
                except Exception:
                    pass
        if msg.is_multipart():
            for preferred in ('text/html', 'text/plain'):
                for part in msg.walk():
                    if part.get_content_type() != preferred:
                        continue
                    if part.get_content_disposition() == 'attachment':
                        continue
                    try:
                        value = part.get_content()
                        if value and len(value.strip()) > 20:
                            return value
                    except Exception:
                        continue
        else:
            try:
                value = msg.get_content()
                if value:
                    return value
            except Exception:
                pass
        return ''

    try:
        msg = BytesParser(policy=policy.default).parsebytes(body.encode('utf-8', 'ignore'))
        extracted = walk(msg)
        if extracted:
            return extracted
    except Exception:
        pass
    return body

def parse_citi_email(body):
    """Parse Citi Singapore transaction-alert emails (HTML or plain)."""
    body = extract_message_body(body)
    text = re.sub(r'\s+', ' ', BeautifulSoup(body, 'html.parser').get_text(' ', strip=True))
    if not re.search(r'citi|citibank', text, re.I):
        return None
    am = None
    for pat in [
        r'Transaction\s+amount\s*:\s*(?:SGD|S\$)\s*([0-9,]+\.\d{2})',
        r'(?:SGD|S\$)\s*([0-9,]+\.\d{2})\s*(?:was\s+spent|charged|posted)',
        r'Amount\s*:\s*(?:SGD|S\$)\s*([0-9,]+\.\d{2})',
        r'(?:SGD|S\$)\s*([0-9,]+\.\d{2})',
    ]:
        am = re.search(pat, text, re.I)
        if am:
            break
    dm = None
    for pat in [
        r'Transaction\s+date\s*:\s*(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})',
        r'Date\s*:\s*(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})',
        r'\b(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})\b',
    ]:
        dm = re.search(pat, text, re.I)
        if dm:
            break
    tm = re.search(r'Transaction\s+time\s*:\s*([0-9]{1,2}:[0-9]{2}(?::[0-9]{2})?)', text, re.I)
    mm = None
    for pat in [
        r'Transaction\s+details\s*:\s*(.+?)(?=\s+If\s+you\s+did\s+not\s+make|\s+Thank\s+you\s+for\s+banking|\s+Account\s+number|\s+Card\s+ending|$)',
        r'(?:Merchant|Description|At)\s*:\s*(.+?)(?=\s+If\s+you\s+did\s+not\s+make|\s+Thank\s+you|\s+Transaction\s+amount|\s+Account\s+number|$)',
        r'(?:spent\s+at|charged\s+at)\s+(.+?)(?=\s+on\s+\d|\s+If\s+you|\s+Thank\s+you|$)',
    ]:
        mm = re.search(pat, text, re.I)
        if mm:
            break
    cm = re.search(r'(?:Account\s+number|Card\s+ending|ending\s+in)\s*:?\s*X*[-\sX]*(\d{4})', text, re.I)
    if not (am and dm and mm):
        return None
    d, mo, y = map(int, dm.groups())
    y += 2000 if y < 100 else 0
    try:
        tx_date = date(y, mo, d).isoformat()
    except ValueError:
        try:
            tx_date = date(y, d, mo).isoformat()
        except ValueError:
            return None
    merchant = re.sub(r'\s+', ' ', mm.group(1)).strip()[:160]
    merchant = re.split(r'\s+If you did not\b', merchant, flags=re.I)[0].strip()
    if not merchant or not am.group(1):
        return None
    return {
        'merchant': merchant,
        'amount': float(am.group(1).replace(',', '')),
        'currency': 'SGD',
        'transaction_date': tx_date,
        'posted_date': tx_date,
        'card_id': 'citi_rewards',
        'last4': cm.group(1) if cm else '',
        'transaction_channel': 'unknown',
        'summary': text[:1000],
        'transaction_time': tm.group(1) if tm else '',
    }

def parse_trust_email(body):
    """Parse Trust Bank Freedom transaction alerts such as:
    You've spent SGD 2.07 at MERCHANT on 26 Sep 2026 13:56SGT with Freedom credit card.
    You'll receive estimated S$0.02 cashback.
    """
    body = extract_message_body(body)
    text = re.sub(r'\s+', ' ', BeautifulSoup(body, 'html.parser').get_text(' ', strip=True))
    if not re.search(r'trustbank\.sg|trust\s+bank|freedom\s+credit\s+card', text, re.I):
        return None
    m = re.search(r"You've\s+spent\s+([A-Z]{3}|S\$|\$)\s*([0-9,]+\.\d{2})\s+at\s+(.+?)\s+on\s+(\d{1,2})\s+([A-Za-z]{3,9})\s+(\d{4})\s+(\d{1,2}:\d{2}(?::\d{2})?)\s*(?:SGT|GMT\+?\s*08:00)\s+with\s+Freedom\s+credit\s+card", text, re.I)
    if not m:
        return None
    currency, amount_s, merchant, d, mon, y, tm = m.groups()
    try:
        tx_date = datetime.strptime(f'{d} {mon} {y}', '%d %b %Y').date().isoformat()
    except ValueError:
        try: tx_date = datetime.strptime(f'{d} {mon} {y}', '%d %B %Y').date().isoformat()
        except ValueError: return None
    cm = re.search(r'estimated\s+S\$\s*([0-9,]+\.\d{2})\s+cashback', text, re.I)
    cashback = float(cm.group(1).replace(',', '')) if cm else None
    merchant = re.sub(r'\s+', ' ', merchant).strip()[:160]
    return {
        'merchant': merchant,
        'amount': float(amount_s.replace(',', '')),
        'currency': 'SGD' if currency.upper() in ('S$', '$') else currency.upper(),
        'transaction_date': tx_date,
        'posted_date': tx_date,
        'card_id': 'trust_freedom',
        'last4': '',
        'transaction_channel': 'unknown',
        'summary': text[:1000],
        'transaction_time': tm,
        'email_cashback': cashback,
    }

def card_id_for_last4(c, last4):
    r = c.execute("SELECT card_id FROM card_identifiers WHERE identifier_type='last4' AND identifier_value=?", (str(last4),)).fetchone()
    return r['card_id'] if r else ''

def google_spot_rate(from_currency, to_currency):
    frm=str(from_currency).upper(); to=str(to_currency).upper()
    if frm == to: return 1.0
    url=f"https://www.google.com/finance/quote/{frm}-{to}?window=1D"
    req=Request(url,headers={'User-Agent':'Mozilla/5.0 (MilesTracker/33.0)'})
    try: html=urlopen(req,timeout=8).read().decode('utf-8','ignore')
    except (URLError, HTTPError, TimeoutError, OSError): html=''
    if html:
        for pat in [r'class=["\'][^"\']*YMlKec[^"\']*fxKbKc[^"\']*["\'][^>]*>([0-9][0-9,]*(?:\.[0-9]+)?)<',r'class=["\'][^"\']*fxKbKc[^"\']*["\'][^>]*>([0-9][0-9,]*(?:\.[0-9]+)?)<']:
            m=re.search(pat,html,re.I)
            if m:
                try:
                    rate=float(m.group(1).replace(',',''))
                    if rate>0:return rate
                except ValueError: pass

    # No-key fallback. The API quotes currencies against SGD, so MYR/SGD is
    # obtained by taking the reciprocal of the returned MYR-per-SGD rate.
    try:
        fallback_url=f"https://open.er-api.com/v6/latest/{to}"
        req=Request(fallback_url,headers={'User-Agent':'Mozilla/5.0 (MilesTracker/33.0)'})
        raw=urlopen(req,timeout=8).read().decode('utf-8','ignore')
        obj=json.loads(raw)
        rates=obj.get('rates') or {}
        quoted=float(rates.get(frm) or 0)
        if quoted>0:
            return round(1.0/quoted, 10)
    except Exception:
        pass
    return None

_FX_CACHE = {}        # (from, to, date) -> rate; dated reference rates never change
_FX_FAIL = {}         # (from, to, date) -> monotonic time of last failed lookup
_FX_FAIL_TTL = 60     # seconds before a failed lookup is retried
_FX_LOCK = threading.Lock()

def historical_fx_rate(from_currency, to_currency, transaction_date):
    """Return transaction-date FX in units of to_currency per from_currency.

    Frankfurter provides dated reference rates. For weekends/holidays (and for
    today, before the daily fixing is published) its date endpoint returns the
    latest available rate on or before the requested date.

    Successful lookups are cached for the life of the process, because a dated
    reference rate never changes. Failures are cached briefly so a dashboard
    refresh while offline does not hammer the API once per transaction.
    """
    frm=str(from_currency).upper(); to=str(to_currency).upper()
    if frm in ('RM',): frm='MYR'
    if frm in ('RP',): frm='IDR'
    if frm == to: return 1.0
    try:
        day=date.fromisoformat(str(transaction_date)[:10]).isoformat()
    except (TypeError, ValueError):
        return None
    key=(frm,to,day)
    with _FX_LOCK:
        if key in _FX_CACHE: return _FX_CACHE[key]
        failed=_FX_FAIL.get(key)
        if failed is not None and time.monotonic()-failed < _FX_FAIL_TTL: return None
    url=f"https://api.frankfurter.dev/v1/{day}?from={frm}&to={to}"
    try:
        req=Request(url,headers={'User-Agent':'MilesTracker/47.0'})
        obj=json.loads(urlopen(req,timeout=10).read().decode('utf-8','ignore'))
        rate=float((obj.get('rates') or {}).get(to) or 0)
    except Exception:
        rate=0.0
    with _FX_LOCK:
        if rate > 0:
            _FX_CACHE[key]=rate; _FX_FAIL.pop(key,None); return rate
        _FX_FAIL[key]=time.monotonic()
    return None

def maybank_spend_sgd(tx):
    """Return a Maybank transaction's SGD-equivalent spend.

    Never treat a foreign-currency amount as SGD. Older records may not have
    an FX snapshot; those are handled by the F&F recalculation/migration path.
    """
    card=str(tx.get('card_id') or ''); currency=str(tx.get('currency') or 'SGD').upper(); amount=float(tx.get('amount') or 0)
    if not card.startswith('maybank_') or currency in ('SGD','S$',''): return amount
    posted=tx.get('posted_amount_sgd')
    if posted is not None and float(posted)>=0: return float(posted)
    sgd=tx.get('spend_sgd')
    if sgd is not None and float(sgd)>=0: return float(sgd)
    rate=tx.get('fx_rate')
    if rate is not None and float(rate)>0: return amount*float(rate)
    # Do not silently interpret MYR/IDR as SGD. A missing FX value is an
    # unresolved foreign transaction, not an SGD transaction.
    return 0.0

FX_SRC_HISTORICAL='Historical daily FX (Frankfurter)'
FX_SRC_PROVISIONAL='Spot FX (provisional)'

def enrich_maybank_fx(data):
    """Attach an SGD-equivalent to a Maybank transaction at import time.

    Foreign-currency rows are converted with the rate for the TRANSACTION DATE
    (Frankfurter dated endpoint). If that service is unreachable and the
    transaction is recent (<= 7 days old), today's spot rate is stored as a
    clearly-labelled provisional value; the next recalculation replaces it with
    the dated rate. Older transactions never fall back to spot.
    """
    card=str(data.get('card_id') or ''); currency=str(data.get('currency') or 'SGD').upper(); amount=float(data.get('amount') or 0)
    if not card.startswith('maybank_') or currency in ('SGD','S$',''):
        data.update(spend_sgd=amount,fx_rate=1.0,fx_source='same-currency',fx_updated_at=sg_now().isoformat()); return data
    if data.get('posted_amount_sgd') is not None: return data
    tx_date=str(data.get('transaction_date') or sg_today().isoformat())[:10]
    rate=historical_fx_rate(currency,'SGD',tx_date)
    source=FX_SRC_HISTORICAL
    if not rate:
        try: age=(sg_today()-date.fromisoformat(tx_date)).days
        except ValueError: age=9999
        if age<=7:
            rate=google_spot_rate(currency,'SGD'); source=FX_SRC_PROVISIONAL
    if rate:
        data.update(fx_rate=rate,spend_sgd=round(amount*rate,2),fx_source=source,fx_updated_at=sg_now().isoformat())
    else:
        data.update(fx_rate=None,spend_sgd=None,fx_source='FX unavailable',fx_updated_at=sg_now().isoformat())
    return data

def parse_maybank_email(body, c=None):
    """Parse Maybank Singapore card SMS/email alerts.

    The normal format is:
      Your Maybank Card ending 8003 was used at GUARDIAN-MSJB-8581
      on 03/10/26 for MYR104.40. If unauthorised, ...

    Gmail forwarding can change MIME/HTML wrapping, so try both the original
    message and the extracted display body.  The parser deliberately searches
    for the transaction pattern rather than requiring an exact MIME layout.
    """
    if not body:
        return None

    # Keep several representations.  This makes manual reprocessing resilient
    # when Gmail has wrapped the SMS in HTML, multipart/alternative, or a
    # forwarded-message container.
    candidates = []
    raw = str(body)
    candidates.append(raw)
    try:
        candidates.append(extract_message_body(raw))
    except Exception:
        pass

    texts = []
    for candidate in candidates:
        if not candidate:
            continue
        try:
            parsed_text = BeautifulSoup(candidate, 'html.parser').get_text(' ', strip=True)
        except Exception:
            parsed_text = str(candidate)
        parsed_text = html.unescape(parsed_text)
        parsed_text = re.sub(r'\s+', ' ', parsed_text).strip()
        if parsed_text and parsed_text not in texts:
            texts.append(parsed_text)

    for text in texts:
        # Refund alerts have a different Maybank SMS format from purchase alerts.
        # Store the refund as a negative transaction so dashboard/card spend is
        # reduced and the transaction remains visible in the Transactions tab.
        refund = re.search(
            r'A\s+refund\s+of\s+(SGD|MYR|IDR|S\$|RM|Rp)\s*([0-9,]+(?:\.[0-9]{1,2})?)'
            r'\s+from\s+(.+?)\s+was\s+made\s+to\s+your\s+Maybank\s+Card\s+ending\s*[:#\-]?\s*(\d{4})'
            r'\s+on\s+(\d{1,2})\s*/\s*(\d{1,2})\s*/\s*(\d{2,4})',
            text, re.I
        )
        if refund:
            currency, amount_s, merchant, last4, d, mo, y = refund.groups()
            y = int(y)
            if y < 100: y += 2000
            try: tx_date=date(y,int(mo),int(d)).isoformat()
            except ValueError: continue
            own_conn = c is None
            if own_conn: c=db()
            try:
                card_id=card_id_for_last4(c,last4) or ''
                merchant=re.sub(r'\s+',' ',html.unescape(merchant)).strip()[:160]
                data={
                    'merchant':merchant,
                    'amount':-float(amount_s.replace(',','')),
                    'currency':('MYR' if currency.upper() in ('MYR','RM') else 'IDR' if currency.upper() in ('IDR','RP') else 'SGD'),
                    'transaction_date':tx_date,
                    'posted_date':tx_date,
                    'card_id':card_id,
                    'last4':last4,
                    'transaction_channel':'unknown',
                    'summary':text[:1000],
                    'transaction_time':'',
                    'is_refund':True,
                }
                return enrich_maybank_fx(data)
            finally:
                if own_conn: c.close()

        # Maybank's wording is stable, but allow harmless punctuation/spacing
        # around the last-4 and across HTML line breaks.
        m = re.search(
            r'Your\s+Maybank\s+Card\s+ending\s*[:#\-]?\s*(\d{4})'
            r'\s+was\s+used\s+at\s+(.+?)'
            r'\s+on\s+(\d{1,2})\s*/\s*(\d{1,2})\s*/\s*(\d{2,4})'
            r'\s+for\s+(SGD|MYR|IDR|S\$|RM|Rp)\s*([0-9,]+(?:\.\d{1,2})?)',
            text, re.I
        )
        if not m:
            continue

        last4, merchant, d, mo, y, currency, amount_s = m.groups()
        y = int(y)
        if y < 100:
            y += 2000
        try:
            tx_date = date(y, int(mo), int(d)).isoformat()
        except ValueError:
            continue

        own_conn = c is None
        if own_conn:
            c = db()
        try:
            card_id = card_id_for_last4(c, last4) or ''
            merchant = re.sub(r'\s+', ' ', html.unescape(merchant)).strip()
            # Stop at any accidental HTML/forwarded-message boundary.
            merchant = re.split(r'\s+(?:If\s+unauthorised|If\s+you\s+did\s+not|Thank\s+you)\b', merchant, flags=re.I)[0].strip()
            if not merchant:
                continue
            data = {
                'merchant': merchant[:160],
                'amount': float(amount_s.replace(',', '')),
                'currency': ('MYR' if currency.upper() in ('MYR', 'RM') else
                             'IDR' if currency.upper() in ('IDR', 'RP') else 'SGD'),
                'transaction_date': tx_date,
                'posted_date': tx_date,
                'card_id': card_id,
                'last4': last4,
                'transaction_channel': 'unknown',
                'summary': text[:1000],
                'transaction_time': '',
            }
            return enrich_maybank_fx(data)
        finally:
            if own_conn:
                c.close()
    return None

def parse_email(body, c=None):
    maybank=parse_maybank_email(body, c)
    if maybank:return maybank
    trust=parse_trust_email(body)
    if trust:return trust
    citi=parse_citi_email(body)
    if citi:return citi
    text=re.sub(r'\s+',' ',BeautifulSoup(body,'html.parser').get_text(' ',strip=True)); amount=0
    for p in [r'(?:SGD|S\$)\s*([0-9,]+\.\d{2})',r'\$\s*([0-9,]+\.\d{2})']:
        m=re.search(p,text,re.I)
        if m: amount=float(m.group(1).replace(',',''));break
    dm=re.search(r'\b(\d{1,2})[/-](\d{1,2})[/-](20\d{2})\b',text); tx_date=sg_today().isoformat()
    if dm:
        d,m,y=map(int,dm.groups());tx_date=date(y,m,d).isoformat()
    low=text.lower(); card='citi_rewards' if 'citi' in low and 'reward' in low else ''
    last4=(re.findall(r'(?:ending|ends|card)\D{0,12}(\d{4})',text,re.I) or [''])[-1]; merchant='Unknown merchant'
    # Never use a generic 'from ...' pattern here: email headers commonly
    # contain 'From: mail-sor-f41.google.com', which is not a merchant.
    for p in [
        r'(?:merchant|description|transaction)\s*[:\-]\s*([^|;]+?)(?:\s+(?:amount|date|card|reference)\s*[:\-]|$)',
        r'(?:spent\s+at|charged\s+at|purchase\s+at)\s+([A-Z0-9][A-Z0-9 &._\-]{2,100}?)(?=\s+(?:on|for|amount)\b|$)',
    ]:
        m=re.search(p,text,re.I)
        if m:
            candidate=m.group(1).strip()
            if not re.search(r'(?:google\.com|googleusercontent\.com|mail-sor-|Received:|Return-Path:|@)', candidate, re.I):
                merchant=candidate
                break
    return {'merchant':merchant[:160],'amount':amount,'currency':'SGD','transaction_date':tx_date,'posted_date':tx_date,'card_id':card,'last4':last4,'transaction_channel':'unknown','summary':text[:1000]}

def card_statement_day(c, card_id, default=1):
    r=c.execute('SELECT statement_day FROM card_settings WHERE card_id=?',(card_id,)).fetchone()
    try: return int(r['statement_day']) if r and r['statement_day'] else default
    except (TypeError,ValueError): return default

def citi_cycle_bounds(posted_date, statement_day=20):
    """Inclusive Citi statement-cycle dates based on POSTED date.

    For a statement boundary on the 20th, a cycle runs from the 20th
    (inclusive) through the 19th of the following month (inclusive).
    """
    d = date.fromisoformat(posted_date)
    sd = max(1, min(int(statement_day), 28))
    if d.day >= sd:
        start = d.replace(day=sd)
        nm = d.replace(day=28) + timedelta(days=4)
        nm = nm.replace(day=1)
        end = nm.replace(day=sd) - timedelta(days=1)
    else:
        pm = d.replace(day=1) - timedelta(days=1)
        start = pm.replace(day=sd)
        end = d.replace(day=sd) - timedelta(days=1)
    return start.isoformat(), end.isoformat()

def citi_cycle_label(tx_date, statement_day=20):
    start,end=citi_cycle_bounds(tx_date,statement_day)
    return f'{start} to {end}'


def classify_citi(tx):
    mcc=tx.get('mcc'); ch=tx.get('transaction_channel') or 'unknown'
    if not mcc:return False,'BASE / MCC UNKNOWN'
    if mcc in CITI_SHOPPING_MCC:return True,'10X / SHOPPING MCC'
    if ch=='online' and mcc not in CITI_TRAVEL_MCC:return True,'10X / ONLINE'
    return False,'BASE'

def calendar_month(dstr):
    """YYYY-MM from transaction_date."""
    if not dstr: return ''
    return str(dstr)[:7]

def month_spend(c, card_id, month, exclude_id=None):
    q="SELECT * FROM transactions WHERE card_id=? AND transaction_date LIKE ?"; params=[card_id,month+'%']
    if exclude_id: q += " AND id <> ?"; params.append(exclude_id)
    return sum(maybank_spend_sgd(dict(r)) if str(card_id).startswith('maybank_') else float(r['amount'] or 0) for r in c.execute(q,tuple(params)).fetchall())

def month_bonus_cashback(c, card_id, month, exclude_id=None):
    """Sum of cashback already awarded at bonus rates this month (approx via reward_status)."""
    q = "SELECT COALESCE(SUM(cashback),0) s FROM transactions WHERE card_id=? AND transaction_date LIKE ? AND (reward_status LIKE '5%%' OR reward_status LIKE '6%%' OR reward_status LIKE '8%%' OR reward_status LIKE '4%%')"
    params = [card_id, month + '%']
    if exclude_id:
        q += " AND id <> ?"
        params.append(exclude_id)
    return float(c.execute(q, tuple(params)).fetchone()['s'] or 0)

def month_cat_bonus_cashback(c, card_id, month, cat_label, exclude_id=None):
    q = "SELECT COALESCE(SUM(cashback),0) s FROM transactions WHERE card_id=? AND transaction_date LIKE ? AND reward_status LIKE ?"
    params = [card_id, month + '%', f'%{cat_label}%']
    if exclude_id:
        q += " AND id <> ?"
        params.append(exclude_id)
    return float(c.execute(q, tuple(params)).fetchone()['s'] or 0)

def fnf_preferred_categories(c):
    raw = get_setting(c, 'fnf_preferred_categories', '')
    if raw:
        cats = [x.strip() for x in raw.split('|') if x.strip() in FNF_MCC]
        if len(cats) == 5:
            return cats
    return list(FNF_DEFAULT_PREFERRED)

def fnf_category_for_mcc(mcc):
    if mcc is None:
        return None
    try:
        mcc = int(mcc)
    except (TypeError, ValueError):
        return None
    for name, codes in FNF_MCC.items():
        if mcc in codes:
            return name
    return None

def fnf_category_for_tx(tx):
    """Return the F&F cashback category for a transaction under the 2026 T&Cs.

    Online Shopping requires the transaction to be an online transaction as well
    as having one of the eligible MCCs. Other categories are MCC-driven.
    """
    cat = fnf_category_for_mcc(tx.get('mcc'))
    if cat == 'Online Shopping' and (tx.get('transaction_channel') or 'unknown') != 'online':
        return None
    return cat


def xl_bonus_category(mcc, currency=None):
    """Return category name if eligible for 5% bonus, else None. Foreign Spend = non-SGD currency."""
    if currency and str(currency).upper() not in ('SGD', 'S$', ''):
        return 'Foreign Spend'
    if mcc is None:
        return None
    try:
        mcc = int(mcc)
    except (TypeError, ValueError):
        return None
    for name, codes in XL_MCC.items():
        if mcc in codes:
            return name
    return None

def round_down_cents(value):
    """Round cashback down to two decimal places, as required by Maybank."""
    import math
    return math.floor((float(value) + 1e-9) * 100) / 100


def xl_transaction_excluded(tx):
    """Return True for transactions excluded by the Maybank XL Cashback T&Cs."""
    amount = float(tx.get('amount') or 0)
    if amount <= 0:
        # Clause 5.2: refunded purchases/reversals are not counted in cashback calculations.
        return True
    try:
        mcc = int(tx.get('mcc')) if tx.get('mcc') is not None else None
    except (TypeError, ValueError):
        mcc = None
    if mcc in XL_EXCLUDED_MCC:
        return True
    merchant = str(tx.get('merchant') or '').strip().upper()
    if merchant.startswith(XL_EXCLUDED_MERCHANT_PREFIXES):
        return True
    # Textual exclusions stated in clause 5.6.
    if any(term in merchant for term in ('AXS', 'SAM PAYMENT', 'SAM ONLINE')):
        return True
    return False


def xl_month_eligible_spend(c, card_id, month, exclude_id=None):
    q = "SELECT * FROM transactions WHERE card_id=? AND transaction_date LIKE ?"
    params = [card_id, month + '%']
    if exclude_id:
        q += ' AND id <> ?'
        params.append(exclude_id)
    total = 0.0
    for row in c.execute(q, tuple(params)).fetchall():
        tx = dict(row)
        if not xl_transaction_excluded(tx) and tx.get('mcc') is not None and int(tx['mcc']) != 6300:
            total += maybank_spend_sgd(tx)
        elif not xl_transaction_excluded(tx) and tx.get('mcc') is None:
            total += maybank_spend_sgd(tx)
    return total


def xl_bonus_cashback_before(c, tx):
    """Return bonus cashback already allocated to earlier XL transactions in this month."""
    month = calendar_month(tx.get('transaction_date'))
    tx_date = str(tx.get('transaction_date') or '')
    tx_time = str(tx.get('transaction_time') or '')
    tx_id = int(tx.get('id') or 0)
    rows = c.execute(
        "SELECT * FROM transactions WHERE card_id='maybank_xl_rewards' AND transaction_date LIKE ? ORDER BY transaction_date, COALESCE(transaction_time,''), id",
        (month + '%',)
    ).fetchall()
    total = 0.0
    for row in rows:
        row_date = str(row['transaction_date'] or '')
        row_time = str(row['transaction_time'] or '')
        row_id = int(row['id'] or 0)
        if (row_date, row_time, row_id) >= (tx_date, tx_time, tx_id):
            continue
        status = str(row['reward_status'] or '')
        if status.startswith('5% PARTIAL'):
            # A partial row consumes the remainder of the S$80 bonus cap;
            # its cashback field also includes base cashback on the residual spend.
            total = 80.0
        elif status.startswith('5%'):
            total += min(round_down_cents(maybank_spend_sgd(dict(row)) * 0.05), float(row['cashback'] or 0))
    return total


def recalc_xl_month(c, month):
    """Recompute XL rows in date order so the S$500 threshold and S$80 cap stay consistent."""
    rows = c.execute(
        "SELECT * FROM transactions WHERE card_id='maybank_xl_rewards' AND transaction_date LIKE ? ORDER BY transaction_date, COALESCE(transaction_time,''), id",
        (month + '%',)
    ).fetchall()
    for row in rows:
        tx = dict(row)
        miles, cash, status = calc_reward(tx, c, include_self=True)
        c.execute('UPDATE transactions SET miles=?,cashback=?,reward_status=? WHERE id=?',
                  (miles, cash, status, row['id']))
    return len(rows)


def recalc_all_xl_months(c):
    months = [r['month'] for r in c.execute(
        "SELECT DISTINCT substr(transaction_date,1,7) AS month FROM transactions WHERE card_id='maybank_xl_rewards' AND transaction_date IS NOT NULL AND transaction_date<>''"
    ).fetchall()]
    return sum(recalc_xl_month(c, month) for month in months)


def calc_reward(tx, c, include_self=False):
    amount = float(tx.get('amount') or 0)
    if amount < 0 or tx.get('is_refund'):
        return 0.0, 0.0, 'REFUND'
    mcc = tx.get('mcc')
    card = tx.get('card_id')
    currency = tx.get('currency') or 'SGD'
    miles = cash = 0.0
    status = 'BASE'
    exclude_id = tx.get('id') if include_self else None
    month = calendar_month(tx.get('transaction_date'))

    if card == 'citi_rewards':
        eligible, label = classify_citi(tx)
        whole = int(amount)
        if eligible and whole > 0:
            statement_day = card_statement_day(c, 'citi_rewards', 20)
            posted_date = (tx.get('posted_date') or tx.get('transaction_date'))
            cycle_start, cycle_end = citi_cycle_bounds(posted_date, statement_day)
            params = [cycle_start, cycle_end]
            q = "SELECT COALESCE(SUM(CASE WHEN reward_status LIKE '10X%' OR reward_status='CAP-PARTIAL' THEN CAST(amount AS INTEGER) ELSE 0 END),0) used FROM transactions WHERE card_id='citi_rewards' AND COALESCE(NULLIF(posted_date,''), transaction_date) BETWEEN ? AND ?"
            if exclude_id:
                q += ' AND id <> ?'
                params.append(exclude_id)
            used = int(c.execute(q, tuple(params)).fetchone()['used'] or 0)
            bonus = max(0, min(whole, 1000 - used))
            miles = (whole + 9 * bonus) / 2.5
            status = label if bonus == whole else ('CAP-PARTIAL' if bonus > 0 else 'BASE / 10X CAP USED')
        else:
            miles = whole / 2.5
            status = label

    elif card == 'maybank_xl_rewards':
        amount = maybank_spend_sgd(tx)
        cat = xl_bonus_category(mcc, currency)
        if xl_transaction_excluded(tx):
            cash = 0.0
            status = 'EXCLUDED / NO CASHBACK'
        elif mcc is not None and int(mcc) == 6300:
            # Etiqa is explicitly excluded from minimum spend and receives base only.
            cash = round_down_cents(amount * 0.002)
            status = '0.2% / ETIQA'
        else:
            spend_for_threshold = xl_month_eligible_spend(c, card, month, exclude_id) + amount
            if not cat or spend_for_threshold < 500:
                cash = round_down_cents(amount * 0.002)
                status = f'0.2% / {"BASE" if not cat else cat + " (min spend)"}'
            else:
                bonus_so_far = xl_bonus_cashback_before(c, tx)
                room = max(0.0, 80.0 - bonus_so_far)
                raw_bonus = round_down_cents(amount * 0.05)
                if room <= 0:
                    cash = round_down_cents(amount * 0.002)
                    status = f'0.2% / CAP USED ({cat})'
                elif raw_bonus <= room:
                    cash = raw_bonus
                    status = f'5% / {cat}'
                else:
                    # Allocate remaining bonus cap, then base cashback on the balance.
                    bonus_part = round_down_cents(room)
                    amount_at_bonus = min(amount, bonus_part / 0.05)
                    base_part = max(0.0, amount - amount_at_bonus)
                    cash = round_down_cents(bonus_part + base_part * 0.002)
                    status = f'5% PARTIAL / {cat}'

    elif card == 'maybank_fnf':
        amount = maybank_spend_sgd(tx)
        # F&F T&Cs effective 1 Jan 2026:
        # < $800: 0.22% all
        # $800–$1599.99: 6% on 5 preferred + MYR/IDR, $20/cat cap ($120 total); Groceries max 6%
        # $1600+: 8% (Groceries still 6%), $30/cat cap ($180 total)
        preferred = fnf_preferred_categories(c)
        cat = fnf_category_for_tx(tx)
        is_myr_idr = str(currency).upper() in ('MYR', 'IDR', 'RM', 'RP')
        spend_for_threshold = month_spend(c, card, month, exclude_id) + amount

        if spend_for_threshold < 800:
            cash = amount * 0.0022
            status = '0.22% / BASE'
        else:
            tier2 = spend_for_threshold >= 1600
            rate = 0.08 if tier2 else 0.06
            cap_per = 30.0 if tier2 else 20.0
            # Eligible for bonus if preferred category OR MYR/IDR (bonus category)
            bonus_eligible = False
            cat_label = None
            if cat and cat in preferred:
                bonus_eligible = True
                cat_label = cat
                if cat == 'Groceries':
                    rate = 0.06  # groceries capped at 6% even in Tier 2
            elif is_myr_idr:
                bonus_eligible = True
                cat_label = 'MYR/IDR'
            if bonus_eligible and cat_label:
                used_cat = month_cat_bonus_cashback(c, card, month, cat_label, exclude_id)
                room = max(0.0, cap_per - used_cat)
                raw = amount * rate
                if room <= 0:
                    cash = amount * 0.0022
                    status = f'0.22% / CAP ({cat_label})'
                elif raw <= room:
                    cash = raw
                    pct = int(rate * 100)
                    status = f'{pct}% / {cat_label}'
                else:
                    at_bonus = room
                    rest_amt = amount - (room / rate)
                    cash = at_bonus + max(0, rest_amt) * 0.0022
                    status = f'{int(rate*100)}% PARTIAL / {cat_label}'
            else:
                cash = amount * 0.0022
                status = '0.22% / OTHER'

    elif card == 'trust_freedom':
        # Trust's Freedom card supports multiple reward modes. For email-imported
        # transactions, use the cashback amount explicitly stated by Trust in the alert.
        if tx.get('email_cashback') is not None:
            cash = float(tx.get('email_cashback') or 0)
            status = 'TRUST EMAIL ESTIMATE'
        else:
            cash = 0.0
            status = 'TRUST / REWARD ESTIMATE NOT PROVIDED'

    return round(miles, 2), round(cash, 2), status


def refresh_fnf_fx_snapshots(c, month=None, force=False):
    """Populate / repair foreign F&F FX snapshots (MYR/IDR -> SGD).

    Each foreign transaction is converted with the reference rate for its own
    transaction date. A row is (re)fetched when it has no valid snapshot, when
    the snapshot is provisional/legacy (not a dated Frankfurter rate), or when
    force=True (used by one-off migrations). Rows that already carry a valid
    dated rate are left alone: a dated reference rate never changes, so
    refetching them on every dashboard load only slows the app down.

    Posted SGD amounts and explicitly manual FX remain authoritative. Failed
    lookups never fall back to the foreign face amount as SGD.
    """
    sql = ("SELECT * FROM transactions WHERE card_id='maybank_fnf' "
           "AND UPPER(COALESCE(currency,'SGD')) NOT IN ('SGD','S$','')")
    params = ()
    if month:
        sql += " AND transaction_date LIKE ?"; params = (month + '%',)
    rows = c.execute(sql, params).fetchall()
    changed = 0
    for r in rows:
        tx = dict(r)
        if tx.get('posted_amount_sgd') is not None:
            continue
        source = str(tx.get('fx_source') or '').strip().lower()
        if source == 'manual':
            continue
        has_valid = (tx.get('spend_sgd') is not None and tx.get('fx_rate') is not None
                     and float(tx.get('fx_rate') or 0) > 0 and float(tx.get('fx_rate')) != 1.0)
        if has_valid and source == FX_SRC_HISTORICAL.lower() and not force:
            continue
        currency = str(tx.get('currency') or '').upper()
        tx_date = str(tx.get('transaction_date') or '')[:10]
        rate = historical_fx_rate(currency, 'SGD', tx_date)
        amount = float(tx.get('amount') or 0)
        if rate and rate > 0:
            spend = round(amount * rate, 2)
            c.execute(
                "UPDATE transactions SET spend_sgd=?,fx_rate=?,fx_source=?,fx_updated_at=? WHERE id=?",
                (spend, rate, FX_SRC_HISTORICAL, sg_now().isoformat(), r['id'])
            )
            changed += 1
        else:
            old_rate = float(tx.get('fx_rate') or 0)
            old_spend = tx.get('spend_sgd')
            # A foreign transaction at 1:1 marked same-currency is the known
            # bad legacy shape. Clear it when no reliable quote exists.
            suspect = source in ('same-currency', '') and old_rate in (0.0, 1.0)
            if suspect and (old_rate != 0.0 or old_spend is not None or source != 'fx unavailable'):
                c.execute(
                    "UPDATE transactions SET spend_sgd=NULL,fx_rate=NULL,fx_source='FX unavailable',fx_updated_at=? WHERE id=?",
                    (sg_now().isoformat(), r['id'])
                )
                changed += 1
    return changed


def recalc_fnf_month(c, month):
    """Authoritatively recalculate every F&F transaction in one calendar month.

    2026 T&C model:
      * < S$800 total eligible monthly spend -> 0.22% base.
      * S$800-S$1,599.99 -> 6% on the five selected categories + MYR/IDR bonus,
        subject to S$20 cashback per category/bonus bucket.
      * >= S$1,600 -> 8% on those buckets, S$30 cap; Groceries remains 6%.
      * For MYR/IDR transactions that also belong to a selected category, only
        the portion after the category's Repeat Categories allowance becomes
        MYR/IDR bonus spend. The allowance is denominated in SGD: S$333.34 at
        Tier 1, S$375 at Tier 2, S$500 for Groceries.

    All calculations are done in SGD internally. Foreign-currency transactions
    are converted using their posted SGD amount first, then stored FX snapshot,
    then a fetched spot rate if necessary. A foreign face value is NEVER used
    as if it were SGD.
    """
    rows = c.execute(
        "SELECT * FROM transactions WHERE card_id='maybank_fnf' AND transaction_date LIKE ? ORDER BY transaction_date, id",
        (month + '%',)
    ).fetchall()
    if not rows:
        return 0

    # Refresh old/stale Google Finance snapshots first. Manual FX and posted SGD
    # values remain untouched.
    refresh_fnf_fx_snapshots(c, month)
    rows = c.execute(
        "SELECT * FROM transactions WHERE card_id='maybank_fnf' AND transaction_date LIKE ? ORDER BY transaction_date, id",
        (month + '%',)
    ).fetchall()
    prepared = []
    fx_cache = {}
    for r in rows:
        tx = dict(r)
        currency = str(tx.get('currency') or 'SGD').upper()
        if currency not in ('SGD', 'S$', ''):
            # Refresh helper has already populated normal foreign rows. If the
            # network was unavailable, leave the transaction unresolved rather
            # than ever treating its foreign face value as SGD.
            if tx.get('posted_amount_sgd') is None and str(tx.get('fx_source') or '').lower() != 'manual' and (tx.get('spend_sgd') is None or tx.get('fx_rate') is None):
                fx_key = (currency, str(tx.get('transaction_date') or '')[:10])
                if fx_key not in fx_cache:
                    fx_cache[fx_key] = historical_fx_rate(currency, 'SGD', fx_key[1])
                rate = fx_cache[fx_key]
                if rate and rate > 0:
                    tx['fx_rate'] = rate
                    tx['spend_sgd'] = round(float(tx.get('amount') or 0) * rate, 2)
                    tx['fx_source'] = FX_SRC_HISTORICAL
                    tx['fx_updated_at'] = sg_now().isoformat()
                    c.execute("UPDATE transactions SET spend_sgd=?,fx_rate=?,fx_source=?,fx_updated_at=? WHERE id=?", (tx['spend_sgd'], rate, tx['fx_source'], tx['fx_updated_at'], r['id']))
        else:
            # Repair old SGD rows whose FX fields were never populated.
            if tx.get('spend_sgd') is None or tx.get('fx_rate') is None:
                tx['spend_sgd'] = float(tx.get('amount') or 0)
                tx['fx_rate'] = 1.0
                tx['fx_source'] = 'same-currency'
                tx['fx_updated_at'] = sg_now().isoformat()
                c.execute("UPDATE transactions SET spend_sgd=?,fx_rate=?,fx_source=?,fx_updated_at=? WHERE id=?", (tx['spend_sgd'], 1.0, tx['fx_source'], tx['fx_updated_at'], r['id']))
        prepared.append(tx)

    # Use only valid SGD-equivalent spend. If a foreign transaction has no FX,
    # it cannot inflate or distort the S$800/S$1,600 threshold.
    total_spend = sum(maybank_spend_sgd(tx) for tx in prepared)
    tier2 = total_spend >= 1600.0
    bonus_enabled = total_spend >= 800.0
    rate_default = 0.08 if tier2 else 0.06
    cap_per = 30.0 if tier2 else 20.0

    preferred = fnf_preferred_categories(c)
    base_rate = 0.0022
    used_cashback = {}

    def award(amount, bucket, rate, cap):
        if amount <= 0:
            return 0.0, None
        already = used_cashback.get(bucket, 0.0)
        room = max(0.0, cap - already)
        bonus_amount = min(amount, room / rate) if rate > 0 and room > 0 else 0.0
        bonus_cash = bonus_amount * rate
        base_amount = max(0.0, amount - bonus_amount)
        cash = bonus_cash + base_amount * base_rate
        if bonus_amount > 0:
            used_cashback[bucket] = min(cap, already + bonus_cash)
        if bonus_amount <= 0:
            status = f'0.22% / CAP ({bucket})'
        elif base_amount > 0.000001:
            status = f'{int(rate * 100)}% PARTIAL / {bucket}'
        else:
            status = f'{int(rate * 100)}% / {bucket}'
        return cash, status

    for tx in prepared:
        amount = max(0.0, maybank_spend_sgd(tx))
        currency = str(tx.get('currency') or 'SGD').upper()
        cat = fnf_category_for_tx(tx)
        is_myr_idr = currency in ('MYR', 'IDR', 'RM', 'RP')

        if not bonus_enabled:
            cash = amount * base_rate
            status = '0.22% / BASE'
        else:
            allocations = []
            if is_myr_idr and cat and cat in preferred:
                # Allocate foreign-currency spend to its selected F&F category first.
                # Only the portion beyond that category's remaining bonus-cashback cap
                # spills into the separate MYR/IDR bonus bucket.
                cat_rate = 0.06 if cat == 'Groceries' else rate_default
                cat_room = max(0.0, cap_per - used_cashback.get(cat, 0.0))
                cat_amount = min(amount, cat_room / cat_rate) if cat_rate > 0 else 0.0
                spill_amount = max(0.0, amount - cat_amount)
                if cat_amount > 0:
                    allocations.append((cat_amount, cat, cat_rate, cap_per))
                if spill_amount > 0:
                    allocations.append((spill_amount, 'MYR/IDR', rate_default, cap_per))
            elif is_myr_idr:
                # Foreign currency outside selected categories qualifies for MYR/IDR from first dollar.
                allocations.append((amount, 'MYR/IDR', rate_default, cap_per))
            elif cat and cat in preferred:
                cat_rate = 0.06 if cat == 'Groceries' else rate_default
                cat_room = max(0.0, cap_per - used_cashback.get(cat, 0.0))
                cat_amount = min(amount, cat_room / cat_rate) if cat_rate > 0 else 0.0
                spill_amount = max(0.0, amount - cat_amount)
                if cat_amount > 0:
                    allocations.append((cat_amount, cat, cat_rate, cap_per))
                if spill_amount > 0:
                    # SGD transactions do not move into MYR/IDR; excess is base cashback.
                    allocations.append((spill_amount, 'BASE', base_rate, float('inf')))
            else:
                allocations.append((amount, 'BASE', base_rate, float('inf')))

            cash = 0.0
            parts = []
            for part_amount, bucket, rate, cap in allocations:
                if bucket == 'BASE':
                    cash += part_amount * base_rate
                    parts.append('0.22% / OTHER')
                else:
                    part_cash, part_status = award(part_amount, bucket, rate, cap)
                    cash += part_cash
                    if part_status:
                        parts.append(part_status)
            status = ' + '.join(dict.fromkeys(parts)) if parts else '0.22% / BASE'

        c.execute('UPDATE transactions SET cashback=?, reward_status=? WHERE id=?',
                  (round(cash, 2), status, tx['id']))
    return len(prepared)


def recalc_all_fnf_months(c):
    months = [r['month'] for r in c.execute(
        "SELECT DISTINCT substr(transaction_date,1,7) AS month FROM transactions WHERE card_id='maybank_fnf' AND transaction_date IS NOT NULL AND transaction_date<>''"
    ).fetchall()]
    total = 0
    for month in months:
        total += recalc_fnf_month(c, month)
    return total


def effective_mcc(c,merchant,supplied=None):
    if supplied is not None:return int(supplied),'user','HIGH','Manual MCC supplied'
    rule=exact_mcc_rule(c,merchant)
    if rule:return int(rule['mcc']),'user-exact-name','HIGH',rule['note'] or 'Exact merchant-name MCC mapping'
    return None,'unverified','LOW','No MCC mapping yet'

def insert_tx(data, c=None):
    own_conn = c is None
    if own_conn: c=db()
    if str(data.get('card_id') or '').startswith('maybank_'): data=enrich_maybank_fx(data)
    mcc,src,conf,note=effective_mcc(c,data['merchant'],data.get('mcc')); data.update(mcc=mcc,mcc_source=src,mcc_confidence=conf,mcc_note=note,transaction_channel=enforced_transaction_channel(data['merchant'], data.get('transaction_channel')))
    miles,cash,status=calc_reward(data,c)
    cur=c.execute("INSERT INTO transactions(transaction_date,transaction_time,posted_date,merchant,amount,currency,card_id,last4,mcc,mcc_source,mcc_confidence,mcc_note,transaction_channel,email_cashback,miles,cashback,reward_status,raw_summary,created_at,spend_sgd,fx_rate,fx_source,fx_updated_at,posted_amount_sgd) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(data['transaction_date'],data.get('transaction_time',''),data.get('posted_date',data['transaction_date']),data['merchant'],data['amount'],data.get('currency','SGD'),data.get('card_id',''),data.get('last4',''),data['mcc'],data['mcc_source'],data['mcc_confidence'],data['mcc_note'],data['transaction_channel'],data.get('email_cashback'),miles,cash,status,data.get('summary',''),sg_now().isoformat(),data.get('spend_sgd'),data.get('fx_rate'),data.get('fx_source'),data.get('fx_updated_at'),data.get('posted_amount_sgd')))
    rid=cur.lastrowid
    if data.get('card_id') == 'maybank_fnf': recalc_fnf_month(c,calendar_month(data['transaction_date']))
    elif data.get('card_id') == 'maybank_xl_rewards': recalc_xl_month(c,calendar_month(data['transaction_date']))
    c.commit()
    if own_conn: c.close()
    return rid

def recalc_all_for_merchant(c, merchant):
    rule = c.execute("SELECT mcc FROM merchant_mcc_rules WHERE merchant_name=? COLLATE BINARY", (merchant,)).fetchone()
    if not rule:
        return 0
    rows = c.execute("SELECT * FROM transactions WHERE merchant = ? COLLATE BINARY ORDER BY transaction_date, id", (merchant,)).fetchall()
    months = set()
    for row in rows:
        c.execute("UPDATE transactions SET mcc=?,mcc_source='user-exact-name',mcc_confidence='HIGH',mcc_note=? WHERE id=?", (int(rule['mcc']), 'User-confirmed exact merchant-name MCC mapping', row['id']))
        if row['transaction_date']:
            months.add(str(row['transaction_date'])[:7])
        # Recompute the reward fields immediately after the MCC change. Previously
        # non-F&F cards only had their MCC updated, leaving stale reward_status.
        if row['card_id'] != 'maybank_fnf':
            fresh = c.execute('SELECT * FROM transactions WHERE id=?', (row['id'],)).fetchone()
            miles, cash, status = calc_reward(dict(fresh), c, include_self=True)
            c.execute('UPDATE transactions SET miles=?,cashback=?,reward_status=? WHERE id=?', (miles, cash, status, row['id']))
    for month in months:
        if c.execute("SELECT 1 FROM transactions WHERE card_id='maybank_fnf' AND transaction_date LIKE ? LIMIT 1", (month+'%',)).fetchone():
            recalc_fnf_month(c, month)
        if c.execute("SELECT 1 FROM transactions WHERE card_id='maybank_xl_rewards' AND transaction_date LIKE ? LIMIT 1", (month+'%',)).fetchone():
            recalc_xl_month(c, month)
    return len(rows)

def email_config(c):
    return {'enabled':get_setting(c,'email_enabled','0')=='1','host':get_setting(c,'imap_host','imap.gmail.com'),'port':int(get_setting(c,'imap_port','993') or 993),'security':get_setting(c,'imap_security','ssl'),'username':read_secret(c,'imap_username'),'password':read_secret(c,'imap_password'),'mailbox':get_setting(c,'imap_mailbox','INBOX'),'interval':int(get_setting(c,'poll_interval','5') or 5),'last_status':get_setting(c,'email_status','Not configured'),'last_poll':get_setting(c,'last_poll','')}

def connect_imap(cfg):
    """Open IMAP connection only (caller must login if still NONAUTH)."""
    host = (cfg.get('host') or 'imap.gmail.com').strip()
    port = int(cfg.get('port') or 993)
    security = (cfg.get('security') or 'ssl').lower()
    if security == 'ssl':
        m = imaplib.IMAP4_SSL(host, port, timeout=30)
    else:
        m = imaplib.IMAP4(host, port, timeout=30)
        m.starttls()
    return m

def imap_authenticate(m, user, password):
    """Login only if the session is still unauthenticated. Gmail/imaplib can
    already be AUTH (PREAUTH or a prior login), in which case LOGIN is illegal."""
    state = getattr(m, 'state', 'NONAUTH')
    if state in ('AUTH', 'SELECTED'):
        return
    try:
        m.login(user, password)
    except imaplib.IMAP4.error as e:
        msg = str(e)
        # Already authenticated — treat as success
        if getattr(m, 'state', '') in ('AUTH', 'SELECTED'):
            return
        if 'illegal in state AUTH' in msg or 'only allowed in states NONAUTH' in msg:
            return
        raise RuntimeError('IMAP login failed: ' + msg)

def email_debug_content(msg):
    """Return readable email content for parser debugging."""
    plain=[]; html=[]
    try:
        parts = msg.walk() if msg.is_multipart() else [msg]
        for part in parts:
            if part.get_content_disposition() == 'attachment':
                continue
            ctype = part.get_content_type()
            if ctype not in ('text/plain','text/html'):
                continue
            try:
                payload = part.get_content()
            except Exception:
                raw = part.get_payload(decode=True) or b''
                payload = raw.decode(part.get_content_charset() or 'utf-8', errors='replace')
            payload = str(payload).strip()
            if not payload:
                continue
            (plain if ctype == 'text/plain' else html).append(payload)
    except Exception:
        pass
    if plain:
        return '\n\n'.join(plain)[:20000]
    if html:
        text = re.sub(r'<br\s*/?>', '\n', html[0], flags=re.I)
        text = re.sub(r'</(p|div|tr|li|h[1-6])>', '\n', text, flags=re.I)
        text = re.sub(r'<[^>]+>', ' ', text)
        text = re.sub(r'&nbsp;', ' ', text, flags=re.I)
        text = re.sub(r'&amp;', '&', text, flags=re.I)
        text = re.sub(r'&lt;', '<', text, flags=re.I)
        text = re.sub(r'&gt;', '>', text, flags=re.I)
        return re.sub(r'\n{3,}', '\n\n', text).strip()[:20000]
    return msg.as_string()[:20000]

# A single poll lock prevents the background scheduler and manual 'Poll now'
# requests from racing over the same IMAP UIDs / SQLite rows. The event makes
# settings changes wake the scheduler immediately instead of waiting for the old interval.
POLL_LOCK = threading.Lock()
POLL_WAKE = threading.Event()
POLL_THREAD_STARTED = False

def process_mailbox(test_only=False):
    if not POLL_LOCK.acquire(blocking=False):
        if test_only:
            raise RuntimeError('A Gmail poll is already in progress; try again shortly')
        return {'ok': True, 'imported': 0, 'skipped_parse': 0, 'errors': 0, 'already_running': True}
    try:
        return _process_mailbox_unlocked(test_only)
    finally:
        POLL_LOCK.release()


def _process_mailbox_unlocked(test_only=False):
    c = db()
    cfg = email_config(c)
    if not cfg['username'] or not cfg['password']:
        c.close()
        raise RuntimeError('Email username/password not configured')
    m = connect_imap(cfg)
    user = (cfg['username'] or '').strip()
    password = (cfg['password'] or '').replace(' ', '')
    if not user or not password:
        try:
            m.logout()
        except Exception:
            pass
        c.close()
        raise RuntimeError('Email username/password not configured')
    try:
        imap_authenticate(m, user, password)
    except Exception as e:
        try:
            m.logout()
        except Exception:
            pass
        c.close()
        raise RuntimeError(str(e))
    typ, _ = m.select(cfg['mailbox'])
    if typ != 'OK':
        m.logout(); c.close()
        raise RuntimeError(f'Cannot select mailbox {cfg["mailbox"]!r}')
    typ, data = m.uid('search', None, 'ALL')
    if typ != 'OK':
        m.logout(); c.close()
        raise RuntimeError('Mailbox search failed')
    uids = data[0].split()
    new = 0
    errors = 0
    error_samples = []
    skipped_parse = 0
    for rawuid in reversed(uids[-300:]):
        uid = rawuid.decode() if isinstance(rawuid, bytes) else str(rawuid)
        prev = c.execute('SELECT transaction_id, subject, sender FROM processed_emails WHERE uid=?', (uid,)).fetchone()
        if prev and prev['transaction_id'] is not None:
            continue
        typ, msgdata = m.uid('fetch', rawuid, '(RFC822)')
        if typ != 'OK' or not msgdata:
            continue
        raw = next((x[1] for x in msgdata if isinstance(x, tuple)), None)
        if not raw:
            continue
        try:
            msg = BytesParser(policy=policy.default).parsebytes(raw)
        except Exception:
            continue
        subject = str(msg.get('subject', '') or '')
        sender = str(msg.get('from', '') or '')
        message_id = str(msg.get('message-id', '') or '').strip()
        body = msg.as_string()
        debug_content = email_debug_content(msg)
        looks_supported = bool(re.search(r'citi|citibank|trustbank\.sg|trust\s+bank|freedom\s+credit\s+card|sms\s+from\s+maybanksg|your\s+maybank\s+card\s+ending', subject + ' ' + sender + ' ' + body[:3000], re.I))
        try:
            parsed = parse_email(body, c)
        except Exception as e:
            errors += 1
            if len(error_samples) < 3: error_samples.append(str(e)[:180])
            if prev:
                c.execute('DELETE FROM processed_emails WHERE uid=?', (uid,))
                c.commit()
            continue
        if not parsed or not parsed.get('amount'):
            # Only count/report messages that look like one of the supported card alerts.
            # Ordinary Gmail messages are silently marked as skipped and do not pollute
            # the user's 'unparsed' count. Supported-looking messages are persisted so
            # the UI can show exactly which emails need attention.
            if looks_supported:
                skipped_parse += 1
                now = sg_now().isoformat()
                reason = 'No supported transaction pattern matched'
                c.execute(
                    'INSERT INTO email_parse_issues(uid,message_id,received_at,subject,sender,reason,first_seen,last_seen,email_content) VALUES(?,?,?,?,?,?,?,?,?) '
                    'ON CONFLICT(uid) DO UPDATE SET message_id=excluded.message_id,received_at=excluded.received_at,subject=excluded.subject,sender=excluded.sender,reason=excluded.reason,last_seen=excluded.last_seen,email_content=excluded.email_content',
                    (uid, message_id or None, str(msg.get('date', '')), subject, sender, reason, now, now, debug_content),
                )
                c.commit()
            else:
                c.execute(
                    'INSERT INTO processed_emails(uid,message_id,received_at,subject,sender,parser_version,transaction_id,processed_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(uid) DO NOTHING',
                    (uid, message_id or None, str(msg.get('date', '')), subject, sender, 'v21-skip', None, sg_now().isoformat()),
                )
                c.commit()
            if test_only and looks_supported:
                m.logout(); c.close()
                return {'ok': False, 'error': 'Supported card email found but could not parse. Subject: ' + subject[:120]}
            continue
        if test_only:
            m.logout(); c.close()
            return {'ok': True, 'parsed': parsed, 'subject': subject, 'sender': sender}
        if message_id:
            dup = c.execute('SELECT 1 FROM processed_emails WHERE message_id=? AND transaction_id IS NOT NULL', (message_id,)).fetchone()
            if dup:
                c.execute(
                    'INSERT INTO processed_emails(uid,message_id,received_at,subject,sender,parser_version,transaction_id,processed_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(uid) DO UPDATE SET message_id=excluded.message_id',
                    (uid, message_id, str(msg.get('date', '')), subject, sender, 'v3-dup', -1, sg_now().isoformat()),
                )
                c.commit()
                continue
        try:
            rid = insert_tx(parsed, c)
            c.execute('DELETE FROM email_parse_issues WHERE uid=?', (uid,))
        except Exception as e:
            errors += 1
            if len(error_samples) < 3: error_samples.append('insert: ' + str(e)[:180])
            set_setting(c, 'email_status', 'ERROR · insert failed: ' + str(e)[:250])
            c.commit()
            continue
        c.execute(
            'INSERT INTO processed_emails(uid,message_id,received_at,subject,sender,parser_version,transaction_id,processed_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(uid) DO UPDATE SET message_id=excluded.message_id, transaction_id=excluded.transaction_id, processed_at=excluded.processed_at, parser_version=excluded.parser_version',
            (uid, message_id or None, str(msg.get('date', '')), subject, sender, 'v25-citi-trust-maybank-fx-editable-1', rid, sg_now().isoformat()),
        )
        c.commit()
        new += 1
    try:
        m.close()
    except Exception:
        pass
    try:
        m.logout()
    except Exception:
        pass
    status = f'OK · imported {new} new transaction(s)'
    if skipped_parse:
        status += f' · {skipped_parse} unparsed'
    if errors:
        status += f' · {errors} error(s)'
        if error_samples: status += ' · ' + ' | '.join(error_samples)
    set_setting(c, 'last_poll', sg_now().isoformat())
    set_setting(c, 'email_status', status)
    c.commit(); c.close()
    return {'ok': True, 'imported': new, 'skipped_parse': skipped_parse, 'errors': errors, 'error_samples': error_samples}


def poll_loop():
    # Poll immediately on startup, then wait the configured interval. Re-read
    # settings every cycle and wake immediately when Email Settings are saved.
    while True:
        try:
            c = db()
            cfg = email_config(c)
            c.close()
            if cfg['enabled'] and cfg['username'] and cfg['password']:
                try:
                    result = process_mailbox(False)
                    # A busy manual poll is not a failure; its result will update status.
                    if result.get('already_running'):
                        pass
                except Exception as e:
                    c = db()
                    set_setting(c, 'email_status', 'ERROR · ' + str(e)[:300])
                    c.commit()
                    c.close()
            interval_seconds = max(1, int(cfg.get('interval') or 5)) * 60
            POLL_WAKE.wait(timeout=interval_seconds)
            POLL_WAKE.clear()
        except Exception as e:
            try:
                c = db()
                set_setting(c, 'email_status', 'ERROR · polling scheduler: ' + str(e)[:250])
                c.commit()
                c.close()
            except Exception:
                pass
            POLL_WAKE.wait(timeout=30)
            POLL_WAKE.clear()

def repair_unparsed_email_issues(c):
    """Recover supported-card emails that failed under an older parser."""
    repaired = 0
    try:
        rows = c.execute("SELECT uid,email_content FROM email_parse_issues WHERE email_content IS NOT NULL AND email_content<>''").fetchall()
    except Exception:
        return 0
    for row in rows:
        try:
            parsed = parse_email(str(row['email_content']), c)
            if not parsed or not parsed.get('amount'):
                continue
            rid = insert_tx(parsed, c)
            c.execute('DELETE FROM email_parse_issues WHERE uid=?', (row['uid'],))
            c.execute('UPDATE processed_emails SET transaction_id=?, parser_version=?, processed_at=? WHERE uid=?',
                      (rid, 'v25-auto-recovered', sg_now().isoformat(), row['uid']))
            c.commit()
            repaired += 1
        except Exception:
            c.rollback()
    return repaired

@app.on_event('startup')
def startup():
    c=db()
    try:
        repair_malformed_merchants(c)
        repair_maybank_transactions(c)
        # One-time migration: make existing AMAZE* transactions online and refresh their rewards.
        if get_setting(c, 'amaze_online_channel_v1', '') != '1':
            amaze_rows = c.execute("SELECT * FROM transactions WHERE UPPER(TRIM(COALESCE(merchant,''))) LIKE 'AMAZE*%'").fetchall()
            for amaze_row in amaze_rows:
                tx = dict(amaze_row)
                tx['transaction_channel'] = 'online'
                miles, cash, status = calc_reward(tx, c, True)
                c.execute('UPDATE transactions SET transaction_channel=?,miles=?,cashback=?,reward_status=? WHERE id=?', ('online', miles, cash, status, tx['id']))
            set_setting(c, 'amaze_online_channel_v1', '1')
            c.commit()
        # FX migration is idempotent and keeps older Maybank records compatible.
        c.close()
        migrate_fx_fields()
        c = db()
        repair_unparsed_email_issues(c)
    finally:
        c.close()
    global POLL_THREAD_STARTED
    if not POLL_THREAD_STARTED:
        POLL_THREAD_STARTED = True
        threading.Thread(target=poll_loop, name='gmail-auto-poll', daemon=True).start()

@app.get('/',response_class=HTMLResponse)
def home(): return (BASE/'static/index.html').read_text()

def migrate_fx_fields():
    c=db(); done=get_setting(c,'migrate_fx_fields_v1','')
    if done=='1': c.close(); return
    rows=c.execute("SELECT * FROM transactions WHERE card_id LIKE 'maybank_%'").fetchall()
    for r in rows:
        tx=dict(r); cur=str(tx.get('currency') or 'SGD').upper()
        if cur in ('SGD','S$',''):
            c.execute("UPDATE transactions SET spend_sgd=?,fx_rate=1.0,fx_source='same-currency',fx_updated_at=? WHERE id=?",(float(tx.get('amount') or 0),sg_now().isoformat(),r['id']))
        elif tx.get('spend_sgd') is None:
            tx=enrich_maybank_fx(tx); c.execute("UPDATE transactions SET spend_sgd=?,fx_rate=?,fx_source=?,fx_updated_at=? WHERE id=?",(tx.get('spend_sgd'),tx.get('fx_rate'),tx.get('fx_source'),tx.get('fx_updated_at'),r['id']))
    set_setting(c,'migrate_fx_fields_v1','1'); c.commit(); c.close()

def migrate_fnf_fx_v2():
    """Repair foreign Maybank F&F FX data and recalculate rewards once."""
    c = db()
    if get_setting(c, 'migrate_fnf_fx_v2', '') == '1':
        c.close()
        return
    # recalc_fnf_month fetches a current FX rate for foreign rows that have no
    # usable snapshot, then recalculates the whole month.
    recalc_all_fnf_months(c)
    set_setting(c, 'migrate_fnf_fx_v2', '1')
    c.commit()
    c.close()


def migrate_fnf_fx_v45():
    """One-time repair of MYR/IDR face-value-as-SGD snapshots from older builds."""
    c = db()
    if get_setting(c, 'migrate_fnf_fx_v45', '') == '1':
        c.close()
        return
    refresh_fnf_fx_snapshots(c, force=True)
    recalc_all_fnf_months(c)
    set_setting(c, 'migrate_fnf_fx_v45', '1')
    c.commit()
    c.close()


def migrate_fnf_rewards_v30():
    """One-time repair for legacy F&F FX and stale cashback/status values."""
    c = db()
    if get_setting(c, 'migrate_fnf_rewards_v30', '') == '1':
        c.close()
        return
    refresh_fnf_fx_snapshots(c, force=True)
    recalc_all_fnf_months(c)
    set_setting(c, 'migrate_fnf_rewards_v30', '1')
    c.commit()
    c.close()


def migrate_maybank_cashback_rules():
    """Recompute Maybank XL + F&F rewards under current T&C logic (one-shot)."""
    c = db()
    done = get_setting(c, 'migrate_maybank_tnc_v5', '')
    if done == '1':
        c.close()
        return
    # F&F must be recalculated month-wide because the S$800/S$1,600 threshold
    # changes the cashback rate for transactions already imported earlier in the month.
    recalc_all_fnf_months(c)
    recalc_all_xl_months(c)
    set_setting(c, 'migrate_maybank_tnc_v5', '1')
    c.commit()
    c.close()


@app.get('/api/summary')
def summary():
    migrate_fx_fields()
    migrate_fnf_fx_v2()
    migrate_fnf_fx_v45()
    migrate_fnf_rewards_v30()
    migrate_maybank_cashback_rules()
    c=db()
    # F&F cashback and dashboard spend depend on dated FX. Force a month-wide
    # recomputation before fetching rows used for card totals, including legacy
    # rows whose prior FX snapshots were incorrectly stored as 1:1.
    recalc_all_fnf_months(c)
    recalc_all_xl_months(c)
    # Persist the authoritative month-wide Maybank recalculation before returning
    # the transaction rows. Without this commit, SQLite rolls the recalculated
    # cashback/reward_status back when the connection closes, so the UI keeps
    # seeing stale 0.22%/BASE values on the next refresh.
    c.commit()
    rows=c.execute('SELECT * FROM transactions ORDER BY transaction_date DESC,id DESC').fetchall()
    mappings=[dict(r) for r in c.execute('SELECT * FROM merchant_mcc_rules ORDER BY merchant_name COLLATE BINARY').fetchall()]
    total=sum(maybank_spend_sgd(dict(r)) if str(r['card_id'] or '').startswith('maybank_') else float(r['amount'] or 0) for r in rows)
    miles=sum(float(r['miles'] or 0) for r in rows)
    cash=sum(float(r['cashback'] or 0) for r in rows)
    today=sg_today()
    this_month=today.strftime('%Y-%m')
    prev=(today.replace(day=1)-timedelta(days=1)).strftime('%Y-%m')

    def month_rows(month):
        return [r for r in rows if str(r['transaction_date'] or '')[:7]==month]
    def stats_for_rows(rs):
        return {
            'spend':round(sum(maybank_spend_sgd(dict(r)) if str(r['card_id'] or '').startswith('maybank_') else float(r['amount'] or 0) for r in rs),2),
            'count':len(rs),
            'miles':round(sum(float(r['miles'] or 0) for r in rs),2),
            'cashback':round(sum(float(r['cashback'] or 0) for r in rs),2),
            'citi_bonus_points':round(sum(max(0.0,(float(r['miles'] or 0)*2.5)-int(float(r['amount'] or 0))) for r in rs if r['card_id']=='citi_rewards'),2),
        }
    def month_stats(month): return stats_for_rows(month_rows(month))

    by_card=[]
    for cid,meta in CARDS.items():
        cr=[r for r in rows if r['card_id']==cid]
        cur=[r for r in cr if str(r['transaction_date'] or '')[:7]==this_month]
        by_card.append({
            'card_id':cid,
            'spend':round(sum(maybank_spend_sgd(dict(r)) if str(r['card_id'] or '').startswith('maybank_') else float(r['amount'] or 0) for r in cr),2),
            'miles':round(sum(float(r['miles'] or 0) for r in cr),2),
            'cashback':round(sum(float(r['cashback'] or 0) for r in cr),2),
            'count':len(cr),
            'this_month_spend':round(sum(maybank_spend_sgd(dict(r)) if str(r['card_id'] or '').startswith('maybank_') else float(r['amount'] or 0) for r in cur),2),
            'this_month_count':len(cur),
            'this_month_miles':round(sum(float(r['miles'] or 0) for r in cur),2),
            'this_month_cashback':round(sum(float(r['cashback'] or 0) for r in cur),2),
        })
    preferred=fnf_preferred_categories(c)
    email_status=get_setting(c,'email_status','Not configured')
    last_poll=get_setting(c,'last_poll','')
    c.close()
    return {
        'total_spend':round(total,2),
        'miles':round(miles,2),
        'cashback':round(cash,2),
        'count':len(rows),
        'current_month':this_month,
        'previous_month':prev,
        'this_month':month_stats(this_month),
        'previous_month_stats':month_stats(prev),
        'timezone':'Asia/Singapore',
        'utc_offset':'+08:00',
        'server_time':sg_now().strftime('%d %b %Y %H:%M'),
        'email_status':email_status,
        'last_poll':last_poll,
        'by_card':by_card,
        'transactions':[dict(r) for r in rows],
        'mcc_catalog':MCC,
        'merchant_mcc_rules':mappings,
        'fnf_categories':list(FNF_MCC.keys()),
        'fnf_preferred':preferred,
    }

@app.post('/api/ingest-email')
def ingest_email(body:str=Form(...)):
    parsed=parse_email(body)
    if not parsed:return {'ok':False,'error':'Could not parse a supported transaction email'}
    rid=insert_tx(parsed);c=db();row=c.execute('SELECT * FROM transactions WHERE id=?',(rid,)).fetchone();c.close();return {'ok':True,'id':rid,'parsed':dict(row)}


@app.put('/api/transactions/{txid}/mcc')
def update_mcc(txid:int,payload:dict):
    mcc=int(payload.get('mcc',0));
    if mcc<0 or mcc>9999:return {'ok':False,'error':'MCC must be between 0 and 9999'}
    c=db();row=c.execute('SELECT * FROM transactions WHERE id=?',(txid,)).fetchone()
    if not row:c.close();return {'ok':False,'error':'Transaction not found'}
    merchant=row['merchant'];c.execute('INSERT INTO merchant_mcc_rules(merchant_name,mcc,note,source,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(merchant_name) DO UPDATE SET mcc=excluded.mcc,note=excluded.note,source=excluded.source,updated_at=excluded.updated_at',(merchant,mcc,'User-confirmed exact merchant-name MCC mapping','user',sg_now().isoformat()));affected=recalc_all_for_merchant(c,merchant);
    months = [r['month'] for r in c.execute("SELECT DISTINCT substr(transaction_date,1,7) AS month FROM transactions WHERE merchant = ? COLLATE BINARY AND card_id='maybank_fnf'", (merchant,)).fetchall()]
    for month in months: recalc_fnf_month(c, month)
    c.commit();c.close();return {'ok':True,'affected_transactions':affected,'merchant':merchant,'mcc':mcc}

@app.delete('/api/merchant-mcc/{merchant}')
def delete_mapping(merchant:str):
    c=db();rule=exact_mcc_rule(c,merchant);c.execute('DELETE FROM merchant_mcc_rules WHERE merchant_name=? COLLATE BINARY',(merchant,));rows=c.execute('SELECT * FROM transactions WHERE merchant=? COLLATE BINARY',(merchant,)).fetchall()
    for r in rows:
        tx=dict(r);tx['mcc']=None;tx['transaction_channel']=r['transaction_channel'] or 'unknown';miles,cash,status=calc_reward(tx,c,True);c.execute('UPDATE transactions SET mcc=NULL,mcc_source="unverified",mcc_confidence="LOW",mcc_note="No MCC mapping yet",miles=?,cashback=?,reward_status=? WHERE id=?',(miles,cash,status,r['id']))
    c.commit();c.close();return {'ok':True,'removed':bool(rule)}

@app.put('/api/transactions/{txid}/channel')
def update_transaction_channel(txid:int,payload:dict):
    ch=payload.get('transaction_channel','unknown')
    if ch not in {'unknown','online','in_store','mobile_wallet','travel'}:return {'ok':False,'error':'Invalid channel'}
    c=db();row=c.execute('SELECT * FROM transactions WHERE id=?',(txid,)).fetchone()
    if not row:c.close();return {'ok':False,'error':'Transaction not found'}
    tx=dict(row);ch=enforced_transaction_channel(row['merchant'], ch);tx['transaction_channel']=ch
    miles,cash,status=calc_reward(tx,c,True)
    c.execute('UPDATE transactions SET transaction_channel=?,miles=?,cashback=?,reward_status=? WHERE id=?',(ch,miles,cash,status,txid))
    if row['card_id']=='maybank_fnf':
        recalc_fnf_month(c, calendar_month(row['transaction_date']))
    elif row['card_id']=='maybank_xl_rewards':
        recalc_xl_month(c, calendar_month(row['transaction_date']))
    c.commit();c.close();return {'ok':True}

@app.get('/api/fx-rate')
def fx_rate_api(from_currency:str, to_currency:str='SGD', transaction_date:str=''):
    if str(to_currency).upper()!='SGD' or str(from_currency).upper()=='SGD': return {'ok':False,'error':'FX conversion is only available for Maybank foreign-currency transactions into SGD'}
    if transaction_date:
        rate=historical_fx_rate(from_currency,to_currency,transaction_date)
        source='Historical daily FX (Frankfurter)'
    else:
        rate=google_spot_rate(from_currency,to_currency)
        source='Google Finance / fallback spot'
    if not rate: return {'ok':False,'error':'FX rate temporarily unavailable for requested date'}
    return {'ok':True,'from_currency':from_currency.upper(),'to_currency':'SGD','rate':rate,'source':source,'transaction_date':transaction_date or None,'updated_at':sg_now().isoformat()}

@app.put('/api/transactions/{txid}')
def edit_transaction(txid:int,payload:dict):
    c=db(); row=c.execute('SELECT * FROM transactions WHERE id=?',(txid,)).fetchone()
    if not row: c.close(); return {'ok':False,'error':'Transaction not found'}
    tx=dict(row); merchant=str(payload.get('merchant',tx['merchant'])).strip()[:160]
    try: amount=float(payload.get('amount',tx['amount']))
    except (TypeError,ValueError): c.close(); return {'ok':False,'error':'Invalid amount'}
    currency=str(payload.get('currency',tx['currency'] or 'SGD')).upper(); card_id=str(payload.get('card_id',tx['card_id'] or ''))
    if not merchant or amount<0 or card_id not in CARDS: c.close(); return {'ok':False,'error':'Invalid merchant, amount, or card'}
    tx_date=str(payload.get('transaction_date',tx['transaction_date']))
    try: date.fromisoformat(tx_date)
    except ValueError: c.close(); return {'ok':False,'error':'Invalid transaction date'}
    posted_date=str(payload.get('posted_date',tx.get('posted_date') or tx_date) or '')
    if posted_date:
        try: date.fromisoformat(posted_date)
        except ValueError: c.close(); return {'ok':False,'error':'Invalid posted date'}
    posted=payload.get('posted_amount_sgd',tx.get('posted_amount_sgd'))
    if posted in ('',None): posted=None
    else:
        try: posted=float(posted); assert posted>=0
        except Exception: c.close(); return {'ok':False,'error':'Invalid posted SGD amount'}
    tx.update(merchant=merchant,amount=amount,currency=currency,card_id=card_id,transaction_date=tx_date,posted_date=posted_date or None,posted_amount_sgd=posted)
    tx['transaction_channel'] = enforced_transaction_channel(merchant, payload.get('transaction_channel', tx.get('transaction_channel')))
    if card_id.startswith('maybank_') and currency not in ('SGD','S$',''):
        manual=payload.get('fx_rate')
        if manual not in ('',None):
            try: rate=float(manual); assert rate>0
            except Exception: c.close(); return {'ok':False,'error':'Invalid FX rate'}
            tx.update(fx_rate=rate,fx_source='Manual',fx_updated_at=sg_now().isoformat())
        elif posted is None:
            rate=historical_fx_rate(currency,'SGD',tx_date)
            if rate:
                tx.update(fx_rate=rate,fx_source=FX_SRC_HISTORICAL,fx_updated_at=sg_now().isoformat())
            else:
                tx.update(fx_rate=None,spend_sgd=None,fx_source='FX unavailable for transaction date',fx_updated_at=sg_now().isoformat())
        tx['spend_sgd']=posted if posted is not None else (amount*float(tx['fx_rate']) if tx.get('fx_rate') else None)
    else:
        tx.update(spend_sgd=amount,fx_rate=1.0,fx_source='same-currency',fx_updated_at=sg_now().isoformat(),posted_amount_sgd=None)
    supplied=payload.get('mcc',tx.get('mcc')); mcc,src,conf,note=effective_mcc(c,merchant,supplied if supplied not in ('',None) else None); tx.update(mcc=mcc,mcc_source=src,mcc_confidence=conf,mcc_note=note)
    miles,cash,status=calc_reward(tx,c,True)
    c.execute("UPDATE transactions SET transaction_date=?,posted_date=?,merchant=?,amount=?,currency=?,card_id=?,last4=?,mcc=?,mcc_source=?,mcc_confidence=?,mcc_note=?,transaction_channel=?,miles=?,cashback=?,reward_status=?,spend_sgd=?,fx_rate=?,fx_source=?,fx_updated_at=?,posted_amount_sgd=? WHERE id=?",(tx_date,posted_date or None,merchant,amount,currency,card_id,payload.get('last4',tx.get('last4') or ''),mcc,src,conf,note,tx['transaction_channel'],miles,cash,status,tx.get('spend_sgd'),tx.get('fx_rate'),tx.get('fx_source'),tx.get('fx_updated_at'),posted,txid))
    if card_id=='maybank_fnf': recalc_fnf_month(c,tx_date[:7])
    elif card_id=='maybank_xl_rewards': recalc_xl_month(c,tx_date[:7])
    old_month=str(row['transaction_date'] or '')[:7]
    if row['card_id']=='maybank_fnf' and old_month and old_month!=tx_date[:7]: recalc_fnf_month(c,old_month)
    elif row['card_id']=='maybank_xl_rewards' and old_month and old_month!=tx_date[:7]: recalc_xl_month(c,old_month)
    c.commit(); out=c.execute('SELECT * FROM transactions WHERE id=?',(txid,)).fetchone(); c.close(); return {'ok':True,'transaction':dict(out)}

@app.delete('/api/transactions/{txid}')
def delete_transaction(txid:int):
    c=db()
    row=c.execute('SELECT card_id,transaction_date FROM transactions WHERE id=?',(txid,)).fetchone()
    c.execute('DELETE FROM transactions WHERE id=?',(txid,))
    if row and row['card_id']=='maybank_fnf':
        recalc_fnf_month(c, calendar_month(row['transaction_date']))
    elif row and row['card_id']=='maybank_xl_rewards':
        recalc_xl_month(c, calendar_month(row['transaction_date']))
    c.commit(); c.close(); return {'ok':True}

@app.get('/api/fnf-categories')
def get_fnf_categories():
    c = db()
    preferred = fnf_preferred_categories(c)
    c.close()
    return {'all': list(FNF_MCC.keys()), 'preferred': preferred, 'defaults': FNF_DEFAULT_PREFERRED}

@app.put('/api/fnf-categories')
def put_fnf_categories(payload: dict):
    cats = payload.get('preferred') or []
    cats = [str(x).strip() for x in cats if str(x).strip() in FNF_MCC]
    if len(cats) != 5:
        return {'ok': False, 'error': 'Select exactly 5 preferred categories'}
    c = db()
    set_setting(c, 'fnf_preferred_categories', '|'.join(cats))
    # Recalculate month-wide because F&F tier, category caps and Repeat
    # Categories thresholds depend on the entire calendar month.
    recalc_all_fnf_months(c)
    c.commit(); c.close()
    return {'ok': True, 'preferred': cats}

@app.get('/api/cards')
def cards(): return CARDS

@app.get('/api/card-identifiers')
def get_card_identifiers():
    c=db()
    rows=c.execute("SELECT identifier_value, card_id FROM card_identifiers WHERE identifier_type='last4' ORDER BY identifier_value").fetchall()
    c.close()
    return [{'last4':r['identifier_value'],'card_id':r['card_id'],'card_name':CARDS.get(r['card_id'],{}).get('name',r['card_id'])} for r in rows]

@app.put('/api/card-identifiers')
def put_card_identifiers(payload:dict):
    mappings = payload.get('mappings') or []
    c=db()
    try:
        for item in mappings:
            last4=str(item.get('last4','')).strip()
            card_id=str(item.get('card_id','')).strip()
            if not re.fullmatch(r'\d{4}', last4):
                raise ValueError(f'Invalid last 4: {last4}')
            if card_id not in CARDS:
                raise ValueError(f'Unknown card: {card_id}')
            c.execute("INSERT INTO card_identifiers(identifier_type,identifier_value,card_id,updated_at) VALUES('last4',?,?,?) ON CONFLICT(identifier_type,identifier_value) DO UPDATE SET card_id=excluded.card_id,updated_at=excluded.updated_at", ('last4', last4, card_id, sg_now().isoformat()))
        c.commit()
        rows=c.execute("SELECT identifier_value, card_id FROM card_identifiers WHERE identifier_type='last4' ORDER BY identifier_value").fetchall()
        return {'ok':True,'mappings':[{'last4':r['identifier_value'],'card_id':r['card_id'],'card_name':CARDS.get(r['card_id'],{}).get('name',r['card_id'])} for r in rows]}
    except Exception as e:
        c.rollback()
        return {'ok':False,'error':str(e)}
    finally:
        c.close()


@app.get('/api/email-settings')
def get_email_settings():
    c=db();cfg=email_config(c);c.close();return {'enabled':cfg['enabled'],'host':cfg['host'],'port':cfg['port'],'security':cfg['security'],'username':cfg['username'],'password_set':bool(cfg['password']),'mailbox':cfg['mailbox'],'interval':cfg['interval'],'last_status':cfg['last_status'],'last_poll':cfg['last_poll']}

@app.put('/api/email-settings')
def update_email_settings(payload:dict):
    c=db();set_setting(c,'email_enabled','1' if payload.get('enabled') else '0');set_setting(c,'imap_host',str(payload.get('host','imap.gmail.com')).strip() or 'imap.gmail.com');set_setting(c,'imap_port',str(int(payload.get('port',993) or 993)));set_setting(c,'imap_security',payload.get('security','ssl'));set_setting(c,'imap_mailbox',str(payload.get('mailbox','INBOX')).strip() or 'INBOX');set_setting(c,'poll_interval',str(max(1,int(payload.get('interval',5)))))
    if 'username' in payload: save_secret(c,'imap_username',str(payload.get('username','')).strip())
    if payload.get('password'): save_secret(c,'imap_password',str(payload['password']).replace(' ',''))
    set_setting(c,'email_status','Saved. Automatic polling will use these settings.');c.commit();c.close();POLL_WAKE.set();return {'ok':True}

@app.post('/api/email-test')
def email_test():
    try:
        result=process_mailbox(True)
        if not result.get('ok', True):
            return {'ok': False, 'error': result.get('error') or 'Connection or parse failed'}
        return {'ok':True,'message':'Connection and mailbox access succeeded.','preview':result.get('parsed'),'subject':result.get('subject',''),'sender':result.get('sender','')}
    except Exception as e:return {'ok':False,'error':str(e)}


@app.get('/api/email-unparsed')
def email_unparsed():
    c = db()
    rows = c.execute('SELECT uid,message_id,received_at,subject,sender,reason,first_seen,last_seen,email_content FROM email_parse_issues ORDER BY last_seen DESC').fetchall()
    c.close()
    return {'count': len(rows), 'items': [dict(r) for r in rows]}

@app.get('/api/email-unparsed/{uid}')
def email_unparsed_detail(uid: str):
    c = db()
    row = c.execute('SELECT uid,message_id,received_at,subject,sender,reason,first_seen,last_seen,email_content FROM email_parse_issues WHERE uid=?', (uid,)).fetchone()
    if not row:
        c.close()
        return {'ok': False, 'error': 'Unparsed email not found'}
    item = dict(row)
    if not item.get('email_content'):
        try:
            cfg = email_config(c)
            m = connect_imap(cfg)
            imap_authenticate(m, (cfg.get('username') or '').strip(), (cfg.get('password') or '').replace(' ', ''))
            typ, _ = m.select(cfg['mailbox'])
            if typ == 'OK':
                typ, msgdata = m.uid('fetch', str(uid).encode(), '(RFC822)')
                raw = next((x[1] for x in (msgdata or []) if isinstance(x, tuple)), None) if typ == 'OK' else None
                if raw:
                    msg = BytesParser(policy=policy.default).parsebytes(raw)
                    item['email_content'] = email_debug_content(msg)
                    item['subject'] = str(msg.get('subject', '') or item.get('subject') or '')
                    item['sender'] = str(msg.get('from', '') or item.get('sender') or '')
                    c.execute('UPDATE email_parse_issues SET email_content=?,subject=?,sender=? WHERE uid=?', (item['email_content'], item['subject'], item['sender'], uid))
                    c.commit()
            try: m.logout()
            except Exception: pass
        except Exception as e:
            item['content_error'] = 'Could not fetch the email body from Gmail: ' + str(e)[:220]
    c.close()
    return {'ok': True, 'item': item}


@app.post('/api/email-unparsed/{uid}/reprocess')
def email_unparsed_reprocess(uid: str):
    # Reprocess the ORIGINAL RFC822 message where possible. The old implementation
    # reparsed email_debug_content(), which is intended for display and can omit MIME
    # structure/content needed by a bank parser.
    c = db()
    row = c.execute('SELECT * FROM email_parse_issues WHERE uid=?', (uid,)).fetchone()
    if not row:
        c.close(); return {'ok': False, 'error': 'Unparsed email not found'}
    try:
        content = row['email_content'] or ''
        raw_body = None
        cfg = email_config(c)
        try:
            m = connect_imap(cfg)
            imap_authenticate(m, (cfg.get('username') or '').strip(), (cfg.get('password') or '').replace(' ', ''))
            typ, _ = m.select(cfg['mailbox'])
            if typ == 'OK':
                typ, msgdata = m.uid('fetch', str(uid).encode(), '(RFC822)')
                raw_body = next((x[1] for x in (msgdata or []) if isinstance(x, tuple)), None) if typ == 'OK' else None
            try: m.logout()
            except Exception: pass
        except Exception:
            raw_body = None

        if raw_body:
            msg = BytesParser(policy=policy.default).parsebytes(raw_body)
            content = msg.as_string()
            display = email_debug_content(msg)
            c.execute('UPDATE email_parse_issues SET email_content=?,subject=?,sender=?,last_seen=? WHERE uid=?',
                      (display, str(msg.get('subject','') or row['subject'] or ''), str(msg.get('from','') or row['sender'] or ''), sg_now().isoformat(), uid))

        parsed = parse_email(content, c) if content else None
        if not parsed or not parsed.get('amount'):
            c.commit(); c.close()
            return {'ok': False, 'error': 'Parser still could not match this email', 'email_content': content[:20000]}

        # If this message was already imported during a previous retry, reuse the
        # existing transaction instead of creating a duplicate.
        message_id = str(row['message_id'] or '').strip()
        existing = None
        if message_id:
            existing = c.execute('SELECT transaction_id FROM processed_emails WHERE message_id=? AND transaction_id IS NOT NULL AND transaction_id>0 LIMIT 1', (message_id,)).fetchone()
        if existing:
            rid = int(existing['transaction_id'])
        else:
            rid = insert_tx(parsed, c)

        # A successful reprocess MUST remove the issue. Also create/update the
        # processed marker so the next normal Gmail poll cannot rediscover it.
        c.execute('DELETE FROM email_parse_issues WHERE uid=?', (uid,))
        c.execute(
            'INSERT INTO processed_emails(uid,message_id,received_at,subject,sender,parser_version,transaction_id,processed_at) '
            'VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(uid) DO UPDATE SET message_id=excluded.message_id,transaction_id=excluded.transaction_id,parser_version=excluded.parser_version,processed_at=excluded.processed_at',
            (uid, message_id or None, row['received_at'], row['subject'], row['sender'], 'v25-manual-reprocess', rid, sg_now().isoformat())
        )
        c.commit(); c.close()
        return {'ok': True, 'transaction_id': rid, 'parsed': parsed}
    except Exception as e:
        c.rollback(); c.close(); return {'ok': False, 'error': str(e)[:300]}

@app.post('/api/email-reset-skips')
def email_reset_skips():
    """Clear processed markers for emails that never produced a transaction so they can be re-polled."""
    c = db()
    cur = c.execute('DELETE FROM processed_emails WHERE transaction_id IS NULL OR transaction_id < 0')
    n = cur.rowcount
    issue_cur = c.execute('DELETE FROM email_parse_issues')
    issues = issue_cur.rowcount
    c.commit(); c.close()
    return {'ok': True, 'cleared': n, 'issues_cleared': issues}

@app.post('/api/email-poll')
def email_poll():
    try:
        result = process_mailbox(False)
        if result.get('already_running'):
            return {'ok':False,'error':'A Gmail poll is already running. Please wait a few seconds and try again.'}
        return result
    except Exception as e:return {'ok':False,'error':str(e)}
