# Miles Tracker V47

V37 builds on V36, fixes Maybank XL Cashback month-wide reward recalculation, and automatically sets every transaction whose merchant name starts with `AMAZE*` to the `online` transaction channel, then recalculates rewards. This applies to new imports, edits, and existing transactions during a one-time migration.

## AMAZE* online-channel rule
- Any merchant name beginning with `AMAZE*` (case-insensitive, ignoring leading spaces) is automatically assigned `online`.
- Existing AMAZE* transactions are migrated to `online` on the first startup after upgrading, and their reward/miles/cashback fields are recalculated.
- The app enforces this rule when adding, editing, or manually changing the channel of an AMAZE* transaction.

## MCC catalogue and reward recalculation
- Transactions display the MCC description beside the numeric code where a built-in description is available.
- The catalogue is shared across Visa and Mastercard because the MCC code is the category identifier; the MCC actually assigned to a merchant can still differ by acquirer, merchant setup, or transaction route.
- Exact merchant-name mappings remain stored locally in SQLite and continue to apply to existing and future transactions with the exact same merchant string.
- Editing a merchant's MCC now recalculates the reward and status fields for affected non-F&F transactions as well as updating the MCC. Maybank F&F transactions still receive the month-wide recalculation.
- Added descriptions for common categories including grocery, food, fuel, online/digital goods, retail, telecom, travel, transport, entertainment, and lodging. This is a built-in starter catalogue, not a claim that every network-specific or newly introduced MCC is included.


## Maybank XL Cashback logic (V37)
- Applies the S$500 calendar-month minimum-spend test using eligible Maybank XL retail transactions, not just bonus-category transactions.
- Awards 5% on the official Dine, Shop, Travel, Play and foreign-currency categories once the monthly minimum is met; otherwise eligible transactions earn 0.2% base cashback.
- Enforces the S$80 monthly 5% bonus-cashback cap, then returns excess spend to 0.2% base cashback.
- Recalculates all XL transactions for the month after imports, MCC changes, transaction edits/deletions, and before dashboard/transaction data is returned, so older rows do not retain stale `0.2% / BASE` statuses.
- Refunds/reversals and T&C-excluded transactions do not earn cashback or count toward the S$500 minimum. MCC 6300 Etiqa transactions receive 0.2% but do not count toward minimum spend.
- Cashback is rounded down to two decimal places per transaction as an estimate; Maybank may aggregate/round by category when crediting the actual statement reward.

## Upgrade
Preserve your existing `data/miles.db` and `data/.credential_key`. Do not copy a release archive's `data` directory over your live data. The archive excludes runtime databases, credential keys, Python bytecode, and cache directories.

## Existing V33 fixes retained
- Maybank refund SMS parsing (refunds stored as negative transactions).
- Google Finance FX lookup with a fallback provider.
- Foreign-currency Maybank spending uses SGD equivalents for dashboard totals and F&F thresholds.
- F&F monthly cashback is recalculated month-wide when required.


## V38 changes
- Added a Maybank Family & Friends monthly category tracker with donut charts showing cashback-cap utilisation, category spending in SGD equivalents, cashback earned, and the monthly cap.
- Added a compact V38 indicator in the top-right header.
- Uses the configured F&F preferred categories and the 1 Jan 2026 programme tier/cap structure. Chart values are estimates from imported transaction MCCs and reward statuses; verify against Maybank TREATS for final posted awards.

## Maybank F&F chart fixes (V44)
- Uses the dashboard month selector as the source of truth for the F&F category chart, and refreshes the trend and chart when the selected month changes.
- Guards category aggregation when a category is not selected, so hidden/unselected categories cannot cause a dashboard rendering error.
- Displays only selected F&F categories, as requested.


V44 fix: Maybank F&F chart spend attribution now puts MYR/IDR transactions into the selected MCC category first and only attributes the overflow portion to MYR/IDR; FX transactions outside selected categories go directly to MYR/IDR.


## Maybank F&F FX correction (V45)

V45 repairs legacy foreign-currency snapshots that incorrectly stored MYR/IDR face values as SGD at a 1:1 rate. The one-time migration refreshes non-manual F&F foreign FX using a currency-to-SGD quote, keeps posted SGD amounts and explicitly manual FX authoritative, clears suspect 1:1 foreign values if no valid quote is available, and recalculates each affected month’s spend thresholds and cashback allocation.

## V46 — date-specific Maybank foreign exchange
- Maybank F&F MYR/IDR transactions use a historical reference FX rate for the transaction date, not the current spot rate.
- Daily rates are requested from Frankfurter's dated endpoint; on weekends/public holidays, the endpoint's latest prior available reference date is used.
- FX is refreshed during F&F monthly recalculation and is keyed by transaction currency + transaction date. Editing the transaction date updates the FX rate.
- Explicit manual FX and posted SGD amount overrides remain authoritative. If historical FX cannot be fetched, the row is marked unavailable and does not get silently converted at 1:1 or today's rate.


## V47 — automatic MYR/IDR → SGD conversion (banner + F&F donuts)
**Root cause:** `main.py` called `json.loads()` without importing `json`. The exception was swallowed, so every FX lookup silently returned "unavailable", MYR rows were stored with no SGD value, and the frontend then showed the raw ringgit figure as if it were SGD.

- Added the missing `import json`.
- New imports convert MYR/IDR using the rate for the **transaction date** (Frankfurter). If that service is down and the transaction is ≤7 days old, a clearly-labelled provisional spot rate is stored and replaced by the dated rate on the next recalculation. Older transactions never fall back to spot.
- Dated rates are cached in memory (they never change); failed lookups are retried after 60 s. Rows that already hold a dated rate are no longer re-fetched on every `/api/summary` load, and the refresh is scoped to the month being recalculated (previously every month re-fetched every foreign row, which made the dashboard very slow).
- Rows with no rate yet self-heal on the next dashboard load; the page re-polls every 60 s while any are pending.
- Frontend `spendSgd()` no longer falls back to the foreign face amount. Unresolved rows count as S$0 and are flagged "FX pending" in the transaction list, in an alert chip under the header banner, and in the F&F donut subtitle. The header banner, card strip, trend chart and F&F donuts all share this one function.
- Posted SGD amounts and manual FX overrides remain authoritative.
