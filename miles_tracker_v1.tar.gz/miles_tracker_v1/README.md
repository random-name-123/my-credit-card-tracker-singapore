# Miles Tracker V1

Self-hosted FastAPI + SQLite web app for tracking credit-card spend, miles/cashback, and MCC classification.

## Run

### Docker
```bash
docker compose up -d --build
```
Open `http://localhost:8000`.

### Without Docker
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Transaction ingestion

V1 supports pasting/forwarding transaction email HTML/text into the web UI or POSTing it to `/api/ingest-email` as form field `body`.

Example:
```bash
curl -X POST http://localhost:8000/api/ingest-email -F 'body=<transaction email text>'
```

The parser intentionally avoids storing the raw email after parsing. In production, put the app behind HTTPS and use a dedicated mailbox/webhook.

## Included cards

- Citi Rewards Mastercard
- Maybank Family & Friends Mastercard
- Maybank XL Rewards

The reward rules are represented as versioned Python configuration so they can be changed without rewriting transaction history.

## Current rule sources

Citi Rewards official page: https://www.citibank.com.sg/credit-cards/points/rewards-card
Maybank Family & Friends official update: https://www.maybank2u.com.sg/en/personal/about_us/important-notices/2025/important-updates-to-your-maybank-fnf.page
Maybank XL Rewards T&Cs: https://www.maybank2u.com.sg/iwov-resources/sg/pdf/cards/xl-privileges-tp-tnc.pdf

Important: internet MCC data is an estimate unless the issuer statement/email supplies the actual MCC. V1 stores `mcc_source` and `mcc_confidence` to make this explicit.

## V1 limitations

- Email parsing is intentionally generic and should be extended with real examples from each bank.
- MCC web lookup is a local knowledge layer in V1; a production version should add a scheduled web research/cache service with source timestamps.
- No bank login credentials are stored or required.
- No automatic email mailbox access is enabled by default.
