from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from bs4 import BeautifulSoup
from datetime import datetime, date
from pathlib import Path
import sqlite3, re, json, html

BASE = Path(__file__).resolve().parent
DB = BASE.parent / 'data' / 'miles.db'
DB.parent.mkdir(exist_ok=True)

app = FastAPI(title='Miles Tracker V1')
app.mount('/static', StaticFiles(directory=str(BASE/'static')), name='static')

CARDS = {
 'citi_rewards': {'name':'Citi Rewards Mastercard','type':'miles'},
 'maybank_fnf': {'name':'Maybank Family & Friends Mastercard','type':'cashback'},
 'maybank_xl_rewards': {'name':'Maybank XL Rewards','type':'miles'},
}

# MCC knowledge used only as an estimate. Actual issuer-provided MCC should override it.
MCC = {
 4111:'Local/Suburban Commuter Passenger Transportation', 4121:'Taxicabs/Limousines', 4789:'Transportation Services',
 5811:'Caterers', 5812:'Eating Places/Restaurants', 5813:'Drinking Places', 5814:'Fast Food Restaurants', 5462:'Bakeries',
 5311:'Department Stores', 5310:'Discount Stores', 5331:'Variety Stores', 5399:'Miscellaneous General Merchandise',
 5262:'Marketplaces', 5621:'Women’s Ready-to-Wear', 5631:'Women’s Accessory/Specialty', 5651:'Family Clothing',
 5655:'Sports/Fashion Clothing', 5661:'Shoe Stores', 5691:'Men/Women Clothing', 5699:'Misc Apparel', 5941:'Sporting Goods',
 4899:'Cable/Other Pay Television', 5815:'Digital Goods/Media', 7832:'Motion Picture Theatres', 7993:'Video Game Arcades',
 7994:'Video Game/Amusement', 7011:'Lodging', 4511:'Airlines', 4722:'Travel Agencies',
}

XL = {
 'Dine': {5811,5812,5814,5462},
 'Shop': {5262,5310,5311,5331,5399,5621,5631,5651,5655,5661,5691,5699,5941},
 'Play': {4899,5813,5815,7832,7993,7994},
 'Travel': set(range(3000,3300)) | set(range(3300,3309)) | {4511,4722,7011},
}
FNF = {
 'Commute': {4111,4121,4789,4112,4131},
 'Automotive': {5541,5542,5532,5533,5599,7531,7535,7538,5552},
}


def db():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row
 c.execute('''CREATE TABLE IF NOT EXISTS transactions(
 id INTEGER PRIMARY KEY, transaction_date TEXT, posted_date TEXT, merchant TEXT, amount REAL,
 currency TEXT, card_id TEXT, last4 TEXT, mcc INTEGER, mcc_source TEXT, mcc_confidence TEXT,
 mcc_note TEXT, miles REAL DEFAULT 0, cashback REAL DEFAULT 0, reward_status TEXT,
 raw_summary TEXT, created_at TEXT)''')
 c.execute('''CREATE TABLE IF NOT EXISTS card_settings(card_id TEXT PRIMARY KEY, statement_day INTEGER DEFAULT 1)''')
 c.commit(); return c

def parse_email(body:str):
 text=BeautifulSoup(body,'html.parser').get_text(' ', strip=True)
 text=re.sub(r'\s+',' ',text)
 amount=None
 for pat in [r'(?:SGD|S\$)\s*([0-9,]+\.\d{2})', r'\$\s*([0-9,]+\.\d{2})']:
  m=re.search(pat,text,re.I)
  if m: amount=float(m.group(1).replace(',','')); break
 currency='SGD' if ('SGD' in text.upper() or 'S$' in text.upper()) else 'SGD'
 date_m=re.search(r'\b(\d{1,2})[/-](\d{1,2})[/-](20\d{2})\b',text)
 if date_m:
  d,m,y=map(int,date_m.groups()); tx_date=date(y,m,d).isoformat()
 else: tx_date=date.today().isoformat()
 card_id=''
 lower=text.lower()
 if 'citi' in lower and 'reward' in lower: card_id='citi_rewards'
 elif 'family' in lower or 'friends' in lower: card_id='maybank_fnf'
 elif 'xl rewards' in lower: card_id='maybank_xl_rewards'
 last4=(re.findall(r'(?:ending|ends|card)\D{0,12}(\d{4})',text,re.I) or [''])[-1]
 # common email labels
 merchant='Unknown merchant'
 for pat in [r'(?:merchant|description|transaction)\s*[:\-]\s*([^|;]+?)(?:\s+(?:amount|date|card|reference)\s*[:\-]|$)',
             r'(?:at|from)\s+([A-Z0-9][A-Z0-9 &._\-]{2,50})']:
  m=re.search(pat,text,re.I)
  if m: merchant=m.group(1).strip(); break
 return {'merchant':merchant[:120],'amount':amount or 0,'currency':currency,'transaction_date':tx_date,'posted_date':tx_date,'card_id':card_id,'last4':last4,'summary':text[:500]}

def classify_merchant(merchant):
 ml=merchant.lower()
 # lightweight deterministic merchant hints; replace/extend with sourced MCC cache in production
 hints=[
  (r'fairprice|ntuc|cold storage|sheng siong|giant',5411,'Grocery / Supermarket'),
  (r'shopee|lazada|qoo10|amazon',5311,'Online marketplace / shopping'),
  (r'grab.*food|foodpanda|deliveroo',5814,'Food delivery'),
  (r'grab.*transport|gojek|comfortdelgro|taxi',4121,'Taxi / ride-hailing'),
  (r'netflix|disney|spotify|youtube',4899,'Streaming / subscription'),
 ]
 for p,m,n in hints:
  if re.search(p,ml): return m,n,'internet-estimate','MEDIUM'
 return None,None,'unverified','LOW'

def citi_period(tx_date, statement_day=1):
 d=date.fromisoformat(tx_date)
 # Approximate statement-month bucket; actual statement date should be configured per user.
 if statement_day <= 1: return f'{d.year:04d}-{d.month:02d}'
 if d.day >= statement_day: return f'{d.year:04d}-{d.month:02d}'
 prev=(d.replace(day=1)-__import__('datetime').timedelta(days=1))
 return f'{prev.year:04d}-{prev.month:02d}'

def calc_reward(tx, c):
 amount=tx['amount']; mcc=tx['mcc']; card=tx['card_id']; miles=0; cash=0; status='BASE'
 if card=='citi_rewards':
  # Official base = 1 point/$, bonus = 9 points/$ on eligible 10X; points are calculated on whole dollars.
  eligible=(mcc in {5311,5611,5621,5631,5641,5651,5655,5661,5691,5699,5948} if mcc else False)
  if eligible:
   # cap allocation is applied by statement month using transactions already stored.
   period=citi_period(tx['transaction_date'])
   row=c.execute("SELECT COALESCE(SUM(CASE WHEN mcc IN (5311,5611,5621,5631,5641,5651,5655,5661,5691,5699,5948) THEN CAST(amount AS INTEGER) ELSE 0 END),0) s FROM transactions WHERE card_id='citi_rewards' AND transaction_date LIKE ?",(period+'%',)).fetchone()
   used=float(row['s']) if row else 0
   bonus_dollars=max(0,min(int(amount),1000-used)) # 9 points/$; 9000 bonus-point cap
   miles=(int(amount)+9*bonus_dollars)/2.5 # 10X points -> 4 miles/$; 25 points = 10 miles assumption
   status='10X' if bonus_dollars>=int(amount) else 'CAP-PARTIAL'
  else:
   miles=int(amount)/2.5; status='BASE'
 elif card=='maybank_xl_rewards':
  eligible=any(mcc in s for s in XL.values()) if mcc else False
  # V1: 10X TREATS = 4 mpd; cap/min-spend handling is surfaced as configurable TODO.
  miles=amount*4 if eligible else amount*0.4
  status='10X' if eligible else 'BASE'
 elif card=='maybank_fnf':
  # 2026 programme: tier 1 up to 6%, tier 2 up to 8%, $20/$30 per category. V1 implements known categories.
  cat=next((k for k,v in FNF.items() if mcc in v),None) if mcc else None
  if cat:
   month=tx['transaction_date'][:7]
   row=c.execute("SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE card_id='maybank_fnf' AND transaction_date LIKE ?",(month+'%',)).fetchone()
   spend=float(row['s']) if row else 0
   rate=0.08 if spend+amount>=1600 else (0.06 if spend+amount>=800 else 0.0022)
   cap=30 if rate==0.08 else 20 if rate==0.06 else None
   cash=min(amount*rate,cap) if cap else amount*rate
   status=f'{int(rate*100)}% {cat}' if rate>0.01 else 'BASE'
  else: cash=amount*0.0022; status='BASE'
 return round(miles,2),round(cash,2),status

def insert_tx(data):
 c=db(); mcc,note,src,conf=classify_merchant(data['merchant'])
 data.update({'mcc':mcc,'mcc_note':note,'mcc_source':src,'mcc_confidence':conf})
 miles,cash,status=calc_reward(data,c)
 c.execute('''INSERT INTO transactions(transaction_date,posted_date,merchant,amount,currency,card_id,last4,mcc,mcc_source,mcc_confidence,mcc_note,miles,cashback,reward_status,raw_summary,created_at)
 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''', (data['transaction_date'],data['posted_date'],data['merchant'],data['amount'],data['currency'],data['card_id'],data['last4'],data['mcc'],data['mcc_source'],data['mcc_confidence'],data['mcc_note'],miles,cash,status,data.get('summary',''),datetime.utcnow().isoformat()))
 c.commit(); rid=c.lastrowid; c.close(); return rid

@app.get('/',response_class=HTMLResponse)
def home(): return (BASE/'static/index.html').read_text()

@app.get('/api/summary')
def summary():
 c=db(); rows=c.execute('SELECT * FROM transactions ORDER BY transaction_date DESC,id DESC').fetchall()
 total=sum(r['amount'] for r in rows); miles=sum(r['miles'] for r in rows); cash=sum(r['cashback'] for r in rows)
 by={}
 for r in rows:
  k=r['card_id'] or 'unknown'; by.setdefault(k,{'spend':0,'miles':0,'cashback':0}); by[k]['spend']+=r['amount']; by[k]['miles']+=r['miles']; by[k]['cashback']+=r['cashback']
 return {'total_spend':round(total,2),'miles':round(miles,2),'cashback':round(cash,2),'count':len(rows),'by_card':by,'transactions':[dict(r) for r in rows]}

@app.post('/api/ingest-email')
def ingest_email(body:str=Form(...)):
 data=parse_email(body); rid=insert_tx(data); return {'id':rid,'parsed':data}

@app.post('/api/transaction')
def add_transaction(payload:dict):
 payload.setdefault('posted_date',payload.get('transaction_date',date.today().isoformat())); payload.setdefault('currency','SGD'); payload.setdefault('card_id','')
 return {'id':insert_tx(payload)}

@app.delete('/api/transactions/{txid}')
def delete_transaction(txid:int):
 c=db(); c.execute('DELETE FROM transactions WHERE id=?',(txid,)); c.commit(); c.close(); return {'ok':True}

@app.get('/api/cards')
def cards(): return CARDS
