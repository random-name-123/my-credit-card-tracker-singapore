from fastapi import FastAPI, Form
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from bs4 import BeautifulSoup
from cryptography.fernet import Fernet, InvalidToken
from datetime import datetime, date, timedelta
from zoneinfo import ZoneInfo
from pathlib import Path
import sqlite3, re, imaplib, email, os, threading, time, hashlib
from email import policy
from email.parser import BytesParser

BASE = Path(__file__).resolve().parent
DB = BASE.parent / 'data' / 'miles.db'
KEYFILE = BASE.parent / 'data' / '.credential_key'
DB.parent.mkdir(exist_ok=True)
SG_TZ = ZoneInfo('Asia/Singapore')

def sg_now():
    return datetime.now(SG_TZ)

def sg_today():
    return sg_now().date()

app = FastAPI(title='Miles Tracker V9')
app.mount('/static', StaticFiles(directory=str(BASE/'static')), name='static')

CARDS = {'citi_rewards': {'name':'Citi Rewards Mastercard','type':'miles'}, 'maybank_fnf': {'name':'Maybank Family & Friends Mastercard','type':'cashback'}, 'maybank_xl_rewards': {'name':'Maybank XL Cashback','type':'cashback'}, 'trust_freedom': {'name':'Trust Freedom Card','type':'cashback'}}
MCC = {5311:'Department Stores',5611:"Men's and Boys' Clothing and Accessories Stores",5621:"Women's Ready-to-Wear",5631:"Women's Accessory/Specialty",5641:'Children/Infant Clothing',5651:'Family Clothing',5655:'Sports/Riding Apparel',5661:'Shoe Stores',5691:"Men's/Women's Clothing",5699:'Misc Apparel/Accessories',5948:'Luggage/Leather Goods',5411:'Grocery Stores/Supermarkets',5811:'Caterers',5812:'Eating Places/Restaurants',5814:'Fast Food Restaurants',4111:'Passenger Transportation',4112:'Passenger Railways',4121:'Taxicabs/Limousines',4789:'Transportation Services',4511:'Airlines',4722:'Travel Agencies',7011:'Lodging'}
CITI_SHOPPING_MCC = {5311,5611,5621,5631,5641,5651,5655,5661,5691,5699,5948}
CITI_TRAVEL_MCC = set(range(3000,4000)) | {4111,4112,4789,4411,4511,4722,4723,5962,7011,7012,7512}
# Maybank XL Cashback — official MCCs from XL Cashback Card T&Cs
XL_MCC = {
    'Dine': {5811, 5812, 5814, 5462},
    'Shop': {5262, 5310, 5311, 5331, 5399, 5621, 5631, 5651, 5655, 5661, 5691, 5699, 5941},
    'Travel': set(range(3000, 3300)) | set(range(3300, 3309)) | {4511, 4722, 7011},
    'Play': {4899, 5813, 5815, 7832, 7993, 7994},
}
XL_ALL_BONUS_MCC = set().union(*XL_MCC.values())

# Maybank Family & Friends — category MCCs (effective 1 Jan 2026 where known)
FNF_MCC = {
    'Automotive': {5541, 5542, 5532, 5533, 5599, 7531, 7535, 7538, 5552, 8699},
    'Beauty & Wellness': {7230, 7297, 7298},
    'Commute': {4111, 4121, 4789, 4112, 4131},
    'Dining & Food Delivery': {5811, 5812, 5814},
    'Entertainment': {5813, 7832, 7922, 7929},
    'Groceries': {5411},
    'Kids & Pets': {742, 5995},  # 0742 stored without leading zero
    'Online Shopping': {5611, 5262, 5309, 5310, 5311, 5331, 5399, 5621, 5631, 5641, 5651, 5661, 5691, 5699, 5948},
    'Sports & Sports Apparels': {5655, 5941, 7997, 7941},
    'Telco & Streaming': {4812, 4814, 4899},
}
# Default preferred categories for new cardmembers from 1 Jan 2026
FNF_DEFAULT_PREFERRED = ['Automotive', 'Dining & Food Delivery', 'Kids & Pets', 'Online Shopping', 'Telco & Streaming']



def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row
    c.execute("""CREATE TABLE IF NOT EXISTS transactions(id INTEGER PRIMARY KEY,transaction_date TEXT,transaction_time TEXT,posted_date TEXT,merchant TEXT,amount REAL,currency TEXT,card_id TEXT,last4 TEXT,mcc INTEGER,mcc_source TEXT,mcc_confidence TEXT,mcc_note TEXT,transaction_channel TEXT DEFAULT 'unknown',miles REAL DEFAULT 0,cashback REAL DEFAULT 0,reward_status TEXT,raw_summary TEXT,created_at TEXT)""")
    c.execute("CREATE TABLE IF NOT EXISTS card_settings(card_id TEXT PRIMARY KEY,statement_day INTEGER DEFAULT 1)")
    # Citi Rewards statement date: user has confirmed the statement closes on the 20th.
    # The setting is persisted so the statement-cycle logic does not depend on UI state.
    c.execute("INSERT OR IGNORE INTO card_settings(card_id,statement_day) VALUES('citi_rewards',20)")
    c.execute("""CREATE TABLE IF NOT EXISTS merchant_mcc_rules(merchant_name TEXT PRIMARY KEY COLLATE BINARY,mcc INTEGER NOT NULL,note TEXT,source TEXT NOT NULL DEFAULT 'user',updated_at TEXT NOT NULL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS app_settings(key TEXT PRIMARY KEY,value TEXT NOT NULL,updated_at TEXT NOT NULL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS processed_emails(uid TEXT PRIMARY KEY,message_id TEXT,received_at TEXT,subject TEXT,sender TEXT,parser_version TEXT,transaction_id INTEGER,processed_at TEXT NOT NULL)""")
    cols={r['name'] for r in c.execute('PRAGMA table_info(transactions)').fetchall()}
    if 'transaction_time' not in cols: c.execute("ALTER TABLE transactions ADD COLUMN transaction_time TEXT")
    if 'transaction_channel' not in cols: c.execute("ALTER TABLE transactions ADD COLUMN transaction_channel TEXT DEFAULT 'unknown'")
    if 'email_cashback' not in cols: c.execute("ALTER TABLE transactions ADD COLUMN email_cashback REAL")
    # Backfill transaction times from stored email text for transactions imported before V7.
    for r in c.execute("SELECT id,raw_summary FROM transactions WHERE (transaction_time IS NULL OR transaction_time='') AND raw_summary IS NOT NULL AND raw_summary<>''").fetchall():
        raw=str(r['raw_summary'])
        tm=None
        m=re.search(r'Transaction\s+time\s*:\s*([0-9]{1,2}:[0-9]{2}(?::[0-9]{2})?)', raw, re.I)
        if m: tm=m.group(1)
        if not tm:
            m=re.search(r'\bon\s+\d{1,2}\s+[A-Za-z]{3,9}\s+\d{4}\s+(\d{1,2}:\d{2}(?::\d{2})?)\s*SGT', raw, re.I)
            if m: tm=m.group(1)
        if tm: c.execute("UPDATE transactions SET transaction_time=? WHERE id=?",(tm,r['id']))
    c.commit(); return c

def get_setting(c,key,default=''):
    r=c.execute('SELECT value FROM app_settings WHERE key=?',(key,)).fetchone(); return r['value'] if r else default

def set_setting(c,key,value):
    c.execute('INSERT INTO app_settings(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at',(key,value,sg_now().isoformat()))

def crypto():
    if not KEYFILE.exists(): KEYFILE.write_bytes(Fernet.generate_key()); os.chmod(KEYFILE,0o600)
    return Fernet(KEYFILE.read_bytes().strip())

def save_secret(c,key,value): set_setting(c,'secret:'+key,crypto().encrypt(value.encode()).decode())
def read_secret(c,key):
    v=get_setting(c,'secret:'+key,'')
    if not v:return ''
    try:return crypto().decrypt(v.encode()).decode()
    except (InvalidToken,ValueError):return ''

def exact_mcc_rule(c,merchant): return c.execute('SELECT * FROM merchant_mcc_rules WHERE merchant_name = ? COLLATE BINARY',(merchant,)).fetchone()

def extract_message_body(body):
    try:
        if re.search(r'(?im)^Content-Type:\s*multipart/', body) or re.search(r'(?im)^MIME-Version:', body):
            msg=BytesParser(policy=policy.default).parsebytes(body.encode('utf-8','ignore')); part=msg.get_body(preferencelist=('html','plain'))
            if part is not None:return part.get_content()
    except Exception: pass
    return body

def parse_citi_email(body):
    """Parse Citi Singapore transaction-alert emails (HTML or plain)."""
    body = extract_message_body(body)
    text = re.sub(r'\s+', ' ', BeautifulSoup(body, 'html.parser').get_text(' ', strip=True))
    if not re.search(r'citi|citibank', text, re.I):
        return None
    am = None
    for pat in [
        r'Transaction\s+amount\s*:\s*(?:SGD|S\$)\s*([0-9,]+\.\d{2})',
        r'(?:SGD|S\$)\s*([0-9,]+\.\d{2})\s*(?:was\s+spent|charged|posted)',
        r'Amount\s*:\s*(?:SGD|S\$)\s*([0-9,]+\.\d{2})',
        r'(?:SGD|S\$)\s*([0-9,]+\.\d{2})',
    ]:
        am = re.search(pat, text, re.I)
        if am:
            break
    dm = None
    for pat in [
        r'Transaction\s+date\s*:\s*(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})',
        r'Date\s*:\s*(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})',
        r'\b(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})\b',
    ]:
        dm = re.search(pat, text, re.I)
        if dm:
            break
    tm = re.search(r'Transaction\s+time\s*:\s*([0-9]{1,2}:[0-9]{2}(?::[0-9]{2})?)', text, re.I)
    mm = None
    for pat in [
        r'Transaction\s+details\s*:\s*(.+?)(?=\s+If\s+you\s+did\s+not\s+make|\s+Thank\s+you\s+for\s+banking|\s+Account\s+number|\s+Card\s+ending|$)',
        r'(?:Merchant|Description|At)\s*:\s*(.+?)(?=\s+If\s+you\s+did\s+not\s+make|\s+Thank\s+you|\s+Transaction\s+amount|\s+Account\s+number|$)',
        r'(?:spent\s+at|charged\s+at)\s+(.+?)(?=\s+on\s+\d|\s+If\s+you|\s+Thank\s+you|$)',
    ]:
        mm = re.search(pat, text, re.I)
        if mm:
            break
    cm = re.search(r'(?:Account\s+number|Card\s+ending|ending\s+in)\s*:?\s*X*[-\sX]*(\d{4})', text, re.I)
    if not (am and dm and mm):
        return None
    d, mo, y = map(int, dm.groups())
    y += 2000 if y < 100 else 0
    try:
        tx_date = date(y, mo, d).isoformat()
    except ValueError:
        try:
            tx_date = date(y, d, mo).isoformat()
        except ValueError:
            return None
    merchant = re.sub(r'\s+', ' ', mm.group(1)).strip()[:160]
    merchant = re.split(r'\s+If you did not\b', merchant, flags=re.I)[0].strip()
    if not merchant or not am.group(1):
        return None
    return {
        'merchant': merchant,
        'amount': float(am.group(1).replace(',', '')),
        'currency': 'SGD',
        'transaction_date': tx_date,
        'posted_date': tx_date,
        'card_id': 'citi_rewards',
        'last4': cm.group(1) if cm else '',
        'transaction_channel': 'unknown',
        'summary': text[:1000],
        'transaction_time': tm.group(1) if tm else '',
    }

def parse_trust_email(body):
    """Parse Trust Bank Freedom transaction alerts such as:
    You've spent SGD 2.07 at MERCHANT on 26 Sep 2026 13:56SGT with Freedom credit card.
    You'll receive estimated S$0.02 cashback.
    """
    body = extract_message_body(body)
    text = re.sub(r'\s+', ' ', BeautifulSoup(body, 'html.parser').get_text(' ', strip=True))
    if not re.search(r'trustbank\.sg|trust\s+bank|freedom\s+credit\s+card', text, re.I):
        return None
    m = re.search(r"You've\s+spent\s+([A-Z]{3}|S\$|\$)\s*([0-9,]+\.\d{2})\s+at\s+(.+?)\s+on\s+(\d{1,2})\s+([A-Za-z]{3,9})\s+(\d{4})\s+(\d{1,2}:\d{2}(?::\d{2})?)\s*SGT\s+with\s+Freedom\s+credit\s+card", text, re.I)
    if not m:
        return None
    currency, amount_s, merchant, d, mon, y, tm = m.groups()
    try:
        tx_date = datetime.strptime(f'{d} {mon} {y}', '%d %b %Y').date().isoformat()
    except ValueError:
        try: tx_date = datetime.strptime(f'{d} {mon} {y}', '%d %B %Y').date().isoformat()
        except ValueError: return None
    cm = re.search(r'estimated\s+S\$\s*([0-9,]+\.\d{2})\s+cashback', text, re.I)
    cashback = float(cm.group(1).replace(',', '')) if cm else None
    merchant = re.sub(r'\s+', ' ', merchant).strip()[:160]
    return {
        'merchant': merchant,
        'amount': float(amount_s.replace(',', '')),
        'currency': 'SGD' if currency.upper() in ('S$', '$') else currency.upper(),
        'transaction_date': tx_date,
        'posted_date': tx_date,
        'card_id': 'trust_freedom',
        'last4': '',
        'transaction_channel': 'unknown',
        'summary': text[:1000],
        'transaction_time': tm,
        'email_cashback': cashback,
    }

def parse_email(body):
    trust=parse_trust_email(body)
    if trust:return trust
    citi=parse_citi_email(body)
    if citi:return citi
    text=re.sub(r'\s+',' ',BeautifulSoup(body,'html.parser').get_text(' ',strip=True)); amount=0
    for p in [r'(?:SGD|S\$)\s*([0-9,]+\.\d{2})',r'\$\s*([0-9,]+\.\d{2})']:
        m=re.search(p,text,re.I)
        if m: amount=float(m.group(1).replace(',',''));break
    dm=re.search(r'\b(\d{1,2})[/-](\d{1,2})[/-](20\d{2})\b',text); tx_date=sg_today().isoformat()
    if dm:
        d,m,y=map(int,dm.groups());tx_date=date(y,m,d).isoformat()
    low=text.lower(); card='citi_rewards' if 'citi' in low and 'reward' in low else ''
    last4=(re.findall(r'(?:ending|ends|card)\D{0,12}(\d{4})',text,re.I) or [''])[-1]; merchant='Unknown merchant'
    for p in [r'(?:merchant|description|transaction)\s*[:\-]\s*([^|;]+?)(?:\s+(?:amount|date|card|reference)\s*[:\-]|$)',r'(?:at|from)\s+([A-Z0-9][A-Z0-9 &._\-]{2,80})']:
        m=re.search(p,text,re.I)
        if m: merchant=m.group(1).strip();break
    return {'merchant':merchant[:160],'amount':amount,'currency':'SGD','transaction_date':tx_date,'posted_date':tx_date,'card_id':card,'last4':last4,'transaction_channel':'unknown','summary':text[:1000]}

def card_statement_day(c, card_id, default=1):
    r=c.execute('SELECT statement_day FROM card_settings WHERE card_id=?',(card_id,)).fetchone()
    try: return int(r['statement_day']) if r and r['statement_day'] else default
    except (TypeError,ValueError): return default

def citi_cycle_bounds(tx_date, statement_day=20):
    """Return inclusive YYYY-MM-DD bounds for the Citi statement cycle containing tx_date.

    With a statement date of the 20th, the cycle runs from the 21st of the
    previous month through the 20th of the current month. Transactions after
    the 20th belong to the next cycle.
    """
    d=date.fromisoformat(tx_date)
    sd=max(1,min(int(statement_day),28))
    if d.day <= sd:
        end=d.replace(day=sd)
        pm=end.replace(day=1)-timedelta(days=1)
        start=pm.replace(day=sd+1)
    else:
        start=d.replace(day=sd+1)
        nm=d.replace(day=28)+timedelta(days=4)
        nm=nm.replace(day=1)
        end=nm.replace(day=sd)
    return start.isoformat(), end.isoformat()

def citi_cycle_label(tx_date, statement_day=20):
    start,end=citi_cycle_bounds(tx_date,statement_day)
    return f'{start} to {end}'


def classify_citi(tx):
    mcc=tx.get('mcc'); ch=tx.get('transaction_channel') or 'unknown'
    if not mcc:return False,'BASE / MCC UNKNOWN'
    if mcc in CITI_SHOPPING_MCC:return True,'10X / SHOPPING MCC'
    if ch=='online' and mcc not in CITI_TRAVEL_MCC:return True,'10X / ONLINE'
    return False,'BASE'

def calendar_month(dstr):
    """YYYY-MM from transaction_date."""
    if not dstr: return ''
    return str(dstr)[:7]

def month_spend(c, card_id, month, exclude_id=None):
    q = "SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE card_id=? AND transaction_date LIKE ?"
    params = [card_id, month + '%']
    if exclude_id:
        q += " AND id <> ?"
        params.append(exclude_id)
    return float(c.execute(q, tuple(params)).fetchone()['s'] or 0)

def month_bonus_cashback(c, card_id, month, exclude_id=None):
    """Sum of cashback already awarded at bonus rates this month (approx via reward_status)."""
    q = "SELECT COALESCE(SUM(cashback),0) s FROM transactions WHERE card_id=? AND transaction_date LIKE ? AND (reward_status LIKE '5%%' OR reward_status LIKE '6%%' OR reward_status LIKE '8%%' OR reward_status LIKE '4%%')"
    params = [card_id, month + '%']
    if exclude_id:
        q += " AND id <> ?"
        params.append(exclude_id)
    return float(c.execute(q, tuple(params)).fetchone()['s'] or 0)

def month_cat_bonus_cashback(c, card_id, month, cat_label, exclude_id=None):
    q = "SELECT COALESCE(SUM(cashback),0) s FROM transactions WHERE card_id=? AND transaction_date LIKE ? AND reward_status LIKE ?"
    params = [card_id, month + '%', f'%{cat_label}%']
    if exclude_id:
        q += " AND id <> ?"
        params.append(exclude_id)
    return float(c.execute(q, tuple(params)).fetchone()['s'] or 0)

def fnf_preferred_categories(c):
    raw = get_setting(c, 'fnf_preferred_categories', '')
    if raw:
        cats = [x.strip() for x in raw.split('|') if x.strip() in FNF_MCC]
        if len(cats) == 5:
            return cats
    return list(FNF_DEFAULT_PREFERRED)

def fnf_category_for_mcc(mcc):
    if mcc is None:
        return None
    try:
        mcc = int(mcc)
    except (TypeError, ValueError):
        return None
    for name, codes in FNF_MCC.items():
        if mcc in codes:
            return name
    return None

def xl_bonus_category(mcc, currency=None):
    """Return category name if eligible for 5% bonus, else None. Foreign Spend = non-SGD currency."""
    if currency and str(currency).upper() not in ('SGD', 'S$', ''):
        return 'Foreign Spend'
    if mcc is None:
        return None
    try:
        mcc = int(mcc)
    except (TypeError, ValueError):
        return None
    for name, codes in XL_MCC.items():
        if mcc in codes:
            return name
    return None

def calc_reward(tx, c, include_self=False):
    amount = float(tx.get('amount') or 0)
    mcc = tx.get('mcc')
    card = tx.get('card_id')
    currency = tx.get('currency') or 'SGD'
    miles = cash = 0.0
    status = 'BASE'
    exclude_id = tx.get('id') if include_self else None
    month = calendar_month(tx.get('transaction_date'))

    if card == 'citi_rewards':
        eligible, label = classify_citi(tx)
        whole = int(amount)
        if eligible and whole > 0:
            statement_day = card_statement_day(c, 'citi_rewards', 20)
            cycle_start, cycle_end = citi_cycle_bounds(tx['transaction_date'], statement_day)
            params = [cycle_start, cycle_end]
            q = "SELECT COALESCE(SUM(CASE WHEN reward_status LIKE '10X%' OR reward_status='CAP-PARTIAL' THEN CAST(amount AS INTEGER) ELSE 0 END),0) used FROM transactions WHERE card_id='citi_rewards' AND transaction_date BETWEEN ? AND ?"
            if exclude_id:
                q += ' AND id <> ?'
                params.append(exclude_id)
            used = int(c.execute(q, tuple(params)).fetchone()['used'] or 0)
            bonus = max(0, min(whole, 1000 - used))
            miles = (whole + 9 * bonus) / 2.5
            status = label if bonus == whole else ('CAP-PARTIAL' if bonus > 0 else 'BASE / 10X CAP USED')
        else:
            miles = whole / 2.5
            status = label

    elif card == 'maybank_xl_rewards':
        # XL Cashback T&Cs: 5% on Dine/Shop/Travel/Play/FCY if month spend >= $500, cap $80 bonus; else 0.2%
        # Etiqa MCC 6300 always 0.2% and does not count toward min spend
        cat = xl_bonus_category(mcc, currency)
        is_etiqa = (mcc is not None and int(mcc) == 6300)
        if is_etiqa:
            cash = amount * 0.002
            status = '0.2% / ETIQA'
        else:
            total_month = month_spend(c, card, month, exclude_id)
            # Include this txn in the threshold check
            if not include_self or not exclude_id:
                total_month_with = total_month  # when inserting, amount already will be in DB after; for calc before insert use +amount
            # For insert path include_self is False and txn not yet in DB → add amount
            # For recalc include_self True and we exclude self → add amount
            spend_for_threshold = total_month + amount
            bonus_so_far = month_bonus_cashback(c, card, month, exclude_id)
            if cat and spend_for_threshold >= 500:
                room = max(0.0, 80.0 - bonus_so_far)
                raw = amount * 0.05
                if room <= 0:
                    cash = amount * 0.002
                    status = f'0.2% / CAP USED ({cat})'
                elif raw <= room:
                    cash = raw
                    status = f'5% / {cat}'
                else:
                    # partial at 5%, rest at 0.2%
                    at5 = room
                    rest = amount - (room / 0.05)
                    cash = at5 + max(0, rest) * 0.002
                    status = f'5% PARTIAL / {cat}'
            else:
                cash = amount * 0.002
                status = f'0.2% / {"BASE" if not cat else cat + " (min spend)"}'

    elif card == 'maybank_fnf':
        # F&F T&Cs effective 1 Jan 2026:
        # < $800: 0.22% all
        # $800–$1599.99: 6% on 5 preferred + MYR/IDR, $20/cat cap ($120 total); Groceries max 6%
        # $1600+: 8% (Groceries still 6%), $30/cat cap ($180 total)
        preferred = fnf_preferred_categories(c)
        cat = fnf_category_for_mcc(mcc)
        is_myr_idr = str(currency).upper() in ('MYR', 'IDR', 'RM', 'RP')
        spend_for_threshold = month_spend(c, card, month, exclude_id) + amount

        if spend_for_threshold < 800:
            cash = amount * 0.0022
            status = '0.22% / BASE'
        else:
            tier2 = spend_for_threshold >= 1600
            rate = 0.08 if tier2 else 0.06
            cap_per = 30.0 if tier2 else 20.0
            # Eligible for bonus if preferred category OR MYR/IDR (bonus category)
            bonus_eligible = False
            cat_label = None
            if cat and cat in preferred:
                bonus_eligible = True
                cat_label = cat
                if cat == 'Groceries':
                    rate = 0.06  # groceries capped at 6% even in Tier 2
            elif is_myr_idr:
                bonus_eligible = True
                cat_label = 'MYR/IDR'
            if bonus_eligible and cat_label:
                used_cat = month_cat_bonus_cashback(c, card, month, cat_label, exclude_id)
                room = max(0.0, cap_per - used_cat)
                raw = amount * rate
                if room <= 0:
                    cash = amount * 0.0022
                    status = f'0.22% / CAP ({cat_label})'
                elif raw <= room:
                    cash = raw
                    pct = int(rate * 100)
                    status = f'{pct}% / {cat_label}'
                else:
                    at_bonus = room
                    rest_amt = amount - (room / rate)
                    cash = at_bonus + max(0, rest_amt) * 0.0022
                    status = f'{int(rate*100)}% PARTIAL / {cat_label}'
            else:
                cash = amount * 0.0022
                status = '0.22% / OTHER'

    elif card == 'trust_freedom':
        # Trust's Freedom card supports multiple reward modes. For email-imported
        # transactions, use the cashback amount explicitly stated by Trust in the alert.
        if tx.get('email_cashback') is not None:
            cash = float(tx.get('email_cashback') or 0)
            status = 'TRUST EMAIL ESTIMATE'
        else:
            cash = 0.0
            status = 'TRUST / REWARD ESTIMATE NOT PROVIDED'

    return round(miles, 2), round(cash, 2), status


def effective_mcc(c,merchant,supplied=None):
    if supplied is not None:return int(supplied),'user','HIGH','Manual MCC supplied'
    rule=exact_mcc_rule(c,merchant)
    if rule:return int(rule['mcc']),'user-exact-name','HIGH',rule['note'] or 'Exact merchant-name MCC mapping'
    return None,'unverified','LOW','No MCC mapping yet'

def insert_tx(data):
    c=db();mcc,src,conf,note=effective_mcc(c,data['merchant'],data.get('mcc'));data.update(mcc=mcc,mcc_source=src,mcc_confidence=conf,mcc_note=note,transaction_channel=data.get('transaction_channel') or 'unknown');miles,cash,status=calc_reward(data,c)
    cur=c.execute('INSERT INTO transactions(transaction_date,transaction_time,posted_date,merchant,amount,currency,card_id,last4,mcc,mcc_source,mcc_confidence,mcc_note,transaction_channel,email_cashback,miles,cashback,reward_status,raw_summary,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(data['transaction_date'],data.get('transaction_time',''),data.get('posted_date',data['transaction_date']),data['merchant'],data['amount'],data.get('currency','SGD'),data.get('card_id',''),data.get('last4',''),data['mcc'],data['mcc_source'],data['mcc_confidence'],data['mcc_note'],data['transaction_channel'],data.get('email_cashback'),miles,cash,status,data.get('summary',''),sg_now().isoformat()));rid=cur.lastrowid;c.commit();c.close();return rid

def recalc_all_for_merchant(c,merchant):
    rows=c.execute('SELECT * FROM transactions WHERE merchant = ? COLLATE BINARY ORDER BY transaction_date,id',(merchant,)).fetchall();rule=exact_mcc_rule(c,merchant)
    for r in rows:
        tx=dict(r);tx['mcc']=int(rule['mcc']);tx['transaction_channel']=r['transaction_channel'] or 'unknown';miles,cash,status=calc_reward(tx,c,True);c.execute('UPDATE transactions SET mcc=?,mcc_source=?,mcc_confidence=?,mcc_note=?,miles=?,cashback=?,reward_status=? WHERE id=?',(tx['mcc'],'user-exact-name','HIGH',rule['note'] or 'Exact merchant-name MCC mapping',miles,cash,status,r['id']))
    return len(rows)

def email_config(c):
    return {'enabled':get_setting(c,'email_enabled','0')=='1','host':get_setting(c,'imap_host','imap.gmail.com'),'port':int(get_setting(c,'imap_port','993') or 993),'security':get_setting(c,'imap_security','ssl'),'username':read_secret(c,'imap_username'),'password':read_secret(c,'imap_password'),'mailbox':get_setting(c,'imap_mailbox','INBOX'),'interval':int(get_setting(c,'poll_interval','5') or 5),'last_status':get_setting(c,'email_status','Not configured'),'last_poll':get_setting(c,'last_poll','')}

def connect_imap(cfg):
    """Open IMAP connection only (caller must login if still NONAUTH)."""
    host = (cfg.get('host') or 'imap.gmail.com').strip()
    port = int(cfg.get('port') or 993)
    security = (cfg.get('security') or 'ssl').lower()
    if security == 'ssl':
        m = imaplib.IMAP4_SSL(host, port, timeout=30)
    else:
        m = imaplib.IMAP4(host, port, timeout=30)
        m.starttls()
    return m

def imap_authenticate(m, user, password):
    """Login only if the session is still unauthenticated. Gmail/imaplib can
    already be AUTH (PREAUTH or a prior login), in which case LOGIN is illegal."""
    state = getattr(m, 'state', 'NONAUTH')
    if state in ('AUTH', 'SELECTED'):
        return
    try:
        m.login(user, password)
    except imaplib.IMAP4.error as e:
        msg = str(e)
        # Already authenticated — treat as success
        if getattr(m, 'state', '') in ('AUTH', 'SELECTED'):
            return
        if 'illegal in state AUTH' in msg or 'only allowed in states NONAUTH' in msg:
            return
        raise RuntimeError('IMAP login failed: ' + msg)

def process_mailbox(test_only=False):
    c = db()
    cfg = email_config(c)
    if not cfg['username'] or not cfg['password']:
        c.close()
        raise RuntimeError('Email username/password not configured')
    m = connect_imap(cfg)
    user = (cfg['username'] or '').strip()
    password = (cfg['password'] or '').replace(' ', '')
    if not user or not password:
        try:
            m.logout()
        except Exception:
            pass
        c.close()
        raise RuntimeError('Email username/password not configured')
    try:
        imap_authenticate(m, user, password)
    except Exception as e:
        try:
            m.logout()
        except Exception:
            pass
        c.close()
        raise RuntimeError(str(e))
    typ, _ = m.select(cfg['mailbox'])
    if typ != 'OK':
        m.logout(); c.close()
        raise RuntimeError(f'Cannot select mailbox {cfg["mailbox"]!r}')
    typ, data = m.uid('search', None, 'ALL')
    if typ != 'OK':
        m.logout(); c.close()
        raise RuntimeError('Mailbox search failed')
    uids = data[0].split()
    new = 0
    errors = 0
    skipped_parse = 0
    for rawuid in reversed(uids[-300:]):
        uid = rawuid.decode() if isinstance(rawuid, bytes) else str(rawuid)
        prev = c.execute('SELECT transaction_id, subject, sender FROM processed_emails WHERE uid=?', (uid,)).fetchone()
        if prev and prev['transaction_id'] is not None:
            continue
        typ, msgdata = m.uid('fetch', rawuid, '(RFC822)')
        if typ != 'OK' or not msgdata:
            continue
        raw = next((x[1] for x in msgdata if isinstance(x, tuple)), None)
        if not raw:
            continue
        try:
            msg = BytesParser(policy=policy.default).parsebytes(raw)
        except Exception:
            continue
        subject = str(msg.get('subject', '') or '')
        sender = str(msg.get('from', '') or '')
        message_id = str(msg.get('message-id', '') or '').strip()
        body = msg.as_string()
        looks_supported = bool(re.search(r'citi|citibank|trustbank\.sg|trust\s+bank|freedom\s+credit\s+card', subject + ' ' + sender + ' ' + body[:3000], re.I))
        try:
            parsed = parse_email(body)
        except Exception:
            errors += 1
            if prev:
                c.execute('DELETE FROM processed_emails WHERE uid=?', (uid,))
                c.commit()
            continue
        if not parsed or not parsed.get('amount'):
            skipped_parse += 1
            # Do not permanently skip Citi-looking mail that failed to parse
            if not looks_supported:
                c.execute(
                    'INSERT INTO processed_emails(uid,message_id,received_at,subject,sender,parser_version,transaction_id,processed_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(uid) DO NOTHING',
                    (uid, message_id or None, str(msg.get('date', '')), subject, sender, 'v3-skip', None, sg_now().isoformat()),
                )
                c.commit()
            if test_only and looks_supported:
                m.logout(); c.close()
                return {'ok': False, 'error': 'Citi-looking email found but could not parse. Subject: ' + subject[:120]}
            continue
        if test_only:
            m.logout(); c.close()
            return {'ok': True, 'parsed': parsed, 'subject': subject, 'sender': sender}
        if message_id:
            dup = c.execute('SELECT 1 FROM processed_emails WHERE message_id=? AND transaction_id IS NOT NULL', (message_id,)).fetchone()
            if dup:
                c.execute(
                    'INSERT INTO processed_emails(uid,message_id,received_at,subject,sender,parser_version,transaction_id,processed_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(uid) DO UPDATE SET message_id=excluded.message_id',
                    (uid, message_id, str(msg.get('date', '')), subject, sender, 'v3-dup', -1, sg_now().isoformat()),
                )
                c.commit()
                continue
        try:
            rid = insert_tx(parsed)
        except Exception as e:
            errors += 1
            set_setting(c, 'email_status', 'ERROR · insert failed: ' + str(e)[:250])
            c.commit()
            continue
        c.execute(
            'INSERT INTO processed_emails(uid,message_id,received_at,subject,sender,parser_version,transaction_id,processed_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(uid) DO UPDATE SET message_id=excluded.message_id, transaction_id=excluded.transaction_id, processed_at=excluded.processed_at, parser_version=excluded.parser_version',
            (uid, message_id or None, str(msg.get('date', '')), subject, sender, 'v4-citi-trust-1', rid, sg_now().isoformat()),
        )
        c.commit()
        new += 1
    try:
        m.close()
    except Exception:
        pass
    try:
        m.logout()
    except Exception:
        pass
    status = f'OK · imported {new} new transaction(s)'
    if skipped_parse:
        status += f' · {skipped_parse} unparsed'
    if errors:
        status += f' · {errors} error(s)'
    set_setting(c, 'last_poll', sg_now().isoformat())
    set_setting(c, 'email_status', status)
    c.commit(); c.close()
    return {'ok': True, 'imported': new, 'skipped_parse': skipped_parse, 'errors': errors}


def poll_loop():
    while True:
        try:
            c=db();cfg=email_config(c);c.close()
            if cfg['enabled'] and cfg['username'] and cfg['password']:
                try: process_mailbox(False)
                except Exception as e:
                    c=db();set_setting(c,'email_status','ERROR · '+str(e)[:300]);c.commit();c.close()
            time.sleep(max(1,cfg['interval']*60))
        except Exception: time.sleep(60)

@app.on_event('startup')
def startup():
    db(); threading.Thread(target=poll_loop,daemon=True).start()

@app.get('/',response_class=HTMLResponse)
def home(): return (BASE/'static/index.html').read_text()

def migrate_maybank_cashback_rules():
    """Recompute Maybank XL + F&F rewards under current T&C logic (one-shot)."""
    c = db()
    done = get_setting(c, 'migrate_maybank_tnc_v2', '')
    if done == '1':
        c.close()
        return
    rows = c.execute("SELECT * FROM transactions WHERE card_id IN ('maybank_xl_rewards','maybank_fnf') ORDER BY transaction_date, id").fetchall()
    for r in rows:
        tx = dict(r)
        miles, cash, status = calc_reward(tx, c, True)
        c.execute('UPDATE transactions SET miles=?, cashback=?, reward_status=? WHERE id=?',
                  (miles, cash, status, r['id']))
    set_setting(c, 'migrate_maybank_tnc_v2', '1')
    c.commit()
    c.close()


@app.get('/api/summary')
def summary():
    migrate_maybank_cashback_rules()
    c=db()
    rows=c.execute('SELECT * FROM transactions ORDER BY transaction_date DESC,id DESC').fetchall()
    mappings=[dict(r) for r in c.execute('SELECT * FROM merchant_mcc_rules ORDER BY merchant_name COLLATE BINARY').fetchall()]
    total=sum(float(r['amount'] or 0) for r in rows)
    miles=sum(float(r['miles'] or 0) for r in rows)
    cash=sum(float(r['cashback'] or 0) for r in rows)
    today=sg_today()
    this_month=today.strftime('%Y-%m')
    prev=(today.replace(day=1)-timedelta(days=1)).strftime('%Y-%m')

    def month_rows(month):
        return [r for r in rows if str(r['transaction_date'] or '')[:7]==month]
    def stats_for_rows(rs):
        return {
            'spend':round(sum(float(r['amount'] or 0) for r in rs),2),
            'count':len(rs),
            'miles':round(sum(float(r['miles'] or 0) for r in rs),2),
            'cashback':round(sum(float(r['cashback'] or 0) for r in rs),2),
            'citi_bonus_points':round(sum(max(0.0,(float(r['miles'] or 0)*2.5)-int(float(r['amount'] or 0))) for r in rs if r['card_id']=='citi_rewards'),2),
        }
    def month_stats(month): return stats_for_rows(month_rows(month))

    by_card=[]
    for cid,meta in CARDS.items():
        cr=[r for r in rows if r['card_id']==cid]
        cur=[r for r in cr if str(r['transaction_date'] or '')[:7]==this_month]
        by_card.append({
            'card_id':cid,
            'spend':round(sum(float(r['amount'] or 0) for r in cr),2),
            'miles':round(sum(float(r['miles'] or 0) for r in cr),2),
            'cashback':round(sum(float(r['cashback'] or 0) for r in cr),2),
            'count':len(cr),
            'this_month_spend':round(sum(float(r['amount'] or 0) for r in cur),2),
            'this_month_count':len(cur),
            'this_month_miles':round(sum(float(r['miles'] or 0) for r in cur),2),
            'this_month_cashback':round(sum(float(r['cashback'] or 0) for r in cur),2),
        })
    preferred=fnf_preferred_categories(c)
    email_status=get_setting(c,'email_status','Not configured')
    last_poll=get_setting(c,'last_poll','')
    c.close()
    return {
        'total_spend':round(total,2),
        'miles':round(miles,2),
        'cashback':round(cash,2),
        'count':len(rows),
        'current_month':this_month,
        'previous_month':prev,
        'this_month':month_stats(this_month),
        'previous_month_stats':month_stats(prev),
        'timezone':'Asia/Singapore',
        'utc_offset':'+08:00',
        'server_time':sg_now().strftime('%d %b %Y %H:%M'),
        'email_status':email_status,
        'last_poll':last_poll,
        'by_card':by_card,
        'transactions':[dict(r) for r in rows],
        'merchant_mcc_rules':mappings,
        'fnf_categories':list(FNF_MCC.keys()),
        'fnf_preferred':preferred,
    }

@app.post('/api/ingest-email')
def ingest_email(body:str=Form(...)):
    parsed=parse_email(body)
    if not parsed:return {'ok':False,'error':'Could not parse a supported transaction email'}
    rid=insert_tx(parsed);c=db();row=c.execute('SELECT * FROM transactions WHERE id=?',(rid,)).fetchone();c.close();return {'ok':True,'id':rid,'parsed':dict(row)}


@app.put('/api/transactions/{txid}/mcc')
def update_mcc(txid:int,payload:dict):
    mcc=int(payload.get('mcc',0));
    if mcc<0 or mcc>9999:return {'ok':False,'error':'MCC must be between 0 and 9999'}
    c=db();row=c.execute('SELECT * FROM transactions WHERE id=?',(txid,)).fetchone()
    if not row:c.close();return {'ok':False,'error':'Transaction not found'}
    merchant=row['merchant'];c.execute('INSERT INTO merchant_mcc_rules(merchant_name,mcc,note,source,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(merchant_name) DO UPDATE SET mcc=excluded.mcc,note=excluded.note,source=excluded.source,updated_at=excluded.updated_at',(merchant,mcc,'User-confirmed exact merchant-name MCC mapping','user',sg_now().isoformat()));affected=recalc_all_for_merchant(c,merchant);c.commit();c.close();return {'ok':True,'affected_transactions':affected,'merchant':merchant,'mcc':mcc}

@app.delete('/api/merchant-mcc/{merchant}')
def delete_mapping(merchant:str):
    c=db();rule=exact_mcc_rule(c,merchant);c.execute('DELETE FROM merchant_mcc_rules WHERE merchant_name=? COLLATE BINARY',(merchant,));rows=c.execute('SELECT * FROM transactions WHERE merchant=? COLLATE BINARY',(merchant,)).fetchall()
    for r in rows:
        tx=dict(r);tx['mcc']=None;tx['transaction_channel']=r['transaction_channel'] or 'unknown';miles,cash,status=calc_reward(tx,c,True);c.execute('UPDATE transactions SET mcc=NULL,mcc_source="unverified",mcc_confidence="LOW",mcc_note="No MCC mapping yet",miles=?,cashback=?,reward_status=? WHERE id=?',(miles,cash,status,r['id']))
    c.commit();c.close();return {'ok':True,'removed':bool(rule)}

@app.put('/api/transactions/{txid}/channel')
def update_transaction_channel(txid:int,payload:dict):
    ch=payload.get('transaction_channel','unknown')
    if ch not in {'unknown','online','in_store','mobile_wallet','travel'}:return {'ok':False,'error':'Invalid channel'}
    c=db();row=c.execute('SELECT * FROM transactions WHERE id=?',(txid,)).fetchone()
    if not row:c.close();return {'ok':False,'error':'Transaction not found'}
    tx=dict(row);tx['transaction_channel']=ch;miles,cash,status=calc_reward(tx,c,True);c.execute('UPDATE transactions SET transaction_channel=?,miles=?,cashback=?,reward_status=? WHERE id=?',(ch,miles,cash,status,txid));c.commit();c.close();return {'ok':True}

@app.delete('/api/transactions/{txid}')
def delete_transaction(txid:int): c=db();c.execute('DELETE FROM transactions WHERE id=?',(txid,));c.commit();c.close();return {'ok':True}

@app.get('/api/fnf-categories')
def get_fnf_categories():
    c = db()
    preferred = fnf_preferred_categories(c)
    c.close()
    return {'all': list(FNF_MCC.keys()), 'preferred': preferred, 'defaults': FNF_DEFAULT_PREFERRED}

@app.put('/api/fnf-categories')
def put_fnf_categories(payload: dict):
    cats = payload.get('preferred') or []
    cats = [str(x).strip() for x in cats if str(x).strip() in FNF_MCC]
    if len(cats) != 5:
        return {'ok': False, 'error': 'Select exactly 5 preferred categories'}
    c = db()
    set_setting(c, 'fnf_preferred_categories', '|'.join(cats))
    # Recalc all F&F transactions under new selection
    rows = c.execute("SELECT * FROM transactions WHERE card_id='maybank_fnf' ORDER BY transaction_date, id").fetchall()
    for r in rows:
        tx = dict(r)
        miles, cash, status = calc_reward(tx, c, True)
        c.execute('UPDATE transactions SET miles=?, cashback=?, reward_status=? WHERE id=?',
                  (miles, cash, status, r['id']))
    c.commit(); c.close()
    return {'ok': True, 'preferred': cats}

@app.get('/api/cards')
def cards(): return CARDS

@app.get('/api/email-settings')
def get_email_settings():
    c=db();cfg=email_config(c);c.close();return {'enabled':cfg['enabled'],'host':cfg['host'],'port':cfg['port'],'security':cfg['security'],'username':cfg['username'],'password_set':bool(cfg['password']),'mailbox':cfg['mailbox'],'interval':cfg['interval'],'last_status':cfg['last_status'],'last_poll':cfg['last_poll']}

@app.put('/api/email-settings')
def update_email_settings(payload:dict):
    c=db();set_setting(c,'email_enabled','1' if payload.get('enabled') else '0');set_setting(c,'imap_host',str(payload.get('host','imap.gmail.com')).strip() or 'imap.gmail.com');set_setting(c,'imap_port',str(int(payload.get('port',993) or 993)));set_setting(c,'imap_security',payload.get('security','ssl'));set_setting(c,'imap_mailbox',str(payload.get('mailbox','INBOX')).strip() or 'INBOX');set_setting(c,'poll_interval',str(max(1,int(payload.get('interval',5)))))
    if 'username' in payload: save_secret(c,'imap_username',str(payload.get('username','')).strip())
    if payload.get('password'): save_secret(c,'imap_password',str(payload['password']).replace(' ',''))
    set_setting(c,'email_status','Saved. Use Test Connection to verify.');c.commit();c.close();return {'ok':True}

@app.post('/api/email-test')
def email_test():
    try:
        result=process_mailbox(True)
        if not result.get('ok', True):
            return {'ok': False, 'error': result.get('error') or 'Connection or parse failed'}
        return {'ok':True,'message':'Connection and mailbox access succeeded.','preview':result.get('parsed'),'subject':result.get('subject',''),'sender':result.get('sender','')}
    except Exception as e:return {'ok':False,'error':str(e)}


@app.post('/api/email-reset-skips')
def email_reset_skips():
    """Clear processed markers for emails that never produced a transaction so they can be re-polled."""
    c = db()
    cur = c.execute('DELETE FROM processed_emails WHERE transaction_id IS NULL OR transaction_id < 0')
    n = cur.rowcount
    c.commit(); c.close()
    return {'ok': True, 'cleared': n}

@app.post('/api/email-poll')
def email_poll():
    try:return process_mailbox(False)
    except Exception as e:return {'ok':False,'error':str(e)}
