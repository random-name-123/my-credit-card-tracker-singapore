# Miles Tracker V10

Self-hosted credit-card miles tracker. V7 tracks Citi Rewards, Maybank cards, and Trust Freedom transactions ingested from a Gmail account over IMAP.

## Important security model
- Do not put Gmail credentials in Git or `.env`.
- Enter your **Gmail address** and a Google **App Password** in **Email Settings** in the app.
- The app password is encrypted locally using a generated key stored in `data/.credential_key`.
- `data/` is ignored by Git and contains the SQLite database and encryption key.
- Do not expose port 8000 directly to the public Internet. Tailscale is recommended.

## Gmail setup
Gmail no longer accepts your regular account password for IMAP, so you need an **App Password**:
1. Turn on 2-Step Verification on the Google account, if it isn't already: https://myaccount.google.com/signinoptions/two-step-verification
2. Generate an App Password at https://myaccount.google.com/apppasswords, choosing "Mail" as the app. Google gives you a 16-character code.
3. In the app, go to **Email Settings**, enter the Gmail address in **Gmail address** and the 16-character code in **App password**, then **Save Email Settings**.
4. Click **Test Connection** to confirm login and mailbox access work before relying on automatic polling.

Consider using a dedicated Gmail account (or a Gmail filter that labels/forwards Citi alert emails into a folder you point the app at) rather than your primary inbox, since the app password grants full IMAP access to whatever mailbox it's pointed at.

The app connects directly to `imap.gmail.com:993` over SSL/TLS by default. These IMAP host/port/security/mailbox settings are exposed under **Advanced IMAP settings** in the Email Settings panel and normally don't need to change.

## Run
```bash
docker compose up -d --build
```
Then open `http://127.0.0.1:8000` locally, or the server's Tailscale address from an authorized device.

## V5 features
- Citi Singapore transaction email parser based on the supplied Citi alert format.
- Gmail IMAP polling with duplicate-message protection.
- Browser-based mailbox configuration; no mailbox credentials in source code or `.env`.
- Encrypted mailbox credentials at rest.
- Persistent exact merchant-name MCC overrides.
- Editing an MCC updates all existing transactions with the exact same merchant string and all future matching transactions.
- Manual channel selection for Citi online/in-store/mobile-wallet/travel classification.
- Trust Freedom transaction parser based on the supplied Trust alert format.
- Trust Freedom imports the cashback amount explicitly stated in the Trust transaction email, avoiding assumptions about which Freedom reward mode is selected.
- Dashboard is redesigned in the supplied desktop/mobile mockup style with responsive KPI cards, reward summaries, a six-month trend view, recent transactions, and per-card performance.
- Dashboard shows current-month spend, miles, cashback, and transaction count, plus previous-month spend and a per-card breakdown of spend + miles/cashback earned.
- Citi 10X bonus-cap calculations still use the configured statement date internally so rewards remain accurate, but the statement-cycle details are intentionally hidden from the daily dashboard.
- Dashboard transaction list defaults to the current month and has an All toggle.
- Transaction table is explicitly redrawn after refresh, including pagination and filtering.

## Maybank cashback (from official T&Cs)

### Maybank XL Cashback
- **5%** on Dine, Shop, Travel, Play MCCs and all foreign-currency spend when calendar-month eligible spend ≥ **S$500**
- Bonus cashback capped at **S$80/month**; **0.2%** base thereafter and on non-bonus spend
- Etiqa (MCC 6300) earns 0.2% and does not count toward the minimum spend

### Maybank Family & Friends (effective 1 Jan 2026)
- **Base 0.22%** when monthly spend &lt; S$800
- **Tier 1** (S$800–S$1,599.99): **6%** on 5 preferred categories + MYR/IDR, cap **S$20/category** (S$120 total)
- **Tier 2** (S$1,600+): **8%** (Groceries max **6%**), cap **S$30/category** (S$180 total)
- After category cap: 0.22%
- Choose preferred categories in the Dashboard (exactly 5 of 10)


## V7 daily-use improvements

- App-wide time zone is explicitly `Asia/Singapore` (SGT / UTC+8), independent of the server's local time zone.
- Transaction date and time are stored separately; Citi and Trust transaction-alert times are retained and displayed in SGT.
- Manual transaction entry includes a Singapore-time date and time field.
- Dashboard shows the last refresh time in SGT and auto-refreshes every 2 minutes while the browser tab is visible.
- Added quick card filters for Citi Rewards, Maybank F&F, Maybank XL and Trust Freedom.
- Responsive/mobile layout includes larger touch targets and horizontally scrollable data tables where detailed columns cannot fit.
- Monetary values are displayed explicitly as S$ to avoid currency ambiguity.

## V10 daily-use improvements

- Dashboard month selector with newest available month first (`MM-YYYY spend`).
- Card filter drives the dashboard, rewards summary, recent transactions, and transaction list.
- Recent-transactions dashboard view plus full searchable transaction table.
- Objective reward efficiency: Citi miles shown as mpd; cashback cards shown as effective cashback %.
- Gmail sync status and one-tap manual poll from the dashboard.
- Unknown-MCC attention indicator and filter.
- Dark mode preference saved locally in the browser.
- Mobile bottom navigation and responsive mobile-first layout.
- Installable web-app manifest and app icon.
- Singapore timezone remains the application-wide source of truth (`Asia/Singapore`, UTC+8).
- Duplicate bank emails remain protected by the existing processed-email/message-ID logic.

The Citi statement-cycle calculation remains internal to reward computation; its statement-cycle details are intentionally not shown on the daily dashboard.
