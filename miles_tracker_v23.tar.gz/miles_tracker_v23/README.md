# Miles Tracker V16

Self-hosted FastAPI + SQLite credit-card miles/cashback tracker.

## V16 changes
- Maybank MYR/IDR foreign-currency parsing.
- Maybank-only foreign-currency conversion to SGD using the current Google Finance spot quote at import time.
- Stores the FX snapshot on each transaction; historical transactions are not silently changed when FX moves.
- Maybank cashback/monthly-spend calculations use the stored SGD equivalent.
- Optional final posted SGD amount can override the FX estimate for Maybank foreign transactions.
- Transactions can be edited from the transaction list.
- Edit supports merchant, original amount, date, and (for Maybank foreign currency) final posted SGD amount and manual FX rate.
- Existing database and credential key must be preserved during upgrades.

## Foreign-currency fields
- `amount` / `currency`: original card-alert amount.
- `spend_sgd`: SGD amount used for Maybank reward calculations.
- `fx_rate`: SGD per 1 unit of foreign currency.
- `fx_source`: Google Finance spot, Manual, or same-currency.
- `posted_amount_sgd`: optional final statement amount; takes precedence over the FX estimate.

Google Finance is accessed by the application server at import/edit time. If unavailable, the transaction keeps any existing stored FX data rather than inventing a rate.


## V22 parser debugging
- Unparsed supported-card emails now retain a readable email body for debugging.
- The Unparsed card emails section has a “View email contents” expander.
- Older unparsed issues without stored content can fetch the original message from the configured IMAP mailbox when opened.
- Existing `data/miles.db` and `data/.credential_key` must be preserved when upgrading.
