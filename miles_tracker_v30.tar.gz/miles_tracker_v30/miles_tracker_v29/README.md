# Miles Tracker V29

V29 fixes Maybank Family & Friends foreign-currency reward allocation.

## Maybank F&F FX / Repeat Categories fix
- Repeat Categories thresholds remain SGD-denominated by the 2026 T&Cs.
- Foreign transactions are never treated as if their MYR/IDR face value were SGD.
- For example, the Tier 1 S$333.34 allowance is approximately MYR 1,063.35 at MYR 3.19 per S$1 (333.34 × 3.19). The exact equivalent changes with FX.
- Missing foreign FX snapshots are resolved from Google Finance once per currency during F&F monthly recalculation when available.
- Stored posted SGD amounts remain authoritative when entered.
- Stored FX snapshots remain authoritative for the transaction's SGD spend unless the snapshot is missing.
- F&F monthly reward allocation is recalculated after FX repair.
- Mixed SGD + foreign-currency transactions continue to be tracked against the SGD-denominated threshold, avoiding currency-mixing errors.

## Upgrade
Preserve your existing `data/miles.db` and `data/.credential_key`.
Do not copy a release archive's `data` directory over your live data.
