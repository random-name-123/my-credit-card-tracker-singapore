# Miles Tracker V3

Self-hosted credit-card miles tracker. V3 currently focuses on Citi Rewards, ingested from a Gmail account over IMAP.

## Important security model
- Do not put Gmail credentials in Git or `.env`.
- Enter your **Gmail address** and a Google **App Password** in **Email Settings** in the app.
- The app password is encrypted locally using a generated key stored in `data/.credential_key`.
- `data/` is ignored by Git and contains the SQLite database and encryption key.
- Do not expose port 8000 directly to the public Internet. Tailscale is recommended.

## Gmail setup
Gmail no longer accepts your regular account password for IMAP, so you need an **App Password**:
1. Turn on 2-Step Verification on the Google account, if it isn't already: https://myaccount.google.com/signinoptions/two-step-verification
2. Generate an App Password at https://myaccount.google.com/apppasswords, choosing "Mail" as the app. Google gives you a 16-character code.
3. In the app, go to **Email Settings**, enter the Gmail address in **Gmail address** and the 16-character code in **App password**, then **Save Email Settings**.
4. Click **Test Connection** to confirm login and mailbox access work before relying on automatic polling.

Consider using a dedicated Gmail account (or a Gmail filter that labels/forwards Citi alert emails into a folder you point the app at) rather than your primary inbox, since the app password grants full IMAP access to whatever mailbox it's pointed at.

The app connects directly to `imap.gmail.com:993` over SSL/TLS by default. These IMAP host/port/security/mailbox settings are exposed under **Advanced IMAP settings** in the Email Settings panel and normally don't need to change.

## Run
```bash
docker compose up -d --build
```
Then open `http://127.0.0.1:8000` locally, or the server's Tailscale address from an authorized device.

## V3 features
- Citi Singapore transaction email parser based on the supplied Citi alert format.
- Gmail IMAP polling with duplicate-message protection.
- Browser-based mailbox configuration; no mailbox credentials in source code or `.env`.
- Encrypted mailbox credentials at rest.
- Persistent exact merchant-name MCC overrides.
- Editing an MCC updates all existing transactions with the exact same merchant string and all future matching transactions.
- Manual channel selection for Citi online/in-store/mobile-wallet/travel classification.
