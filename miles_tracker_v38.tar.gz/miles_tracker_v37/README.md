# Miles Tracker V37

V37 builds on V36, fixes Maybank XL Cashback month-wide reward recalculation, and automatically sets every transaction whose merchant name starts with `AMAZE*` to the `online` transaction channel, then recalculates rewards. This applies to new imports, edits, and existing transactions during a one-time migration.

## AMAZE* online-channel rule
- Any merchant name beginning with `AMAZE*` (case-insensitive, ignoring leading spaces) is automatically assigned `online`.
- Existing AMAZE* transactions are migrated to `online` on the first startup after upgrading, and their reward/miles/cashback fields are recalculated.
- The app enforces this rule when adding, editing, or manually changing the channel of an AMAZE* transaction.

## MCC catalogue and reward recalculation
- Transactions display the MCC description beside the numeric code where a built-in description is available.
- The catalogue is shared across Visa and Mastercard because the MCC code is the category identifier; the MCC actually assigned to a merchant can still differ by acquirer, merchant setup, or transaction route.
- Exact merchant-name mappings remain stored locally in SQLite and continue to apply to existing and future transactions with the exact same merchant string.
- Editing a merchant's MCC now recalculates the reward and status fields for affected non-F&F transactions as well as updating the MCC. Maybank F&F transactions still receive the month-wide recalculation.
- Added descriptions for common categories including grocery, food, fuel, online/digital goods, retail, telecom, travel, transport, entertainment, and lodging. This is a built-in starter catalogue, not a claim that every network-specific or newly introduced MCC is included.


## Maybank XL Cashback logic (V37)
- Applies the S$500 calendar-month minimum-spend test using eligible Maybank XL retail transactions, not just bonus-category transactions.
- Awards 5% on the official Dine, Shop, Travel, Play and foreign-currency categories once the monthly minimum is met; otherwise eligible transactions earn 0.2% base cashback.
- Enforces the S$80 monthly 5% bonus-cashback cap, then returns excess spend to 0.2% base cashback.
- Recalculates all XL transactions for the month after imports, MCC changes, transaction edits/deletions, and before dashboard/transaction data is returned, so older rows do not retain stale `0.2% / BASE` statuses.
- Refunds/reversals and T&C-excluded transactions do not earn cashback or count toward the S$500 minimum. MCC 6300 Etiqa transactions receive 0.2% but do not count toward minimum spend.
- Cashback is rounded down to two decimal places per transaction as an estimate; Maybank may aggregate/round by category when crediting the actual statement reward.

## Upgrade
Preserve your existing `data/miles.db` and `data/.credential_key`. Do not copy a release archive's `data` directory over your live data. The archive excludes runtime databases, credential keys, Python bytecode, and cache directories.

## Existing V33 fixes retained
- Maybank refund SMS parsing (refunds stored as negative transactions).
- Google Finance FX lookup with a fallback provider.
- Foreign-currency Maybank spending uses SGD equivalents for dashboard totals and F&F thresholds.
- F&F monthly cashback is recalculated month-wide when required.


## V38 changes
- Added a Maybank Family & Friends monthly category tracker with donut charts showing cashback-cap utilisation, category spending in SGD equivalents, cashback earned, and the monthly cap.
- Added a compact V38 indicator in the top-right header.
- Uses the configured F&F preferred categories and the 1 Jan 2026 programme tier/cap structure. Chart values are estimates from imported transaction MCCs and reward statuses; verify against Maybank TREATS for final posted awards.
