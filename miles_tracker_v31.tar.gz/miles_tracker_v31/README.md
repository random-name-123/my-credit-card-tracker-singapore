# Miles Tracker V31

V30 fixes the Maybank Family & Friends monthly cashback calculation and repairs stale foreign-currency values left by earlier versions.

## Maybank F&F calculation fixes
- All Maybank F&F monthly thresholds are calculated from the same SGD-equivalent spend used by the dashboard.
- Foreign MYR/IDR face values are never treated as SGD.
- Posted SGD amounts are authoritative when entered.
- Explicit Manual FX values are preserved.
- Non-manual Google Finance FX snapshots for Maybank F&F are refreshed before monthly recalculation so stale/incorrect V29 FX values cannot survive.
- Tier 1 requires S$800 monthly eligible spend; Tier 2 requires S$1,600.
- Repeat Categories thresholds remain SGD-denominated under the 2026 T&Cs: S$333.34 Tier 1, S$375 Tier 2, S$500 Groceries.
- MYR/IDR transactions that also fall in a preferred category consume the category's Repeat Categories allowance first; only the excess becomes MYR/IDR bonus-category spend.
- Cashback caps are tracked independently by category/bucket.
- Every F&F transaction in a month is recalculated together, preventing stale 0.22%/BASE or old cashback values from remaining after FX/MCC/category changes.
- Changing the five preferred categories now triggers a month-wide F&F recalculation.
- Deleting a F&F transaction triggers a month-wide recalculation for its month.
- Dashboard card spend and backend card totals use the same SGD-equivalent calculation.

## Example
For MYR 104.40 at 1 SGD = 3.19 MYR:
- SGD equivalent ≈ S$32.73.
- The Tier 1 S$333.34 Repeat Categories allowance is ≈ MYR 1,063.35.
- A MYR 104.40 transaction therefore does not consume the Repeat Categories allowance beyond its SGD-equivalent amount and must not be treated as S$104.40.

## Upgrade
Preserve your existing `data/miles.db` and `data/.credential_key`.
Do not copy a release archive's `data` directory over your live data.
V31 additionally recalculates all F&F calendar months on every dashboard/transaction refresh, so stored cashback statuses cannot become stale. This is intentional and inexpensive for the local SQLite workload. Existing FX/MCC/category settings are preserved.
