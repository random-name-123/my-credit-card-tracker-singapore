from fastapi import FastAPI, Form
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from bs4 import BeautifulSoup
from cryptography.fernet import Fernet, InvalidToken
from datetime import datetime, date, timedelta
from pathlib import Path
import sqlite3, re, imaplib, email, os, threading, time, hashlib
from email import policy
from email.parser import BytesParser

BASE = Path(__file__).resolve().parent
DB = BASE.parent / 'data' / 'miles.db'
KEYFILE = BASE.parent / 'data' / '.credential_key'
DB.parent.mkdir(exist_ok=True)
app = FastAPI(title='Miles Tracker V3')
app.mount('/static', StaticFiles(directory=str(BASE/'static')), name='static')

CARDS = {'citi_rewards': {'name':'Citi Rewards Mastercard','type':'miles'}, 'maybank_fnf': {'name':'Maybank Family & Friends Mastercard','type':'cashback'}, 'maybank_xl_rewards': {'name':'Maybank XL Rewards','type':'miles'}}
MCC = {5311:'Department Stores',5611:"Men's and Boys' Clothing and Accessories Stores",5621:"Women's Ready-to-Wear",5631:"Women's Accessory/Specialty",5641:'Children/Infant Clothing',5651:'Family Clothing',5655:'Sports/Riding Apparel',5661:'Shoe Stores',5691:"Men's/Women's Clothing",5699:'Misc Apparel/Accessories',5948:'Luggage/Leather Goods',5411:'Grocery Stores/Supermarkets',5811:'Caterers',5812:'Eating Places/Restaurants',5814:'Fast Food Restaurants',4111:'Passenger Transportation',4112:'Passenger Railways',4121:'Taxicabs/Limousines',4789:'Transportation Services',4511:'Airlines',4722:'Travel Agencies',7011:'Lodging'}
CITI_SHOPPING_MCC = {5311,5611,5621,5631,5641,5651,5655,5661,5691,5699,5948}
CITI_TRAVEL_MCC = set(range(3000,4000)) | {4111,4112,4789,4411,4511,4722,4723,5962,7011,7012,7512}
XL = {'Dine':{5811,5812,5814,5462},'Shop':{5262,5310,5311,5331,5399,5621,5631,5651,5655,5661,5691,5699,5941},'Play':{4899,5813,5815,7832,7993,7994},'Travel':set(range(3000,3300))|set(range(3300,3309))|{4511,4722,7011}}


def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row
    c.execute("""CREATE TABLE IF NOT EXISTS transactions(id INTEGER PRIMARY KEY,transaction_date TEXT,posted_date TEXT,merchant TEXT,amount REAL,currency TEXT,card_id TEXT,last4 TEXT,mcc INTEGER,mcc_source TEXT,mcc_confidence TEXT,mcc_note TEXT,transaction_channel TEXT DEFAULT 'unknown',miles REAL DEFAULT 0,cashback REAL DEFAULT 0,reward_status TEXT,raw_summary TEXT,created_at TEXT)""")
    c.execute("CREATE TABLE IF NOT EXISTS card_settings(card_id TEXT PRIMARY KEY,statement_day INTEGER DEFAULT 1)")
    c.execute("""CREATE TABLE IF NOT EXISTS merchant_mcc_rules(merchant_name TEXT PRIMARY KEY COLLATE BINARY,mcc INTEGER NOT NULL,note TEXT,source TEXT NOT NULL DEFAULT 'user',updated_at TEXT NOT NULL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS app_settings(key TEXT PRIMARY KEY,value TEXT NOT NULL,updated_at TEXT NOT NULL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS processed_emails(uid TEXT PRIMARY KEY,message_id TEXT,received_at TEXT,subject TEXT,sender TEXT,parser_version TEXT,transaction_id INTEGER,processed_at TEXT NOT NULL)""")
    cols={r['name'] for r in c.execute('PRAGMA table_info(transactions)').fetchall()}
    if 'transaction_channel' not in cols: c.execute("ALTER TABLE transactions ADD COLUMN transaction_channel TEXT DEFAULT 'unknown'")
    c.commit(); return c

def get_setting(c,key,default=''):
    r=c.execute('SELECT value FROM app_settings WHERE key=?',(key,)).fetchone(); return r['value'] if r else default

def set_setting(c,key,value):
    c.execute('INSERT INTO app_settings(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at',(key,value,datetime.utcnow().isoformat()))

def crypto():
    if not KEYFILE.exists(): KEYFILE.write_bytes(Fernet.generate_key()); os.chmod(KEYFILE,0o600)
    return Fernet(KEYFILE.read_bytes().strip())

def save_secret(c,key,value): set_setting(c,'secret:'+key,crypto().encrypt(value.encode()).decode())
def read_secret(c,key):
    v=get_setting(c,'secret:'+key,'')
    if not v:return ''
    try:return crypto().decrypt(v.encode()).decode()
    except (InvalidToken,ValueError):return ''

def exact_mcc_rule(c,merchant): return c.execute('SELECT * FROM merchant_mcc_rules WHERE merchant_name = ? COLLATE BINARY',(merchant,)).fetchone()

def extract_message_body(body):
    try:
        if re.search(r'(?im)^Content-Type:\s*multipart/', body) or re.search(r'(?im)^MIME-Version:', body):
            msg=BytesParser(policy=policy.default).parsebytes(body.encode('utf-8','ignore')); part=msg.get_body(preferencelist=('html','plain'))
            if part is not None:return part.get_content()
    except Exception: pass
    return body

def parse_citi_email(body):
    body=extract_message_body(body); text=re.sub(r'\s+',' ',BeautifulSoup(body,'html.parser').get_text(' ',strip=True))
    if not re.search(r'citi|citibank',text,re.I): return None
    am=re.search(r'Transaction\s+amount\s*:\s*SGD\s*([0-9,]+\.\d{2})',text,re.I)
    dm=re.search(r'Transaction\s+date\s*:\s*(\d{1,2})/(\d{1,2})/(\d{2,4})',text,re.I)
    tm=re.search(r'Transaction\s+time\s*:\s*([0-9]{2}:[0-9]{2}:[0-9]{2})',text,re.I)
    mm=re.search(r'Transaction\s+details\s*:\s*(.+?)(?=\s+If\s+you\s+did\s+not\s+make|\s+Thank\s+you\s+for\s+banking)',text,re.I)
    cm=re.search(r'Account\s+number\s*:\s*X+[-\sX]*(\d{4})',text,re.I)
    if not(am and dm and mm): return None
    d,m,y=map(int,dm.groups()); y+=2000 if y<100 else 0
    return {'merchant':re.sub(r'\s+',' ',mm.group(1)).strip()[:160],'amount':float(am.group(1).replace(',','')),'currency':'SGD','transaction_date':date(y,m,d).isoformat(),'posted_date':date(y,m,d).isoformat(),'card_id':'citi_rewards','last4':cm.group(1) if cm else '','transaction_channel':'unknown','summary':text[:1000],'transaction_time':tm.group(1) if tm else ''}

def parse_email(body):
    citi=parse_citi_email(body)
    if citi:return citi
    text=re.sub(r'\s+',' ',BeautifulSoup(body,'html.parser').get_text(' ',strip=True)); amount=0
    for p in [r'(?:SGD|S\$)\s*([0-9,]+\.\d{2})',r'\$\s*([0-9,]+\.\d{2})']:
        m=re.search(p,text,re.I)
        if m: amount=float(m.group(1).replace(',',''));break
    dm=re.search(r'\b(\d{1,2})[/-](\d{1,2})[/-](20\d{2})\b',text); tx_date=date.today().isoformat()
    if dm:
        d,m,y=map(int,dm.groups());tx_date=date(y,m,d).isoformat()
    low=text.lower(); card='citi_rewards' if 'citi' in low and 'reward' in low else ''
    last4=(re.findall(r'(?:ending|ends|card)\D{0,12}(\d{4})',text,re.I) or [''])[-1]; merchant='Unknown merchant'
    for p in [r'(?:merchant|description|transaction)\s*[:\-]\s*([^|;]+?)(?:\s+(?:amount|date|card|reference)\s*[:\-]|$)',r'(?:at|from)\s+([A-Z0-9][A-Z0-9 &._\-]{2,80})']:
        m=re.search(p,text,re.I)
        if m: merchant=m.group(1).strip();break
    return {'merchant':merchant[:160],'amount':amount,'currency':'SGD','transaction_date':tx_date,'posted_date':tx_date,'card_id':card,'last4':last4,'transaction_channel':'unknown','summary':text[:1000]}

def citi_period(tx_date,statement_day=1):
    d=date.fromisoformat(tx_date)
    if statement_day<=1:return f'{d.year:04d}-{d.month:02d}'
    if d.day>=statement_day:return f'{d.year:04d}-{d.month:02d}'
    p=d.replace(day=1)-timedelta(days=1);return f'{p.year:04d}-{p.month:02d}'

def classify_citi(tx):
    mcc=tx.get('mcc'); ch=tx.get('transaction_channel') or 'unknown'
    if not mcc:return False,'BASE / MCC UNKNOWN'
    if mcc in CITI_SHOPPING_MCC:return True,'10X / SHOPPING MCC'
    if ch=='online' and mcc not in CITI_TRAVEL_MCC:return True,'10X / ONLINE'
    return False,'BASE'

def calc_reward(tx,c,include_self=False):
    amount=float(tx.get('amount') or 0);mcc=tx.get('mcc');card=tx.get('card_id');miles=cash=0;status='BASE'
    if card=='citi_rewards':
        eligible,label=classify_citi(tx);whole=int(amount)
        if eligible and whole>0:
            period=citi_period(tx['transaction_date']); params=[period+'%']; q="SELECT COALESCE(SUM(CASE WHEN reward_status LIKE '10X%' OR reward_status='CAP-PARTIAL' THEN CAST(amount AS INTEGER) ELSE 0 END),0) used FROM transactions WHERE card_id='citi_rewards' AND transaction_date LIKE ?"
            if include_self and tx.get('id'):q+=' AND id <> ?';params.append(tx['id'])
            used=int(c.execute(q,tuple(params)).fetchone()['used'] or 0);bonus=max(0,min(whole,1000-used));miles=(whole+9*bonus)/2.5;status=label if bonus==whole else ('CAP-PARTIAL' if bonus>0 else 'BASE / 10X CAP USED')
        else:miles=whole/2.5;status=label
    elif card=='maybank_xl_rewards':
        eligible=any(mcc in s for s in XL.values()) if mcc else False;miles=amount*4 if eligible else amount*0.4;status='10X' if eligible else 'BASE'
    elif card=='maybank_fnf': cash=amount*0.0022;status='BASE / F&F RULE PENDING'
    return round(miles,2),round(cash,2),status

def effective_mcc(c,merchant,supplied=None):
    if supplied is not None:return int(supplied),'user','HIGH','Manual MCC supplied'
    rule=exact_mcc_rule(c,merchant)
    if rule:return int(rule['mcc']),'user-exact-name','HIGH',rule['note'] or 'Exact merchant-name MCC mapping'
    return None,'unverified','LOW','No MCC mapping yet'

def insert_tx(data):
    c=db();mcc,src,conf,note=effective_mcc(c,data['merchant'],data.get('mcc'));data.update(mcc=mcc,mcc_source=src,mcc_confidence=conf,mcc_note=note,transaction_channel=data.get('transaction_channel') or 'unknown');miles,cash,status=calc_reward(data,c)
    cur=c.execute('INSERT INTO transactions(transaction_date,posted_date,merchant,amount,currency,card_id,last4,mcc,mcc_source,mcc_confidence,mcc_note,transaction_channel,miles,cashback,reward_status,raw_summary,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(data['transaction_date'],data.get('posted_date',data['transaction_date']),data['merchant'],data['amount'],data.get('currency','SGD'),data.get('card_id',''),data.get('last4',''),data['mcc'],data['mcc_source'],data['mcc_confidence'],data['mcc_note'],data['transaction_channel'],miles,cash,status,data.get('summary',''),datetime.utcnow().isoformat()));rid=cur.lastrowid;c.commit();c.close();return rid

def recalc_all_for_merchant(c,merchant):
    rows=c.execute('SELECT * FROM transactions WHERE merchant = ? COLLATE BINARY ORDER BY transaction_date,id',(merchant,)).fetchall();rule=exact_mcc_rule(c,merchant)
    for r in rows:
        tx=dict(r);tx['mcc']=int(rule['mcc']);tx['transaction_channel']=r['transaction_channel'] or 'unknown';miles,cash,status=calc_reward(tx,c,True);c.execute('UPDATE transactions SET mcc=?,mcc_source=?,mcc_confidence=?,mcc_note=?,miles=?,cashback=?,reward_status=? WHERE id=?',(tx['mcc'],'user-exact-name','HIGH',rule['note'] or 'Exact merchant-name MCC mapping',miles,cash,status,r['id']))
    return len(rows)

def email_config(c):
    return {'enabled':get_setting(c,'email_enabled','0')=='1','host':get_setting(c,'imap_host','127.0.0.1'),'port':int(get_setting(c,'imap_port','1143') or 1143),'security':get_setting(c,'imap_security','starttls'),'username':read_secret(c,'imap_username'),'password':read_secret(c,'imap_password'),'mailbox':get_setting(c,'imap_mailbox','INBOX'),'interval':int(get_setting(c,'poll_interval','5') or 5),'last_status':get_setting(c,'email_status','Not configured'),'last_poll':get_setting(c,'last_poll','')}

def connect_imap(cfg):
    if cfg['security']=='ssl': m=imaplib.IMAP4_SSL(cfg['host'],cfg['port'],timeout=30)
    else:
        m=imaplib.IMAP4(cfg['host'],cfg['port'],timeout=30);m.starttls()
    m.login(cfg['username'],cfg['password']);return m

def process_mailbox(test_only=False):
    c=db();cfg=email_config(c)
    if not cfg['username'] or not cfg['password']: raise RuntimeError('Email credentials are not configured')
    m=connect_imap(cfg); typ,_=m.select(cfg['mailbox'],readonly=False)
    if typ!='OK': raise RuntimeError('Could not select mailbox '+cfg['mailbox'])
    typ,data=m.uid('search',None,'ALL')
    if typ!='OK': raise RuntimeError('Mailbox search failed')
    uids=data[0].split(); new=0
    for rawuid in reversed(uids[-200:]):
        uid=rawuid.decode();
        if c.execute('SELECT 1 FROM processed_emails WHERE uid=?',(uid,)).fetchone(): continue
        typ,msgdata=m.uid('fetch',rawuid,'(RFC822)')
        if typ!='OK' or not msgdata: continue
        raw=next((x[1] for x in msgdata if isinstance(x,tuple)),None)
        if not raw: continue
        msg=BytesParser(policy=policy.default).parsebytes(raw); subject=str(msg.get('subject','')); sender=str(msg.get('from','')); message_id=str(msg.get('message-id',''))
        body=msg.as_string(); parsed=parse_email(body)
        if not parsed:
            c.execute('INSERT INTO processed_emails(uid,message_id,received_at,subject,sender,parser_version,transaction_id,processed_at) VALUES(?,?,?,?,?,?,?,?)',(uid,message_id,str(msg.get('date','')),subject,sender,'v3-citi-1',None,datetime.utcnow().isoformat())); c.commit(); continue
        if test_only: m.logout(); c.close(); return {'ok':True,'parsed':parsed,'subject':subject,'sender':sender}
        # duplicate protection using Message-ID when present
        if message_id and c.execute('SELECT 1 FROM processed_emails WHERE message_id=?',(message_id,)).fetchone(): continue
        rid=insert_tx(parsed)
        c.execute('INSERT INTO processed_emails(uid,message_id,received_at,subject,sender,parser_version,transaction_id,processed_at) VALUES(?,?,?,?,?,?,?,?)',(uid,message_id,str(msg.get('date','')),subject,sender,'v3-citi-1',rid,datetime.utcnow().isoformat())); c.commit(); new+=1
    m.close();m.logout();set_setting(c,'last_poll',datetime.utcnow().isoformat());set_setting(c,'email_status',f'OK · imported {new} new transaction(s)');c.commit();c.close();return {'ok':True,'imported':new}

def poll_loop():
    while True:
        try:
            c=db();cfg=email_config(c);c.close()
            if cfg['enabled'] and cfg['username'] and cfg['password']:
                try: process_mailbox(False)
                except Exception as e:
                    c=db();set_setting(c,'email_status','ERROR · '+str(e)[:300]);c.commit();c.close()
            time.sleep(max(1,cfg['interval']*60))
        except Exception: time.sleep(60)

@app.on_event('startup')
def startup():
    db(); threading.Thread(target=poll_loop,daemon=True).start()

@app.get('/',response_class=HTMLResponse)
def home(): return (BASE/'static/index.html').read_text()

@app.get('/api/summary')
def summary():
    c=db();rows=c.execute('SELECT * FROM transactions ORDER BY transaction_date DESC,id DESC').fetchall();mappings=[dict(r) for r in c.execute('SELECT * FROM merchant_mcc_rules ORDER BY merchant_name COLLATE BINARY').fetchall()];total=sum(r['amount'] for r in rows);miles=sum(r['miles'] for r in rows);cash=sum(r['cashback'] for r in rows);c.close();return {'total_spend':round(total,2),'miles':round(miles,2),'cashback':round(cash,2),'count':len(rows),'transactions':[dict(r) for r in rows],'merchant_mcc_rules':mappings}

@app.post('/api/ingest-email')
def ingest_email(body:str=Form(...)):
    parsed=parse_email(body)
    if not parsed:return {'ok':False,'error':'Could not parse a supported transaction email'}
    rid=insert_tx(parsed);c=db();row=c.execute('SELECT * FROM transactions WHERE id=?',(rid,)).fetchone();c.close();return {'ok':True,'id':rid,'parsed':dict(row)}

@app.post('/api/transaction')
def manual_transaction(payload:dict): return {'ok':True,'id':insert_tx(payload)}

@app.put('/api/transactions/{txid}/mcc')
def update_mcc(txid:int,payload:dict):
    mcc=int(payload.get('mcc',0));
    if mcc<0 or mcc>9999:return {'ok':False,'error':'MCC must be between 0 and 9999'}
    c=db();row=c.execute('SELECT * FROM transactions WHERE id=?',(txid,)).fetchone()
    if not row:c.close();return {'ok':False,'error':'Transaction not found'}
    merchant=row['merchant'];c.execute('INSERT INTO merchant_mcc_rules(merchant_name,mcc,note,source,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(merchant_name) DO UPDATE SET mcc=excluded.mcc,note=excluded.note,source=excluded.source,updated_at=excluded.updated_at',(merchant,mcc,'User-confirmed exact merchant-name MCC mapping','user',datetime.utcnow().isoformat()));affected=recalc_all_for_merchant(c,merchant);c.commit();c.close();return {'ok':True,'affected_transactions':affected,'merchant':merchant,'mcc':mcc}

@app.delete('/api/merchant-mcc/{merchant}')
def delete_mapping(merchant:str):
    c=db();rule=exact_mcc_rule(c,merchant);c.execute('DELETE FROM merchant_mcc_rules WHERE merchant_name=? COLLATE BINARY',(merchant,));rows=c.execute('SELECT * FROM transactions WHERE merchant=? COLLATE BINARY',(merchant,)).fetchall()
    for r in rows:
        tx=dict(r);tx['mcc']=None;tx['transaction_channel']=r['transaction_channel'] or 'unknown';miles,cash,status=calc_reward(tx,c,True);c.execute('UPDATE transactions SET mcc=NULL,mcc_source="unverified",mcc_confidence="LOW",mcc_note="No MCC mapping yet",miles=?,cashback=?,reward_status=? WHERE id=?',(miles,cash,status,r['id']))
    c.commit();c.close();return {'ok':True,'removed':bool(rule)}

@app.put('/api/transactions/{txid}/channel')
def update_transaction_channel(txid:int,payload:dict):
    ch=payload.get('transaction_channel','unknown')
    if ch not in {'unknown','online','in_store','mobile_wallet','travel'}:return {'ok':False,'error':'Invalid channel'}
    c=db();row=c.execute('SELECT * FROM transactions WHERE id=?',(txid,)).fetchone()
    if not row:c.close();return {'ok':False,'error':'Transaction not found'}
    tx=dict(row);tx['transaction_channel']=ch;miles,cash,status=calc_reward(tx,c,True);c.execute('UPDATE transactions SET transaction_channel=?,miles=?,cashback=?,reward_status=? WHERE id=?',(ch,miles,cash,status,txid));c.commit();c.close();return {'ok':True}

@app.delete('/api/transactions/{txid}')
def delete_transaction(txid:int): c=db();c.execute('DELETE FROM transactions WHERE id=?',(txid,));c.commit();c.close();return {'ok':True}
@app.get('/api/cards')
def cards(): return CARDS

@app.get('/api/email-settings')
def get_email_settings():
    c=db();cfg=email_config(c);c.close();return {'enabled':cfg['enabled'],'host':cfg['host'],'port':cfg['port'],'security':cfg['security'],'username':cfg['username'],'password_set':bool(cfg['password']),'mailbox':cfg['mailbox'],'interval':cfg['interval'],'last_status':cfg['last_status'],'last_poll':cfg['last_poll']}

@app.put('/api/email-settings')
def update_email_settings(payload:dict):
    c=db();set_setting(c,'email_enabled','1' if payload.get('enabled') else '0');set_setting(c,'imap_host',str(payload.get('host','127.0.0.1')).strip());set_setting(c,'imap_port',str(int(payload.get('port',1143))));set_setting(c,'imap_security',payload.get('security','starttls'));set_setting(c,'imap_mailbox',str(payload.get('mailbox','INBOX')).strip() or 'INBOX');set_setting(c,'poll_interval',str(max(1,int(payload.get('interval',5)))));set_setting(c,'imap_username', '') if False else None
    if 'username' in payload: save_secret(c,'imap_username',str(payload.get('username','')))
    if payload.get('password'): save_secret(c,'imap_password',str(payload['password']))
    set_setting(c,'email_status','Saved. Use Test Connection to verify.');c.commit();c.close();return {'ok':True}

@app.post('/api/email-test')
def email_test():
    try:
        c=db();cfg=email_config(c);c.close();result=process_mailbox(True);return {'ok':True,'message':'Connection and mailbox access succeeded.','preview':result.get('parsed'),'subject':result.get('subject',''),'sender':result.get('sender','')}
    except Exception as e:return {'ok':False,'error':str(e)}

@app.post('/api/email-poll')
def email_poll():
    try:return process_mailbox(False)
    except Exception as e:return {'ok':False,'error':str(e)}
