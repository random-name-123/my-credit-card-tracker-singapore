# Miles Tracker V3

Self-hosted credit-card miles tracker. V3 currently focuses on Citi Rewards and Proton Mail Bridge ingestion.

## Important security model
- Do not put Proton credentials in Git.
- Enter the Proton Mail Bridge mailbox username/password in **Email Settings** in the app.
- The password is encrypted locally using a generated key stored in `data/.credential_key`.
- `data/` is ignored by Git and contains the SQLite database and encryption key.
- Do not expose port 8000 directly to the public Internet. Tailscale is recommended.

## Proton Mail Bridge
Proton Bridge must already be installed, signed in, and running on the same Oracle host. The app connects to Bridge's local IMAP service. Use the Bridge mailbox password shown in Bridge, not the Proton account password.

The default Docker configuration uses host networking so `127.0.0.1` can refer to the Oracle host's Bridge service. Adjust the Bridge IMAP host/port/security in the UI if your Bridge configuration differs.

## Run
```bash
docker compose up -d --build
```
Then open `http://127.0.0.1:8000` locally, or the server's Tailscale address from an authorized device.

## V3 features
- Citi Singapore transaction email parser based on the supplied Citi alert format.
- Proton Bridge IMAP polling with duplicate-message protection.
- Browser-based mailbox configuration; no mailbox password in source code or `.env`.
- Encrypted mailbox credentials at rest.
- Persistent exact merchant-name MCC overrides.
- Editing an MCC updates all existing transactions with the exact same merchant string and all future matching transactions.
- Manual channel selection for Citi online/in-store/mobile-wallet/travel classification.
