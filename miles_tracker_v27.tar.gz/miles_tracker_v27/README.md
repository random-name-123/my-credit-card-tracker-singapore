# Miles Tracker V27

Self-hosted FastAPI + SQLite credit-card miles/cashback tracker.

## V27 — Dashboard cleanup and dedicated transactions view

- Removed the duplicate Rewards Summary panel from the dashboard.
- Added an All Cards aggregate tile to the card-summary row, alongside each individual card.
- Changed the dashboard trend panel to use the full available width.
- Kept the dashboard transaction area compact: it now shows only the latest 5 transactions with a View all transactions action.
- Moved the full searchable/filterable transaction ledger into a dedicated Transactions tab.
- Added Transactions to the mobile navigation and kept pagination/filtering/edit/delete controls there.
- Monthly summary cells now open the dedicated Transactions view for the selected month/card instead of expanding the dashboard.

## V25 — Maybank Family & Friends cashback allocation fix

- Reworked F&F MYR/IDR cashback allocation to follow the effective 1 Jan 2026 terms, Clauses 3.1.1–3.1.2.
- Eligible MYR/IDR transactions outside the selected/default categories go to the MYR/IDR Additional Bonus Category from the first dollar.
- Eligible MYR/IDR transactions that also fall into a selected/default category are treated as Repeat Categories Transactions: the first S$333.34 in Tier 1 or S$375 in Tier 2 is allocated to that category; only the excess is allocated to MYR/IDR.
- Groceries uses its separate S$500 repeat-category threshold and remains capped at 6% in the Groceries bucket; excess eligible MYR/IDR spend is allocated to MYR/IDR at the applicable tier rate.
- The normal category cap and the MYR/IDR category cap are tracked independently. Transactions crossing a threshold are split across the applicable reward buckets.
- Existing F&F transactions are recalculated once on first dashboard load after upgrade using a new migration marker (`migrate_maybank_tnc_v4`).
- Keeps the V23 email parsing/debugging, mobile-friendly UI, transaction editing, Maybank FX snapshots, and other card logic.

## Upgrade notes

Preserve the existing `data/miles.db` and `data/.credential_key`. This release archive intentionally does not include a live database or credentials. Replace application files, rebuild/restart the container, and open the dashboard; the one-time cashback migration will recalculate existing F&F rewards.

## Maybank foreign currency

- `amount` / `currency` retain the original transaction currency and amount.
- `spend_sgd` is the SGD equivalent used for reward thresholds.
- Stored FX snapshots remain stable over time; a final posted SGD amount can override the estimate.
